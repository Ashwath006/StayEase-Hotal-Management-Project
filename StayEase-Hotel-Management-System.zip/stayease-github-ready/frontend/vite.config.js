import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({

  plugins: [react()],

  server: {
    host: "stayease.com",
    port: 5173,
  },

});