import {
  NavLink,
  Outlet,
  useNavigate,
} from "react-router-dom";

import {
  FaHotel,
  FaHome,
  FaBed,
  FaCalendarCheck,
  FaUsers,
  FaSignOutAlt,
  FaBars,
  FaUserShield,
} from "react-icons/fa";

import { useState } from "react";

import "../styles/adminLayout.css";


function AdminLayout() {

  const navigate = useNavigate();

  const [sidebar, setSidebar] = useState(true);


  const logout = () => {

    localStorage.removeItem("token");

    localStorage.removeItem("user");

    navigate("/login");

  };


  return (

    <div className="admin-layout">


      <aside
        className={`admin-sidebar ${
          sidebar
            ? "sidebar-open"
            : "sidebar-closed"
        }`}
      >

        <div className="sidebar-inner">


          {/* LOGO */}

          <div className="sidebar-brand">

            <div className="brand-icon">

              <FaHotel />

            </div>

            <div>

              <h3>

                StayEase

              </h3>

              <span>

                LUXURY MANAGEMENT

              </span>

            </div>

          </div>


          {/* DIVIDER */}

          <div className="sidebar-divider"></div>


          {/* MENU LABEL */}

          <p className="sidebar-label">

            MAIN MENU

          </p>


          {/* DASHBOARD */}

          <NavLink
            to="/admin"
            end
            className={({ isActive }) =>
              `admin-nav-link ${
                isActive ? "active" : ""
              }`
            }
          >

            <FaHome />

            <span>

              Dashboard

            </span>

          </NavLink>


          {/* HOTELS */}

          <NavLink
            to="/admin/hotels"
            className={({ isActive }) =>
              `admin-nav-link ${
                isActive ? "active" : ""
              }`
            }
          >

            <FaHotel />

            <span>

              Hotels

            </span>

          </NavLink>


          {/* ROOMS */}

          <NavLink
            to="/admin/rooms"
            className={({ isActive }) =>
              `admin-nav-link ${
                isActive ? "active" : ""
              }`
            }
          >

            <FaBed />

            <span>

              Rooms

            </span>

          </NavLink>


          {/* BOOKINGS */}

          <NavLink
            to="/admin/bookings"
            className={({ isActive }) =>
              `admin-nav-link ${
                isActive ? "active" : ""
              }`
            }
          >

            <FaCalendarCheck />

            <span>

              Bookings

            </span>

          </NavLink>


          {/* USERS */}

          <NavLink
            to="/admin/users"
            className={({ isActive }) =>
              `admin-nav-link ${
                isActive ? "active" : ""
              }`
            }
          >

            <FaUsers />

            <span>

              Users

            </span>

          </NavLink>


          {/* BOTTOM AREA */}

          <div className="sidebar-bottom">


            <div className="sidebar-status">

              <span className="status-dot"></span>

              <div>

                <strong>

                  System Online

                </strong>

                <small>

                  All services operational

                </small>

              </div>

            </div>


            {/* LOGOUT */}

            <button
              className="admin-logout-btn"
              onClick={logout}
            >

              <FaSignOutAlt />

              <span>

                Logout

              </span>

            </button>

          </div>


        </div>

      </aside>

      <main className="admin-main">


        {/* TOPBAR */}

        <nav className="admin-topbar">


          <button
            className="sidebar-toggle"
            onClick={() =>
              setSidebar(!sidebar)
            }
          >

            <FaBars />

          </button>


          <div className="topbar-right">


            <div className="admin-profile">


              <div className="admin-avatar">

                <FaUserShield />

              </div>


              <div className="admin-profile-info">

                <h6>

                  Admin

                </h6>

                <span>

                  StayEase Management

                </span>

              </div>


            </div>


          </div>


        </nav>


        {/* PAGE CONTENT */}

        <section className="admin-content">


          <div className="admin-content-card">


            <Outlet />


          </div>


        </section>


      </main>


    </div>

  );

}


export default AdminLayout;