import { useState } from "react";
import { toast } from "react-toastify";
import {
  FaHotel,
  FaMapMarkerAlt,
  FaAlignLeft,
  FaRupeeSign,
  FaStar,
  FaImage,
  FaConciergeBell,
  FaPlus,
  FaCrown,
  FaTimes,
} from "react-icons/fa";

import { addHotel } from "../services/hotelService";
import "../styles/AddHotel.css";

function AddHotel({ refreshHotels, onClose }) {
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    hotelName: "",
    location: "",
    description: "",
    price: "",
    rating: "",
    image: "",
    amenities: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.hotelName.trim() ||
      !formData.location.trim() ||
      !formData.price
    ) {
      toast.error("Please fill all required fields");
      return;
    }

    if (Number(formData.price) <= 0) {
      toast.error("Price must be greater than zero");
      return;
    }

    if (
      formData.rating !== "" &&
      (Number(formData.rating) < 0 ||
        Number(formData.rating) > 5)
    ) {
      toast.error("Rating must be between 0 and 5");
      return;
    }

    try {
      setLoading(true);

      const payload = {
        hotelName: formData.hotelName.trim(),
        location: formData.location.trim(),
        description: formData.description.trim(),
        price: Number(formData.price),
        rating: Number(formData.rating || 0),
        images: formData.image.trim()
          ? [formData.image.trim()]
          : [],
        amenities: formData.amenities
          ? formData.amenities
              .split(",")
              .map((item) => item.trim())
              .filter(Boolean)
          : [],
      };

      await addHotel(payload);

      toast.success("Hotel added successfully!");

      setFormData({
        hotelName: "",
        location: "",
        description: "",
        price: "",
        rating: "",
        image: "",
        amenities: "",
      });

      if (typeof refreshHotels === "function") {
        await refreshHotels();
      }

      if (typeof onClose === "function") {
        onClose();
      }
    } catch (err) {
      console.error("Add hotel error:", err);

      toast.error(
        err?.response?.data?.message ||
          "Failed to add hotel. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="add-hotel-page">
      <div className="add-hotel-card">

        {/* Header */}
        <div className="add-hotel-header">
          <div className="add-hotel-header-content">
            <div className="add-hotel-icon">
              <FaHotel />
            </div>

            <div>
              <span className="add-hotel-eyebrow">
                STAYEASE · ADMINISTRATION
              </span>

              <h2>Add New Hotel</h2>

              <p>
                Expand your collection with an exceptional stay.
              </p>
            </div>
          </div>

          {typeof onClose === "function" && (
            <button
              type="button"
              className="add-hotel-close"
              onClick={onClose}
              aria-label="Close form"
            >
              <FaTimes />
            </button>
          )}

          <div className="add-hotel-header-decoration">
            <FaCrown />
          </div>
        </div>

        {/* Form */}
        <div className="add-hotel-body">
          <div className="add-hotel-section-heading">
            <span className="add-hotel-gold-line" />
            <h3>Hotel Information</h3>
            <p>
              Enter the property details to create a new listing.
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="row g-4">

              {/* Hotel Name */}
              <div className="col-md-6">
                <label
                  htmlFor="hotelName"
                  className="add-hotel-label"
                >
                  <FaHotel />
                  Hotel Name <span>*</span>
                </label>

                <input
                  id="hotelName"
                  className="form-control add-hotel-input"
                  type="text"
                  name="hotelName"
                  value={formData.hotelName}
                  onChange={handleChange}
                  placeholder="Enter hotel name"
                  maxLength={100}
                  required
                />
              </div>

              {/* Location */}
              <div className="col-md-6">
                <label
                  htmlFor="location"
                  className="add-hotel-label"
                >
                  <FaMapMarkerAlt />
                  Location <span>*</span>
                </label>

                <input
                  id="location"
                  className="form-control add-hotel-input"
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  placeholder="City, state or destination"
                  maxLength={200}
                  required
                />
              </div>

              {/* Description */}
              <div className="col-12">
                <label
                  htmlFor="description"
                  className="add-hotel-label"
                >
                  <FaAlignLeft />
                  Hotel Description
                </label>

                <textarea
                  id="description"
                  className="form-control add-hotel-input add-hotel-textarea"
                  rows="4"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Describe the hotel's experience, comfort and facilities..."
                  maxLength={2000}
                />
              </div>

              {/* Price */}
              <div className="col-md-6">
                <label
                  htmlFor="price"
                  className="add-hotel-label"
                >
                  <FaRupeeSign />
                  Price Per Night <span>*</span>
                </label>

                <div className="add-hotel-price-wrap">
                  <span className="add-hotel-price-symbol">
                    ₹
                  </span>

                  <input
                    id="price"
                    className="form-control add-hotel-input add-hotel-price-input"
                    type="number"
                    name="price"
                    min="1"
                    step="0.01"
                    value={formData.price}
                    onChange={handleChange}
                    placeholder="5000"
                    required
                  />
                </div>

                <small className="add-hotel-help">
                  Enter the starting price for one night.
                </small>
              </div>

              {/* Rating */}
              <div className="col-md-6">
                <label
                  htmlFor="rating"
                  className="add-hotel-label"
                >
                  <FaStar />
                  Hotel Rating
                </label>

                <div className="add-hotel-rating-wrap">
                  <input
                    id="rating"
                    className="form-control add-hotel-input"
                    type="number"
                    name="rating"
                    min="0"
                    max="5"
                    step="0.1"
                    value={formData.rating}
                    onChange={handleChange}
                    placeholder="4.5"
                  />

                  <span className="add-hotel-rating-star">
                    <FaStar />
                    <small>/ 5</small>
                  </span>
                </div>

                <small className="add-hotel-help">
                  Enter a rating between 0 and 5.
                </small>
              </div>

              {/* Image URL */}
              <div className="col-12">
                <label
                  htmlFor="image"
                  className="add-hotel-label"
                >
                  <FaImage />
                  Hotel Image URL
                </label>

                <input
                  id="image"
                  className="form-control add-hotel-input"
                  type="url"
                  name="image"
                  value={formData.image}
                  onChange={handleChange}
                  placeholder="https://example.com/hotel-image.jpg"
                />

                {formData.image.trim() && (
                  <div className="add-hotel-image-preview">
                    <img
                      src={formData.image}
                      alt="Hotel preview"
                      onError={(e) => {
                        e.currentTarget.style.display = "none";
                      }}
                      onLoad={(e) => {
                        e.currentTarget.style.display = "block";
                      }}
                    />

                    <span>Image Preview</span>
                  </div>
                )}
              </div>

              {/* Amenities */}
              <div className="col-12">
                <label
                  htmlFor="amenities"
                  className="add-hotel-label"
                >
                  <FaConciergeBell />
                  Hotel Amenities
                </label>

                <input
                  id="amenities"
                  className="form-control add-hotel-input"
                  type="text"
                  name="amenities"
                  value={formData.amenities}
                  onChange={handleChange}
                  placeholder="WiFi, Swimming Pool, Parking, Gym"
                />

                <small className="add-hotel-help">
                  Separate each amenity with a comma.
                </small>
              </div>

            </div>

            {/* Footer */}
            <div className="add-hotel-form-footer">
              <div className="add-hotel-required-note">
                <span>*</span> Required fields
              </div>

              <div className="add-hotel-actions">
                {typeof onClose === "function" && (
                  <button
                    type="button"
                    className="add-hotel-cancel-btn"
                    onClick={onClose}
                    disabled={loading}
                  >
                    Cancel
                  </button>
                )}

                <button
                  type="submit"
                  className="add-hotel-submit-btn"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="add-hotel-spinner" />
                      Adding Hotel...
                    </>
                  ) : (
                    <>
                      <FaPlus />
                      Add Hotel
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>

        {/* Bottom branding */}
        <div className="add-hotel-bottom">
          <span>✦</span>
          STAYEASE ROYAL COLLECTION
          <span>✦</span>
        </div>

      </div>
    </div>
  );
}

export default AddHotel;