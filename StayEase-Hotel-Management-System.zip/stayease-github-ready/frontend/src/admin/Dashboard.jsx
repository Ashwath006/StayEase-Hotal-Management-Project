import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import "../styles/dashboard.css";

import {
  FaUsers,
  FaHotel,
  FaBed,
  FaCalendarCheck,
  FaRupeeSign,
  FaPlusCircle,
  FaClipboardList,
  FaCog,
  FaChartLine,
  FaSyncAlt,
} from "react-icons/fa";

function Dashboard() {
  const navigate = useNavigate();

  const [dashboard, setDashboard] = useState({
    totalUsers: 0,
    totalHotels: 0,
    totalRooms: 0,
    totalBookings: 0,
    totalRevenue: 0,
    recentBookings: [],
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      setError("");

      const res = await API.get("/admin/dashboard");
      const data = res.data;

      setDashboard({
        totalUsers: data.totalUsers ?? 0,
        totalHotels: data.totalHotels ?? 0,
        totalRooms: data.totalRooms ?? 0,
        totalBookings: data.totalBookings ?? 0,
        totalRevenue: data.totalRevenue ?? 0,
        recentBookings: Array.isArray(data.recentBookings)
          ? data.recentBookings
          : [],
      });
    } catch (err) {
      console.error("Dashboard error:", err);

      setError(
        err.response?.data?.message ||
          "Dashboard data load ஆகவில்லை. Backend-ஐச் சரிபார்க்கவும்."
      );
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) =>
    new Intl.NumberFormat("en-IN", {
      maximumFractionDigits: 2,
    }).format(Number(amount) || 0);

  const getStatusClass = (status) => {
    const value = (status || "Pending").toLowerCase();

    if (["cancelled", "canceled"].includes(value)) {
      return "status-cancelled";
    }

    if (["confirmed", "booked", "completed", "paid"].includes(value)) {
      return "status-confirmed";
    }

    if (value === "processing") {
      return "status-processing";
    }

    return "status-pending";
  };

  const statCards = [
    {
      title: "Total Users",
      value: dashboard.totalUsers,
      description: "Registered Members",
      icon: <FaUsers />,
      className: "users-card",
    },
    {
      title: "Total Hotels",
      value: dashboard.totalHotels,
      description: "Premium Properties",
      icon: <FaHotel />,
      className: "hotels-card",
    },
    {
      title: "Total Rooms",
      value: dashboard.totalRooms,
      description: "Registered Hotel Rooms",
      icon: <FaBed />,
      className: "rooms-card",
    },
    {
      title: "Total Bookings",
      value: dashboard.totalBookings,
      description: "All Reservations",
      icon: <FaCalendarCheck />,
      className: "bookings-card",
    },
  ];

  const quickActions = [
    {
      label: "Add Hotel",
      icon: <FaPlusCircle />,
      path: "/admin/hotels",
    },
    {
      label: "View Bookings",
      icon: <FaClipboardList />,
      path: "/admin/bookings",
    },
    {
      label: "Manage Rooms",
      icon: <FaCog />,
      path: "/admin/rooms",
    },
    {
      label: "Manage Users",
      icon: <FaUsers />,
      path: "/admin/users",
    },
  ];

  return (
    <div className="container-fluid dashboard-page">
      {/* Dashboard Header */}
      <div className="dashboard-header">
        <div>
          <span className="dashboard-eyebrow">Admin Panel</span>

          <h2 className="dashboard-title">
            Welcome Back, Admin 👋
          </h2>

          <p className="dashboard-subtitle">
            Monitor hotels, bookings, revenue and users
            from your StayEase management dashboard.
          </p>
        </div>

        <div className="dashboard-header-tools">
          <div className="dashboard-brand">
            <FaHotel />
            <span>StayEase Luxury Hotels</span>
          </div>

          <button
            type="button"
            className="dashboard-action-btn"
            onClick={fetchDashboard}
            disabled={loading}
          >
            <FaSyncAlt />
            {loading ? "Loading..." : "Refresh"}
          </button>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="dashboard-message mb-4" role="alert">
          <p className="mb-2">{error}</p>

          <button
            type="button"
            className="dashboard-action-btn"
            onClick={fetchDashboard}
            disabled={loading}
          >
            Try Again
          </button>
        </div>
      )}

      {/* Statistics */}
      <div className="row g-4">
        {statCards.map((item) => (
          <div className="col-xl-3 col-md-6" key={item.title}>
            <div className={`dashboard-card ${item.className}`}>
              <div className="dashboard-icon">{item.icon}</div>

              <h5>{item.title}</h5>

              <h2>
                {loading
                  ? "..."
                  : Number(item.value).toLocaleString("en-IN")}
              </h2>

              <p>{item.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Revenue and Quick Actions */}
      <div className="row g-4 mt-2">
        <div className="col-xl-5 col-lg-6">
          <div className="dashboard-card revenue-card">
            <div className="dashboard-icon">
              <FaRupeeSign />
            </div>

            <h5>Total Revenue</h5>

            <h2>
              {loading
                ? "..."
                : `₹ ${formatCurrency(dashboard.totalRevenue)}`}
            </h2>

            <p>Revenue reported by the backend</p>
          </div>
        </div>

        <div className="col-xl-7 col-lg-6">
          <div className="dashboard-card">
            <div className="dashboard-actions-heading">
              <span className="dashboard-eyebrow">
                Shortcuts
              </span>

              <h4 className="dashboard-section-title">
                Quick Actions
              </h4>

              <p className="dashboard-section-subtitle">
                Manage your hotel operations quickly.
              </p>
            </div>

            <div className="dashboard-actions">
              {quickActions.map((item) => (
                <button
                  key={item.label}
                  type="button"
                  className="dashboard-action-btn"
                  onClick={() => navigate(item.path)}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            <div className="dashboard-quick-note">
              <FaChartLine />
              <span>
                StayEase Management Overview
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Bookings */}
      <div className="row mt-4">
        <div className="col-12">
          <div className="dashboard-panel">
            <div className="dashboard-panel-header">
              <div>
                <span className="dashboard-eyebrow">
                  Reservations
                </span>

                <h4>Recent Bookings</h4>

                <p>
                  Latest reservations recorded in StayEase
                </p>
              </div>

              <FaCalendarCheck className="panel-accent" />
            </div>

            <div className="dashboard-table-wrap">
              <table className="table dashboard-table">
                <thead>
                  <tr>
                    <th>User</th>
                    <th>Hotel</th>
                    <th>Room</th>
                    <th>Status</th>
                  </tr>
                </thead>

                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan="4">
                        <div className="dashboard-empty-state">
                          <p>Loading bookings...</p>
                        </div>
                      </td>
                    </tr>
                  ) : dashboard.recentBookings.length === 0 ? (
                    <tr>
                      <td colSpan="4">
                        <div className="dashboard-empty-state">
                          <FaCalendarCheck className="empty-icon" />
                          <h5>No Recent Bookings</h5>
                          <p>
                            New reservations will appear here.
                          </p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    dashboard.recentBookings.map((booking) => {
                      const userName =
                        booking.userId?.name || "Unknown User";

                      const hotelName =
                        booking.hotelId?.hotelName || "Unknown Hotel";

                      const roomNumber =
                        booking.roomId?.roomNumber || "N/A";

                      const status =
                        booking.bookingStatus || "Pending";

                      return (
                        <tr key={booking._id}>
                          <td>
                            <span className="booking-guest-name">
                              {userName}
                            </span>

                            <span className="booking-secondary-text">
                              Guest
                            </span>
                          </td>

                          <td>{hotelName}</td>

                          <td>{roomNumber}</td>

                          <td>
                            <span
                              className={getStatusClass(status)}
                            >
                              {status}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <div className="dashboard-panel-footer">
              <button
                type="button"
                className="dashboard-action-btn"
                onClick={() => navigate("/admin/bookings")}
              >
                <FaClipboardList />
                View All Bookings
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;