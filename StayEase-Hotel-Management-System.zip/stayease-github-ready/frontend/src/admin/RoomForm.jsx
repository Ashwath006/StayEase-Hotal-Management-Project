
import { useEffect, useState } from "react";
import { addRoom } from "../services/roomService";
import { getHotels } from "../services/hotelService";
import "../styles/AdminRooms.css";

function RoomForm({ refreshRooms }) {
  const [hotels, setHotels] = useState([]);
  const [loadingHotels, setLoadingHotels] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const initialFormData = {
    hotel: "",
    roomNumber: "",
    roomType: "Standard",
    price: "",
    capacity: "",
    beds: 1,
    available: true,
  };

  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    loadHotels();
  }, []);

  const loadHotels = async () => {
    try {
      setLoadingHotels(true);

      const res = await getHotels();
      setHotels(res.data.hotels || []);
    } catch (err) {
      console.error("Failed to load hotels:", err);
      setError("Unable to load hotels. Please try again.");
    } finally {
      setLoadingHotels(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      setSubmitting(true);

      await addRoom({
        ...formData,
        price: Number(formData.price),
        capacity: Number(formData.capacity),
        beds: Number(formData.beds),
      });

      window.alert("Room added successfully!");

      setFormData(initialFormData);

      if (refreshRooms) {
        await refreshRooms();
      }
    } catch (err) {
      console.error("Failed to add room:", err);

      setError(
        err.response?.data?.message ||
          "Unable to add room. Please check the details and try again."
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="room-form-page">
      <div className="room-form-card">

        {/* FORM HEADER */}
        <div className="room-form-header">
          <div className="room-form-header-icon">
            <span>▦</span>
          </div>

          <div className="room-form-header-content">
            <span className="room-form-eyebrow">
              STAYEASE · PROPERTY MANAGEMENT
            </span>

            <h3>Add New Room</h3>

            <p>
              Configure room details, pricing and availability.
            </p>
          </div>
        </div>

        {/* FORM CONTENT */}
        <div className="room-form-body">
          <form onSubmit={handleSubmit}>

            {/* HOTEL DETAILS */}
            <div className="room-form-section-heading">
              <span className="room-form-section-number">01</span>
              <div>
                <h4>Property Details</h4>
                <p>Select the hotel for this room.</p>
              </div>
            </div>

            <div className="room-form-grid">
              <div className="room-form-field room-form-full">
                <label htmlFor="room-hotel">
                  Select Hotel <span>*</span>
                </label>

                <select
                  id="room-hotel"
                  className="form-select room-form-control"
                  name="hotel"
                  value={formData.hotel}
                  onChange={handleChange}
                  required
                  disabled={loadingHotels}
                >
                  <option value="">
                    {loadingHotels
                      ? "Loading hotels..."
                      : "Choose a hotel"}
                  </option>

                  {hotels.map((hotel) => (
                    <option key={hotel._id} value={hotel._id}>
                      {hotel.hotelName}
                    </option>
                  ))}
                </select>

                {!loadingHotels && hotels.length === 0 && (
                  <small className="room-form-help">
                    No hotels found. Add a hotel before creating a room.
                  </small>
                )}
              </div>
            </div>

            {/* ROOM DETAILS */}
            <div className="room-form-section-heading">
              <span className="room-form-section-number">02</span>
              <div>
                <h4>Room Information</h4>
                <p>Enter the room number and room category.</p>
              </div>
            </div>

            <div className="room-form-grid">
              <div className="room-form-field">
                <label htmlFor="room-number">
                  Room Number <span>*</span>
                </label>

                <input
                  id="room-number"
                  className="form-control room-form-control"
                  type="text"
                  name="roomNumber"
                  value={formData.roomNumber}
                  onChange={handleChange}
                  placeholder="e.g. DLX-101"
                  required
                />
              </div>

              <div className="room-form-field">
                <label htmlFor="room-type">
                  Room Type <span>*</span>
                </label>

                <select
                  id="room-type"
                  className="form-select room-form-control"
                  name="roomType"
                  value={formData.roomType}
                  onChange={handleChange}
                  required
                >
                  <option value="Standard">Standard</option>
                  <option value="Deluxe">Deluxe</option>
                  <option value="Suite">Suite</option>
                </select>
              </div>
            </div>

            {/* PRICING & CAPACITY */}
            <div className="room-form-section-heading">
              <span className="room-form-section-number">03</span>
              <div>
                <h4>Pricing & Capacity</h4>
                <p>Set the nightly price and guest capacity.</p>
              </div>
            </div>

            <div className="room-form-grid">
              <div className="room-form-field">
                <label htmlFor="room-price">
                  Price Per Night <span>*</span>
                </label>

                <div className="room-form-price-wrap">
                  <span className="room-form-price-symbol">₹</span>

                  <input
                    id="room-price"
                    className="form-control room-form-control room-form-price-input"
                    type="number"
                    name="price"
                    min="1"
                    step="0.01"
                    value={formData.price}
                    onChange={handleChange}
                    placeholder="5000"
                    required
                  />
                </div>
              </div>

              <div className="room-form-field">
                <label htmlFor="room-capacity">
                  Guest Capacity <span>*</span>
                </label>

                <input
                  id="room-capacity"
                  className="form-control room-form-control"
                  type="number"
                  name="capacity"
                  min="1"
                  step="1"
                  value={formData.capacity}
                  onChange={handleChange}
                  placeholder="e.g. 2"
                  required
                />
              </div>

              <div className="room-form-field">
                <label htmlFor="room-beds">
                  Number of Beds <span>*</span>
                </label>

                <input
                  id="room-beds"
                  className="form-control room-form-control"
                  type="number"
                  name="beds"
                  min="1"
                  step="1"
                  value={formData.beds}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="room-form-field room-form-availability-field">
                <label>Room Availability</label>

                <label className="room-form-availability">
                  <input
                    type="checkbox"
                    name="available"
                    checked={formData.available}
                    onChange={handleChange}
                  />

                  <span className="room-form-toggle" />

                  <span className="room-form-availability-text">
                    <strong>
                      {formData.available ? "Available" : "Unavailable"}
                    </strong>
                    <small>
                      {formData.available
                        ? "Room can be booked"
                        : "Room is not available for booking"}
                    </small>
                  </span>
                </label>
              </div>
            </div>

            {/* ERROR MESSAGE */}
            {error && (
              <div className="room-form-error" role="alert">
                {error}
              </div>
            )}

            {/* FORM ACTIONS */}
            <div className="room-form-actions">
              <button
                type="button"
                className="room-form-reset-btn"
                onClick={() => {
                  setFormData(initialFormData);
                  setError("");
                }}
                disabled={submitting}
              >
                Reset Form
              </button>

              <button
                type="submit"
                className="room-form-submit-btn"
                disabled={submitting || loadingHotels || hotels.length === 0}
              >
                {submitting ? "Adding Room..." : "+ Add Room"}
              </button>
            </div>

          </form>
        </div>
      </div>
    </section>
  );
}

export default RoomForm;
