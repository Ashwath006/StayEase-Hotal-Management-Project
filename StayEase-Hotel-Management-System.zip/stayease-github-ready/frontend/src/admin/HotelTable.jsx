import { useState } from "react";
import { FaEdit, FaTrash } from "react-icons/fa";
import DeleteConfirmModal from "./DeleteConfirmModal";

function HotelTable({ hotels = [], onEdit, onDelete }) {
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const handleConfirmDelete = async () => {
    if (!selectedHotel || deleting) return;

    try {
      setDeleting(true);

      await onDelete(selectedHotel._id);

      setSelectedHotel(null);
    } catch (error) {
      console.error("Failed to delete hotel:", error);
    } finally {
      setDeleting(false);
    }
  };

  if (hotels.length === 0) {
    return (
      <div className="alert alert-warning text-center">
        No Hotels Found
      </div>
    );
  }

  return (
    <>
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead className="table-dark">
            <tr>
              <th>Image</th>
              <th>Hotel</th>
              <th>Location</th>
              <th>Price / Night</th>
              <th>Rating</th>
              <th>Amenities</th>
              <th style={{ width: "170px" }}>Actions</th>
            </tr>
          </thead>

          <tbody>
            {hotels.map((hotel) => (
              <tr key={hotel._id}>
                <td>
                  <img
                    src={
                      hotel.images?.length
                        ? hotel.images[0]
                        : "https://via.placeholder.com/80x60?text=Hotel"
                    }
                    alt={hotel.hotelName || "Hotel"}
                    width="80"
                    height="60"
                    style={{
                      objectFit: "cover",
                      borderRadius: "8px",
                    }}
                  />
                </td>

                <td>
                  <strong>{hotel.hotelName}</strong>
                </td>

                <td>📍 {hotel.location}</td>

                <td>
                  <span className="fw-bold text-success">
                    ₹ {hotel.price}
                  </span>
                </td>

                <td>
                  <span className="badge bg-warning text-dark">
                    ⭐ {hotel.rating ?? "N/A"}
                  </span>
                </td>

                <td>
                  <span className="badge bg-info">
                    {hotel.amenities?.length || 0} Amenities
                  </span>
                </td>

                <td>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm me-2"
                    onClick={() => onEdit(hotel)}
                  >
                    <FaEdit /> Edit
                  </button>

                  <button
                    type="button"
                    className="btn btn-danger btn-sm"
                    onClick={() => setSelectedHotel(hotel)}
                  >
                    <FaTrash /> Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <DeleteConfirmModal
        show={Boolean(selectedHotel)}
        title="Delete Hotel?"
        message="Are you sure you want to delete this hotel?"
        itemName={selectedHotel?.hotelName || ""}
        loading={deleting}
        onCancel={() => {
          if (!deleting) {
            setSelectedHotel(null);
          }
        }}
        onConfirm={handleConfirmDelete}
      />
    </>
  );
}

export default HotelTable;
