import { useEffect, useState } from "react";
import { FaTrash } from "react-icons/fa";
import API from "../services/api";
import { toast } from "react-toastify";
import LoadingSpinner from "../components/LoadingSpinner";
import DeleteConfirmModal from "../components/DeleteConfirmModal";
import "../styles/AdminUsers.css";

function Users() {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const [selectedUser, setSelectedUser] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, []);

  useEffect(() => {
    const query = search.trim().toLowerCase();

    const result = users.filter((user) =>
      [user.name, user.email, user.phone, user.role]
        .filter(Boolean)
        .some((value) =>
          String(value).toLowerCase().includes(query)
        )
    );

    setFilteredUsers(result);
  }, [search, users]);

  const fetchUsers = async () => {
    try {
      setLoading(true);

      const res = await API.get("/admin/users");
      const userList = res.data.users || [];

      setUsers(userList);
    } catch (err) {
      console.error("Failed to fetch users:", err);
      toast.error("Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!selectedUser || deleting) return;

    try {
      setDeleting(true);

      await API.delete(`/admin/users/${selectedUser._id}`);

      toast.success("User deleted successfully");
      setSelectedUser(null);

      await fetchUsers();
    } catch (err) {
      console.error("Failed to delete user:", err);

      toast.error(
        err.response?.data?.message || "Failed to delete user"
      );
    } finally {
      setDeleting(false);
    }
  };

  if (loading) return <LoadingSpinner />;

  const adminCount = users.filter(
    (user) => user.role === "admin"
  ).length;

  const regularCount = users.length - adminCount;

  return (
    <main className="admin-users-page">
      {/* PAGE HEADER */}
      <header className="admin-users-header">
        <div>
          <p className="admin-users-eyebrow">
            STAYEASE ADMINISTRATION
          </p>

          <h1 className="admin-users-heading">
            Manage Users
          </h1>

          <p className="admin-users-subtitle">
            View user details and manage registered accounts.
          </p>
        </div>

        <button
          type="button"
          className="admin-users-refresh-btn"
          onClick={fetchUsers}
          disabled={loading || deleting}
          aria-label="Refresh users"
        >
          <span aria-hidden="true">↻</span> Refresh
        </button>
      </header>

      {/* USER STATISTICS */}
      <section
        className="admin-users-stats"
        aria-label="User statistics"
      >
        <article className="admin-users-stat-card">
          <div
            className="admin-users-stat-icon admin-users-icon-navy"
            aria-hidden="true"
          >
            ♙
          </div>

          <div>
            <p className="admin-users-stat-label">Total Users</p>
            <h2 className="admin-users-stat-value">
              {users.length}
            </h2>
            <p className="admin-users-stat-note">
              All registered accounts
            </p>
          </div>
        </article>

        <article className="admin-users-stat-card">
          <div
            className="admin-users-stat-icon admin-users-icon-green"
            aria-hidden="true"
          >
            ✓
          </div>

          <div>
            <p className="admin-users-stat-label">
              Regular Users
            </p>
            <h2 className="admin-users-stat-value">
              {regularCount}
            </h2>
            <p className="admin-users-stat-note">
              Customer accounts
            </p>
          </div>
        </article>

        <article className="admin-users-stat-card">
          <div
            className="admin-users-stat-icon admin-users-icon-gold"
            aria-hidden="true"
          >
            ♛
          </div>

          <div>
            <p className="admin-users-stat-label">
              Administrators
            </p>
            <h2 className="admin-users-stat-value">
              {adminCount}
            </h2>
            <p className="admin-users-stat-note">
              Privileged accounts
            </p>
          </div>
        </article>
      </section>

      {/* USER LIST */}
      <section className="admin-users-list-section">
        <div className="admin-users-list-header">
          <div>
            <h2 className="admin-users-section-heading">
              Registered Accounts
            </h2>

            <p className="admin-users-section-description">
              {filteredUsers.length}{" "}
              {filteredUsers.length === 1
                ? "account"
                : "accounts"}{" "}
              shown
            </p>
          </div>

          <label className="admin-users-search-wrap">
            <span
              className="admin-users-search-icon"
              aria-hidden="true"
            >
              ⌕
            </span>

            <input
              type="search"
              className="admin-users-search"
              placeholder="Search name, email, phone or role..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search users"
            />
          </label>
        </div>

        <div className="admin-users-table-wrap">
          <table className="admin-users-table">
            <thead>
              <tr>
                <th scope="col">User</th>
                <th scope="col">Email Address</th>
                <th scope="col">Phone</th>
                <th scope="col">Role</th>
                <th
                  scope="col"
                  className="admin-users-action-heading"
                >
                  Action
                </th>
              </tr>
            </thead>

            <tbody>
              {filteredUsers.length === 0 ? (
                <tr>
                  <td
                    colSpan="5"
                    className="admin-users-empty-cell"
                  >
                    <div
                      className="admin-users-empty-icon"
                      aria-hidden="true"
                    >
                      ⌕
                    </div>

                    <strong>No Users Found</strong>
                    <span>
                      Try changing your search keywords.
                    </span>
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => (
                  <tr key={user._id}>
                    <td>
                      <div className="admin-users-name-cell">
                        <span
                          className="admin-users-avatar"
                          aria-hidden="true"
                        >
                          {(user.name || "U")
                            .trim()
                            .charAt(0)
                            .toUpperCase()}
                        </span>

                        <span className="admin-users-name">
                          {user.name || "Unknown User"}
                        </span>
                      </div>
                    </td>

                    <td className="admin-users-email">
                      {user.email || "-"}
                    </td>

                    <td className="admin-users-phone">
                      {user.phone || "-"}
                    </td>

                    <td>
                      <span
                        className={`admin-users-role ${
                          user.role === "admin"
                            ? "admin-users-role-admin"
                            : "admin-users-role-user"
                        }`}
                      >
                        <span className="admin-users-role-dot" />
                        {user.role || "user"}
                      </span>
                    </td>

                    <td className="admin-users-action-cell">
                      {user.role === "admin" ? (
                        <button
                          type="button"
                          className="admin-users-admin-btn"
                          disabled
                        >
                          Admin Account
                        </button>
                      ) : (
                        <button
                          type="button"
                          className="admin-users-delete-btn"
                          onClick={() => setSelectedUser(user)}
                          disabled={deleting}
                          aria-label={`Delete ${
                            user.name || "user"
                          }`}
                        >
                          <FaTrash /> Delete
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="admin-users-table-footer">
          <span>
            Showing <strong>{filteredUsers.length}</strong> of{" "}
            <strong>{users.length}</strong> users
          </span>

          <span className="admin-users-footer-mark">
            <span /> Secure user management
          </span>
        </div>
      </section>

      {/* DELETE CONFIRMATION */}
      <DeleteConfirmModal
        show={Boolean(selectedUser)}
        title="Delete User?"
        message="Are you sure you want to delete this user?"
        itemName={selectedUser?.name || selectedUser?.email || ""}
        loading={deleting}
        onCancel={() => {
          if (!deleting) {
            setSelectedUser(null);
          }
        }}
        onConfirm={handleConfirmDelete}
      />
    </main>
  );
}

export default Users;