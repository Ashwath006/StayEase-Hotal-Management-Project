import { useState, useEffect } from "react";
import { updateRoom } from "../services/roomService";

function EditRoomModal({ room, refreshRooms }) {

  const [formData, setFormData] = useState({
    roomNumber: "",
    roomType: "",
    price: "",
    capacity: "",
    available: true,
  });

  useEffect(() => {
    if (room) {
      setFormData({
        roomNumber: room.roomNumber,
        roomType: room.roomType,
        price: room.price,
        capacity: room.capacity,
        available: room.available,
      });
    }
  }, [room]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {

      await updateRoom(room._id, formData);

      alert("Room Updated Successfully");

      refreshRooms();

    } catch (err) {

      console.log(err);

      alert("Update Failed");

    }
  };

  if (!room) return null;

  return (
    <div className="card p-4 mb-4 shadow">

      <h3>Edit Room</h3>

      <form onSubmit={handleSubmit}>

        <input
          className="form-control mb-3"
          name="roomNumber"
          value={formData.roomNumber}
          onChange={handleChange}
        />

        <select
          className="form-select mb-3"
          name="roomType"
          value={formData.roomType}
          onChange={handleChange}
        >
          <option>Standard</option>
          <option>Deluxe</option>
          <option>Suite</option>
        </select>

        <input
          className="form-control mb-3"
          type="number"
          name="price"
          value={formData.price}
          onChange={handleChange}
        />

        <input
          className="form-control mb-3"
          type="number"
          name="capacity"
          value={formData.capacity}
          onChange={handleChange}
        />

        <button className="btn btn-primary">
          Update Room
        </button>

      </form>

    </div>
  );
}

export default EditRoomModal;