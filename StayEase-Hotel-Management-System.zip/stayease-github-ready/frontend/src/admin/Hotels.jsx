import { useEffect, useState } from "react";
import { FaTrash } from "react-icons/fa";
import API from "../services/api";
import HotelCard from "../components/HotelCard";
import DeleteConfirmModal from "../components/DeleteConfirmModal";
import AddHotel from "./AddHotel";
import "../styles/AdminHotels.css";

function Hotels() {
  const [hotels, setHotels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showDeletePanel, setShowDeletePanel] = useState(false);
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState("");

  const [filters, setFilters] = useState({
    search: "",
    location: "",
    minPrice: "",
    maxPrice: "",
    sort: "",
  });

  useEffect(() => {
    fetchHotels();
  }, []);

  const fetchHotels = async (activeFilters = filters) => {
    try {
      setLoading(true);

      const res = await API.get("/hotels", {
        params: activeFilters,
      });

      setHotels(res.data.hotels || []);
    } catch (err) {
      console.error("Failed to fetch hotels:", err);
      setHotels([]);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFilters((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    fetchHotels(filters);
  };

  const clearFilters = () => {
    const resetFilters = {
      search: "",
      location: "",
      minPrice: "",
      maxPrice: "",
      sort: "",
    };

    setFilters(resetFilters);
    fetchHotels(resetFilters);
  };

  const handleConfirmDelete = async () => {
    if (!selectedHotel || deleting) return;

    try {
      setDeleting(true);
      setDeleteError("");

      await API.delete(`/hotels/${selectedHotel._id}`);

      setSelectedHotel(null);
      setShowDeletePanel(false);

      await fetchHotels(filters);
    } catch (err) {
      console.error("Failed to delete hotel:", err);

      setDeleteError(
        err.response?.data?.message ||
          "Unable to delete hotel. Please try again."
      );
    } finally {
      setDeleting(false);
    }
  };

  const closeDeletePanel = () => {
    if (deleting) return;

    setShowDeletePanel(false);
    setSelectedHotel(null);
    setDeleteError("");
  };

  const totalHotels = hotels.length;

  const averagePrice = totalHotels
    ? hotels.reduce(
        (total, hotel) => total + (Number(hotel.price) || 0),
        0
      ) / totalHotels
    : 0;

  const ratedHotels = hotels.filter(
    (hotel) => Number(hotel.rating) > 0
  );

  const averageRating = ratedHotels.length
    ? ratedHotels.reduce(
        (total, hotel) => total + Number(hotel.rating),
        0
      ) / ratedHotels.length
    : 0;

  const formatPrice = (price) =>
    new Intl.NumberFormat("en-IN", {
      maximumFractionDigits: 0,
    }).format(price);

  return (
    <div className="container-fluid admin-hotels-page">
      {/* PAGE HEADER */}
      <div className="admin-hotels-top">
        <div className="admin-hotels-heading">
          <span className="admin-hotels-eyebrow">
            STAYEASE ADMINISTRATION
          </span>

          <h2 className="admin-hotels-title">
            Hotel Management
          </h2>

          <p className="admin-hotels-subtitle">
            Manage your properties, pricing and hotel listings.
          </p>
        </div>

        <div className="admin-hotels-header-actions">
          <button
            type="button"
            className="admin-hotels-delete-btn"
            onClick={() => {
              setDeleteError("");
              setShowDeletePanel(true);
            }}
          >
            <FaTrash />
            Delete Hotel
          </button>

          <button
            type="button"
            className="admin-hotels-add-btn"
            onClick={() => setShowAddForm(true)}
          >
            <span className="admin-hotels-add-icon">+</span>
            Add New Hotel
          </button>
        </div>
      </div>

      {/* SUMMARY CARDS */}
      <div className="admin-hotels-stats">
        <div className="admin-hotels-stat-card">
          <div className="admin-hotels-stat-icon hotel-stat-blue">
            <span>⌂</span>
          </div>

          <div className="admin-hotels-stat-info">
            <p>Total Hotels</p>
            <h3>{totalHotels}</h3>
            <span>Hotels in current results</span>
          </div>
        </div>

        <div className="admin-hotels-stat-card">
          <div className="admin-hotels-stat-icon hotel-stat-gold">
            <span>₹</span>
          </div>

          <div className="admin-hotels-stat-info">
            <p>Average Price</p>
            <h3>₹{formatPrice(averagePrice)}</h3>
            <span>Per night in current results</span>
          </div>
        </div>

        <div className="admin-hotels-stat-card">
          <div className="admin-hotels-stat-icon hotel-stat-green">
            <span>★</span>
          </div>

          <div className="admin-hotels-stat-info">
            <p>Average Rating</p>
            <h3>
              {ratedHotels.length
                ? averageRating.toFixed(1)
                : "—"}
              {ratedHotels.length > 0 && (
                <small className="admin-hotels-rating-max">
                  {" "}/ 5
                </small>
              )}
            </h3>
            <span>Hotels with a rating</span>
          </div>
        </div>
      </div>

      {/* SEARCH & FILTER */}
      <section className="admin-hotels-filter-card">
        <div className="admin-hotels-filter-heading">
          <div>
            <h4>Find a Hotel</h4>
            <p>Search and refine your hotel listings.</p>
          </div>

          <span className="admin-hotels-filter-label">
            SEARCH & FILTER
          </span>
        </div>

        <form onSubmit={handleSearch}>
          <div className="admin-hotels-filter-grid">
            <div className="admin-hotels-field hotel-search-field">
              <label htmlFor="hotel-search">Hotel Name</label>
              <input
                id="hotel-search"
                type="text"
                name="search"
                value={filters.search}
                onChange={handleChange}
                className="form-control"
                placeholder="Search hotel name..."
              />
            </div>

            <div className="admin-hotels-field">
              <label htmlFor="hotel-location">Location</label>
              <input
                id="hotel-location"
                type="text"
                name="location"
                value={filters.location}
                onChange={handleChange}
                className="form-control"
                placeholder="Enter location"
              />
            </div>

            <div className="admin-hotels-field">
              <label htmlFor="hotel-min-price">Min Price (₹)</label>
              <input
                id="hotel-min-price"
                type="number"
                name="minPrice"
                min="0"
                value={filters.minPrice}
                onChange={handleChange}
                className="form-control"
                placeholder="Minimum"
              />
            </div>

            <div className="admin-hotels-field">
              <label htmlFor="hotel-max-price">Max Price (₹)</label>
              <input
                id="hotel-max-price"
                type="number"
                name="maxPrice"
                min="0"
                value={filters.maxPrice}
                onChange={handleChange}
                className="form-control"
                placeholder="Maximum"
              />
            </div>

            <div className="admin-hotels-field">
              <label htmlFor="hotel-sort">Sort By</label>
              <select
                id="hotel-sort"
                name="sort"
                value={filters.sort}
                onChange={handleChange}
                className="form-select"
              >
                <option value="">Default order</option>
                <option value="priceLow">Price: Low to High</option>
                <option value="priceHigh">Price: High to Low</option>
                <option value="ratingHigh">Rating: High to Low</option>
                <option value="ratingLow">Rating: Low to High</option>
              </select>
            </div>
          </div>

          <div className="admin-hotels-filter-actions">
            <button
              type="button"
              className="admin-hotels-clear-btn"
              onClick={clearFilters}
            >
              Clear Filters
            </button>

            <button
              type="submit"
              className="admin-hotels-search-btn"
              disabled={loading}
            >
              {loading ? "Searching..." : "⌕ Search Hotels"}
            </button>
          </div>
        </form>
      </section>

      {/* HOTEL RESULTS */}
      <section className="admin-hotels-results">
        <div className="admin-hotels-results-header">
          <div>
            <span className="admin-hotels-eyebrow">
              PROPERTY COLLECTION
            </span>

            <h3>Available Hotels</h3>

            <p>Explore and manage your hotel properties.</p>
          </div>

          {!loading && (
            <span className="admin-hotels-count">
              {totalHotels} {totalHotels === 1 ? "Hotel" : "Hotels"}
            </span>
          )}
        </div>

        {loading ? (
          <div className="admin-hotels-status">
            <div className="admin-hotels-spinner" />
            <h5>Loading Hotels</h5>
            <p>Please wait while we load your properties.</p>
          </div>
        ) : hotels.length === 0 ? (
          <div className="admin-hotels-empty">
            <div className="admin-hotels-empty-icon">⌂</div>

            <h4>No Hotels Found</h4>

            <p>
              Try changing your search filters or add a new hotel
              to your collection.
            </p>

            <button
              type="button"
              className="admin-hotels-add-btn"
              onClick={() => setShowAddForm(true)}
            >
              + Add New Hotel
            </button>
          </div>
        ) : (
          <div className="row g-4 admin-hotels-card-grid">
            {hotels.map((hotel) => (
              <HotelCard key={hotel._id} hotel={hotel} />
            ))}
          </div>
        )}
      </section>

      {/* DELETE HOTEL LIST POPUP */}
      {showDeletePanel && (
        <div
          className="hotel-modal-overlay"
          onClick={closeDeletePanel}
        >
          <div
            className="hotel-modal-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-hotels-heading"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="hotel-modal-header">
              <div>
                <span className="hotel-modal-eyebrow">
                  STAYEASE · ADMINISTRATION
                </span>

                <h3 id="delete-hotels-heading">
                  Delete Hotel
                </h3>
              </div>

              <button
                type="button"
                className="hotel-modal-close"
                onClick={closeDeletePanel}
                disabled={deleting}
                aria-label="Close popup"
              >
                &times;
              </button>
            </div>

            <div className="hotel-modal-body">
              <p>Select the hotel you want to delete.</p>

              {deleteError && (
                <div className="alert alert-danger" role="alert">
                  {deleteError}
                </div>
              )}

              {hotels.length === 0 ? (
                <div className="alert alert-warning">
                  No hotels available to delete.
                </div>
              ) : (
                <div className="hotel-delete-list">
                  {hotels.map((hotel) => (
                    <div
                      className="hotel-delete-list-item"
                      key={hotel._id}
                    >
                      <div>
                        <strong>{hotel.hotelName}</strong>
                        <p>{hotel.location}</p>
                      </div>

                      <button
                        type="button"
                        className="btn btn-danger btn-sm"
                        disabled={deleting}
                        onClick={() => {
                          setDeleteError("");
                          setSelectedHotel(hotel);
                        }}
                      >
                        <FaTrash /> Delete
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION */}
      <DeleteConfirmModal
        show={Boolean(selectedHotel)}
        title="Delete Hotel?"
        message="Are you sure you want to delete this hotel?"
        itemName={selectedHotel?.hotelName || ""}
        loading={deleting}
        onCancel={() => {
          if (!deleting) {
            setSelectedHotel(null);
            setDeleteError("");
          }
        }}
        onConfirm={handleConfirmDelete}
      />

      {/* ADD HOTEL POPUP */}
      {showAddForm && (
        <div
          className="hotel-modal-overlay"
          onClick={() => setShowAddForm(false)}
        >
          <div
            className="hotel-modal-dialog"
            onClick={(event) => event.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-labelledby="add-hotel-modal-title"
          >
            <div className="hotel-modal-header">
              <div>
                <span className="hotel-modal-eyebrow">
                  STAYEASE · ADMINISTRATION
                </span>

                <h3 id="add-hotel-modal-title">
                  Add New Hotel
                </h3>
              </div>

              <button
                type="button"
                className="hotel-modal-close"
                onClick={() => setShowAddForm(false)}
                aria-label="Close popup"
              >
                &times;
              </button>
            </div>

            <div className="hotel-modal-body">
              <AddHotel
                refreshHotels={() => fetchHotels(filters)}
                onClose={() => setShowAddForm(false)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Hotels;