import { useEffect, useState } from "react";
import API from "../services/api";
import { toast } from "react-toastify";
import LoadingSpinner from "../components/LoadingSpinner";
import "../styles/AdminBookings.css";

function Bookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  const [searchUser, setSearchUser] = useState("");
  const [searchHotel, setSearchHotel] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      setLoading(true);

      const res = await API.get("/bookings");

      setBookings(res.data.bookings || []);
    } catch (err) {
      console.log(err);
      toast.error("Failed to load bookings");
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id, status) => {
    try {
      await API.put(`/bookings/status/${id}`, {
        status,
      });

      toast.success("Booking Status Updated");

      fetchBookings();
    } catch (err) {
      toast.error(err.response?.data?.message || "Update Failed");
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  const filteredBookings = bookings.filter((booking) => {
    const userMatch = (booking.userId?.name || "")
      .toLowerCase()
      .includes(searchUser.toLowerCase());

    const hotelMatch = (booking.hotelId?.hotelName || "")
      .toLowerCase()
      .includes(searchHotel.toLowerCase());

    const statusMatch =
      statusFilter === "" ||
      booking.bookingStatus === statusFilter;

    return userMatch && hotelMatch && statusMatch;
  });

  return (
    <div className="container-fluid admin-bookings-page">

      {/* PAGE HEADER */}
      <div className="admin-bookings-header">
        <div>
          <h2 className="admin-bookings-title">
            Manage Bookings
          </h2>

          <p className="admin-bookings-subtitle">
            Manage guest reservations, hotel stays and booking status.
          </p>
        </div>
      </div>

      {/* SEARCH AND FILTER */}
      <div className="admin-bookings-filters">

        <div className="admin-bookings-filter-group">
          <label className="admin-bookings-filter-label">
            Search User
          </label>

          <input
            type="text"
            className="form-control"
            placeholder="Enter guest name"
            value={searchUser}
            onChange={(e) => setSearchUser(e.target.value)}
          />
        </div>

        <div className="admin-bookings-filter-group">
          <label className="admin-bookings-filter-label">
            Search Hotel
          </label>

          <input
            type="text"
            className="form-control"
            placeholder="Enter hotel name"
            value={searchHotel}
            onChange={(e) => setSearchHotel(e.target.value)}
          />
        </div>

        <div className="admin-bookings-filter-group">
          <label className="admin-bookings-filter-label">
            Booking Status
          </label>

          <select
            className="form-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="">All Status</option>
            <option value="Booked">Booked</option>
            <option value="Checked In">Checked In</option>
            <option value="Checked Out">Checked Out</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>

        <div className="admin-bookings-filter-group">
          <label className="admin-bookings-filter-label">
            Reset Filters
          </label>

          <button
            type="button"
            className="admin-bookings-clear-btn"
            onClick={() => {
              setSearchUser("");
              setSearchHotel("");
              setStatusFilter("");
            }}
          >
            Clear Filters
          </button>
        </div>

      </div>

      {/* BOOKINGS TABLE CARD */}
      <div className="admin-bookings-card">

        <div className="admin-bookings-card-header">
          <h3 className="admin-bookings-card-title">
            Booking Reservations
          </h3>

          <span className="admin-bookings-count">
            {filteredBookings.length} Bookings
          </span>
        </div>

        <div className="admin-bookings-table-wrap">

          <table className="table admin-bookings-table">

            <thead>
              <tr>
                <th>User</th>
                <th>Hotel</th>
                <th>Room</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th>Total</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {filteredBookings.length === 0 ? (

                <tr>
                  <td colSpan="8" className="admin-bookings-empty-cell">
                    <div className="admin-bookings-empty">
                      <div className="admin-bookings-empty-icon">
                        &#128203;
                      </div>

                      <h3>No Bookings Found</h3>

                      <p>
                        Try changing your search terms or clearing the filters.
                      </p>
                    </div>
                  </td>
                </tr>

              ) : (

                filteredBookings.map((booking) => (

                  <tr key={booking._id}>

                    <td>
                      <span className="admin-bookings-user">
                        {booking.userId?.name || "N/A"}
                      </span>
                    </td>

                    <td>
                      <span className="admin-bookings-hotel">
                        {booking.hotelId?.hotelName || "N/A"}
                      </span>
                    </td>

                    <td>
                      <span className="admin-bookings-room">
                        {booking.roomId?.roomNumber || "N/A"}
                      </span>
                    </td>

                    <td>
                      <span className="admin-bookings-date">
                        {booking.checkIn
                          ? new Date(booking.checkIn).toLocaleDateString()
                          : "N/A"}
                      </span>
                    </td>

                    <td>
                      <span className="admin-bookings-date">
                        {booking.checkOut
                          ? new Date(booking.checkOut).toLocaleDateString()
                          : "N/A"}
                      </span>
                    </td>

                    <td>
                      <span className="admin-bookings-amount">
                        ₹ {Number(booking.totalAmount || 0).toLocaleString("en-IN")}
                      </span>
                    </td>

                    <td>
                      <span
                        className={`badge ${
                          booking.bookingStatus === "Booked"
                            ? "bg-success"
                            : booking.bookingStatus === "Checked In"
                            ? "bg-primary"
                            : booking.bookingStatus === "Checked Out"
                            ? "bg-dark"
                            : "bg-danger"
                        }`}
                      >
                        {booking.bookingStatus || "N/A"}
                      </span>
                    </td>

                    <td>
                      <select
                        className="form-select admin-bookings-action-select"
                        value={booking.bookingStatus}
                        onChange={(e) =>
                          updateStatus(booking._id, e.target.value)
                        }
                        aria-label={`Update booking status for ${
                          booking.userId?.name || "guest"
                        }`}
                      >
                        <option value="Booked">Booked</option>
                        <option value="Checked In">Checked In</option>
                        <option value="Checked Out">Checked Out</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>

                  </tr>

                ))

              )}
            </tbody>

          </table>

        </div>
      </div>

    </div>
  );
}

export default Bookings;