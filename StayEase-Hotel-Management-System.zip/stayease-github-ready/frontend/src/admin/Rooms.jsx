
import { useCallback, useEffect, useMemo, useState } from "react";

import RoomForm from "./RoomForm";
import RoomTable from "./RoomTable";
import { getRooms } from "../services/roomService";

import "../styles/AdminRooms.css";

function Rooms() {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  const loadRooms = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      const res = await getRooms();
      setRooms(res.data.rooms || []);
    } catch (err) {
      setError(
        err.response?.data?.message || "Failed to load rooms. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadRooms();
  }, [loadRooms]);

  const availableRooms = useMemo(
    () => rooms.filter((room) => room.available === true).length,
    [rooms]
  );

  const unavailableRooms = rooms.length - availableRooms;

  const averagePrice = useMemo(() => {
    if (rooms.length === 0) return 0;

    const total = rooms.reduce(
      (sum, room) => sum + (Number(room.price) || 0),
      0
    );

    return Math.round(total / rooms.length);
  }, [rooms]);

  const filteredRooms = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) return rooms;

    return rooms.filter((room) => {
      const roomNumber = String(room.roomNumber || "").toLowerCase();
      const roomType = String(room.roomType || "").toLowerCase();
      const hotelName = String(
        room.hotel?.hotelName ||
          room.hotelId?.hotelName ||
          room.hotelName ||
          ""
      ).toLowerCase();

      return (
        roomNumber.includes(query) ||
        roomType.includes(query) ||
        hotelName.includes(query)
      );
    });
  }, [rooms, search]);

  return (
    <main className="admin-rooms-page">
      {/* Page Header */}
      <header className="admin-rooms-header">
        <div className="admin-rooms-heading">
          <span className="admin-rooms-eyebrow">
            STAYEASE · PROPERTY MANAGEMENT
          </span>

          <h1>Room Management</h1>

          <p>
            Manage room inventory, pricing and availability across your hotels.
          </p>
        </div>

        <button
          type="button"
          className="admin-rooms-refresh-btn"
          onClick={loadRooms}
          disabled={loading}
        >
          <span className={loading ? "admin-rooms-spin" : ""}>↻</span>
          {loading ? "Refreshing..." : "Refresh Rooms"}
        </button>
      </header>

      {/* Summary Cards */}
      <section className="admin-rooms-stats">
        <article className="admin-rooms-stat-card">
          <div className="admin-rooms-stat-icon admin-rooms-icon-navy">
            <span>▦</span>
          </div>

          <div>
            <p>Total Rooms</p>
            <h3>{rooms.length}</h3>
            <span className="admin-rooms-stat-note">Registered inventory</span>
          </div>
        </article>

        <article className="admin-rooms-stat-card">
          <div className="admin-rooms-stat-icon admin-rooms-icon-green">
            <span>✓</span>
          </div>

          <div>
            <p>Available Rooms</p>
            <h3>{availableRooms}</h3>
            <span className="admin-rooms-stat-note">Marked as available</span>
          </div>
        </article>

        <article className="admin-rooms-stat-card">
          <div className="admin-rooms-stat-icon admin-rooms-icon-red">
            <span>−</span>
          </div>

          <div>
            <p>Unavailable Rooms</p>
            <h3>{unavailableRooms}</h3>
            <span className="admin-rooms-stat-note">Not available to book</span>
          </div>
        </article>

        <article className="admin-rooms-stat-card">
          <div className="admin-rooms-stat-icon admin-rooms-icon-gold">
            <span>₹</span>
          </div>

          <div>
            <p>Average Nightly Price</p>
            <h3>
              ₹{averagePrice.toLocaleString("en-IN")}
            </h3>
            <span className="admin-rooms-stat-note">Across listed rooms</span>
          </div>
        </article>
      </section>

      {/* Add Room Form */}
      <section className="admin-rooms-form-section">
        <div className="admin-rooms-section-heading">
          <div>
            <span className="admin-rooms-eyebrow">INVENTORY SETUP</span>
            <h2>Add a New Room</h2>
            <p>Choose a property and configure its room details.</p>
          </div>
        </div>

        <RoomForm refreshRooms={loadRooms} />
      </section>

      {/* Rooms List */}
      <section className="admin-rooms-list-section">
        <div className="admin-rooms-list-header">
          <div>
            <span className="admin-rooms-eyebrow">YOUR INVENTORY</span>
            <h2>All Rooms</h2>
            <p>Review the rooms registered in your properties.</p>
          </div>

          <span className="admin-rooms-count">
            {filteredRooms.length}{" "}
            {filteredRooms.length === 1 ? "ROOM" : "ROOMS"}
          </span>
        </div>

        <div className="admin-rooms-search">
          <span className="admin-rooms-search-icon">⌕</span>

          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by room number, type or hotel..."
            aria-label="Search rooms"
          />

          {search && (
            <button
              type="button"
              onClick={() => setSearch("")}
              aria-label="Clear search"
            >
              ×
            </button>
          )}
        </div>

        {loading ? (
          <div className="admin-rooms-state">
            <span className="admin-rooms-loader" />
            <h3>Loading Rooms</h3>
            <p>Please wait while we retrieve your room inventory.</p>
          </div>
        ) : error ? (
          <div className="admin-rooms-state admin-rooms-error-state">
            <div className="admin-rooms-state-icon">!</div>
            <h3>Unable to Load Rooms</h3>
            <p>{error}</p>

            <button
              type="button"
              className="admin-rooms-retry-btn"
              onClick={loadRooms}
            >
              Try Again
            </button>
          </div>
        ) : filteredRooms.length === 0 ? (
          <div className="admin-rooms-state">
            <div className="admin-rooms-state-icon">▦</div>
            <h3>{search ? "No Matching Rooms" : "No Rooms Added Yet"}</h3>
            <p>
              {search
                ? "Try another room number, room type or hotel name."
                : "Add a new room using the form above to see it listed here."}
            </p>

            {search && (
              <button
                type="button"
                className="admin-rooms-retry-btn"
                onClick={() => setSearch("")}
              >
                Clear Search
              </button>
            )}
          </div>
        ) : (
          <div className="admin-rooms-table-wrap">
            <RoomTable
              rooms={filteredRooms}
              refreshRooms={loadRooms}
            />
          </div>
        )}
      </section>
    </main>
  );
}

export default Rooms;
