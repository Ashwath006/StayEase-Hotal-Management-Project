import { useState } from "react";
import { FaTrash } from "react-icons/fa";
import { toast } from "react-toastify";
import { deleteRoom } from "../services/roomService";
import DeleteConfirmModal from "../components/DeleteConfirmModal";
import "../styles/AdminRooms.css";

function RoomTable({ rooms = [], refreshRooms }) {
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const handleConfirmDelete = async () => {
    if (!selectedRoom || deleting) return;

    try {
      setDeleting(true);

      await deleteRoom(selectedRoom._id);

      toast.success("Room deleted successfully!");

      setSelectedRoom(null);

      if (refreshRooms) {
        await refreshRooms();
      }
    } catch (err) {
      console.error("Failed to delete room:", err);

      toast.error(
        err.response?.data?.message ||
          "Failed to delete room. Please try again."
      );
    } finally {
      setDeleting(false);
    }
  };

  return (
    <>
      <div className="room-table-container">
        <table className="room-management-table">
          <thead>
            <tr>
              <th>Hotel</th>
              <th>Room No.</th>
              <th>Room Type</th>
              <th>Price / Night</th>
              <th>Capacity</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {rooms.length === 0 ? (
              <tr>
                <td colSpan="7" className="room-table-empty">
                  <div className="room-table-empty-icon">
                    ▦
                  </div>

                  <strong>No Rooms Found</strong>

                  <p>
                    No rooms match your current search.
                  </p>
                </td>
              </tr>
            ) : (
              rooms.map((room) => (
                <tr key={room._id}>
                  <td>
                    <div className="room-table-hotel">
                      <span className="room-table-hotel-icon">
                        ⌂
                      </span>

                      <span>
                        {room.hotel?.hotelName ||
                          room.hotelId?.hotelName ||
                          room.hotelName ||
                          "N/A"}
                      </span>
                    </div>
                  </td>

                  <td>
                    <span className="room-table-number">
                      {room.roomNumber || "N/A"}
                    </span>
                  </td>

                  <td>
                    <span className="room-table-type">
                      {room.roomType || "Standard"}
                    </span>
                  </td>

                  <td>
                    <span className="room-table-price">
                      ₹
                      {(Number(room.price) || 0).toLocaleString(
                        "en-IN"
                      )}
                    </span>
                  </td>

                  <td>
                    <span className="room-table-capacity">
                      {room.capacity ?? 0} Guests
                    </span>
                  </td>

                  <td>
                    <span
                      className={`room-table-status ${
                        room.available
                          ? "room-table-status-available"
                          : "room-table-status-booked"
                      }`}
                    >
                      <span className="room-table-status-dot" />

                      {room.available
                        ? "Available"
                        : "Booked"}
                    </span>
                  </td>

                  <td>
                    <button
                      type="button"
                      className="room-table-delete-btn"
                      onClick={() => setSelectedRoom(room)}
                      disabled={deleting}
                      aria-label={`Delete room ${
                        room.roomNumber || ""
                      }`}
                    >
                      <FaTrash /> Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <DeleteConfirmModal
        show={Boolean(selectedRoom)}
        title="Delete Room?"
        message="Are you sure you want to delete this room?"
        itemName={
          selectedRoom
            ? `Room ${selectedRoom.roomNumber || "N/A"}`
            : ""
        }
        loading={deleting}
        onCancel={() => {
          if (!deleting) {
            setSelectedRoom(null);
          }
        }}
        onConfirm={handleConfirmDelete}
      />
    </>
  );
}

export default RoomTable;