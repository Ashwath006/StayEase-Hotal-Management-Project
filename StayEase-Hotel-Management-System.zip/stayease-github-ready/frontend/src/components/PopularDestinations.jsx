
import { Link } from "react-router-dom";
import "../styles/popularDestinations.css";

function PopularDestinations() {
    const destinations = [
        {
            name: "Chennai",
            hotels: 12,
            image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=85",
        },
        {
            name: "Ooty",
            hotels: 8,
            image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=900&q=85",
        },
        {
            name: "Goa",
            hotels: 15,
            image: "https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=900&q=85",
        },
        {
            name: "Bangalore",
            hotels: 10,
            image: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=900&q=85",
        },
        {
            name: "Munnar",
            hotels: 12,
            image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=900&q=85",
        },
        {
            name: "Kodaikanal",
            hotels: 7,
            image: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=85",
        },
    ];

    return (
        <section className="popular-destinations-section">
            <div className="container">

                <div className="destinations-heading-row">
                    <div className="destinations-heading">
                        <span className="destinations-section-tag">
                            Discover Your Next Escape
                        </span>

                        <h2 className="destinations-title">
                            Popular <span>Destinations</span>
                        </h2>

                        <p className="destinations-subtitle">
                            Explore beautiful destinations and find the perfect
                            stay for your next memorable journey.
                        </p>
                    </div>

                    <Link
                        to="/hotels"
                        className="destinations-explore-all"
                    >
                        Explore All <span aria-hidden="true">→</span>
                    </Link>
                </div>

                <div className="row g-4">
                    {destinations.map((item) => (
                        <div
                            className="col-lg-4 col-md-6"
                            key={item.name}
                        >
                            <Link
                                to={`/hotels?location=${encodeURIComponent(item.name)}`}
                                className="destination-link"
                                aria-label={`Explore hotels in ${item.name}`}
                            >
                                <article className="destination-card">

                                    <div className="destination-image-wrap">
                                        <img
                                            src={item.image}
                                            alt={`${item.name} destination`}
                                            className="destination-image"
                                            loading="lazy"
                                        />

                                        <div className="destination-image-overlay" />

                                        <span className="destination-location-badge">
                                            <span aria-hidden="true">✦</span>
                                            Featured Destination
                                        </span>

                                        <span className="destination-image-name">
                                            {item.name}
                                        </span>
                                    </div>

                                    <div className="destination-content">
                                        <div className="destination-info">
                                            <h3>{item.name}</h3>

                                            <p className="destination-hotel-count">
                                                <span aria-hidden="true">⌂</span>
                                                {item.hotels}+ Hotels
                                            </p>
                                        </div>

                                        <span className="destination-explore-btn">
                                            Explore <span aria-hidden="true">↗</span>
                                        </span>
                                    </div>

                                </article>
                            </Link>
                        </div>
                    ))}
                </div>

            </div>
        </section>
    );
}

export default PopularDestinations;
