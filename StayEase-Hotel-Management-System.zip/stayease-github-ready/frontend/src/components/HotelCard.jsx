
import { useState } from "react";
import { Link } from "react-router-dom";
import { FaMapMarkerAlt, FaStar, FaHeart, FaArrowRight } from "react-icons/fa";
import "../styles/hotelCard.css";

function HotelCard({ hotel }) {
  const [isFavorite, setIsFavorite] = useState(false);

  const hotelImage =
    hotel.images && hotel.images.length > 0
      ? hotel.images[0]
      : "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=900&q=85";

  return (
    <div className="col-lg-4 col-md-6 mb-4 st-hotel-card-column">
      <article className="st-hotel-card">
        <div className="st-hotel-card-image-wrap">
          <img
            src={hotelImage}
            alt={hotel.hotelName || "Hotel"}
            className="st-hotel-card-image"
            loading="lazy"
          />

          <div className="st-hotel-card-image-shade"></div>

          <span className="st-hotel-card-tag">
            <span className="st-hotel-card-tag-dot"></span>
            STAYEASE SELECT
          </span>

          <button
            type="button"
            className={`st-hotel-favorite-btn ${
              isFavorite ? "is-favorite" : ""
            }`}
            aria-label={
              isFavorite ? "Remove from favorites" : "Add to favorites"
            }
            aria-pressed={isFavorite}
            onClick={() => setIsFavorite((previous) => !previous)}
          >
            <FaHeart />
          </button>

          <div className="st-hotel-card-image-caption">
            <span className="st-hotel-card-location">
              <FaMapMarkerAlt />
              {hotel.location || "Destination"}
            </span>
          </div>
        </div>

        <div className="st-hotel-card-body">
          <div className="st-hotel-card-heading">
            <div className="st-hotel-card-name-wrap">
              <span className="st-hotel-card-overline">
                YOUR NEXT GETAWAY
              </span>

              <h3 className="st-hotel-card-title">
                {hotel.hotelName || "Beautiful Hotel"}
              </h3>
            </div>

            <div className="st-hotel-rating">
              <FaStar />
              <span>{Number(hotel.rating || 0).toFixed(1)}</span>
            </div>
          </div>

          <div className="st-hotel-card-divider"></div>

          <div className="st-hotel-card-bottom">
            <div className="st-hotel-price-wrap">
              <span className="st-hotel-price-label">Starting from</span>

              <div className="st-hotel-price">
                <span className="st-hotel-currency">₹</span>
                {Number(hotel.price || 0).toLocaleString("en-IN")}
              </div>

              <span className="st-hotel-price-period">per night</span>
            </div>

            <Link
              to={`/hotel/${hotel._id}`}
              className="st-hotel-details-btn"
              aria-label={`View details for ${hotel.hotelName}`}
            >
              <span>Explore Stay</span>
              <FaArrowRight />
            </Link>
          </div>
        </div>
      </article>
    </div>
  );
}

export default HotelCard;
