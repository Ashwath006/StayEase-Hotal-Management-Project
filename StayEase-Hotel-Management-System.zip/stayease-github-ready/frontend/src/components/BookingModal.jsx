import React from "react";
import "../styles/BookingModal.css";

function BookingModal({ booking, onClose }) {
  if (!booking) return null;

  const transactionId = `TXN${String(booking._id || "")
    .slice(-8)
    .toUpperCase()}`;

  const hotel = booking.hotelId || {};
  const room = booking.roomId || {};

  const formatDate = (date) => {
    if (!date) return "N/A";

    const parsedDate = new Date(date);

    if (Number.isNaN(parsedDate.getTime())) return "N/A";

    return parsedDate.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  const formatAmount = (amount) =>
    Number(amount || 0).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

  const rawPaymentStatus =
    booking.paymentStatus ||
    booking.payment?.status ||
    (booking.isPaid === true ? "SUCCESS" : "PENDING");

  const paymentStatus = String(rawPaymentStatus).toUpperCase();

  const paymentSuccess = [
    "SUCCESS",
    "PAID",
    "COMPLETED",
  ].includes(paymentStatus);

  const hotelImage =
    (Array.isArray(hotel.images) && hotel.images[0]) ||
    hotel.image ||
    "https://images.unsplash.com/photo-1566073771259-6a8506099945";

  const bookingStatus = booking.bookingStatus || "Pending";

  const printBooking = () => {
    window.print();
  };

  return (
    <div
      className="st-bm-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          onClose?.();
        }
      }}
    >
      <div
        className="st-bm-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="st-bm-title"
      >
        <div className="st-bm-content">
          {/* ROYAL HEADER */}
          <header className="st-bm-header">
            <div>
              <p className="st-bm-eyebrow">
                STAYEASE · ROYAL COLLECTION
              </p>

              <h4 className="st-bm-title" id="st-bm-title">
                Booking Receipt
              </h4>

              <p className="st-bm-subtitle">
                Your stay, beautifully confirmed.
              </p>
            </div>

            <button
              type="button"
              className="st-bm-close"
              onClick={onClose}
              aria-label="Close booking receipt"
            >
              &times;
            </button>
          </header>

          {/* RECEIPT BODY */}
          <div className="st-bm-body">
            <div className="st-bm-layout">
              {/* HOTEL IMAGE AND QR */}
              <aside className="st-bm-visual">
                <img
                  src={hotelImage}
                  className="st-bm-hotel-image"
                  alt={hotel.hotelName || "Hotel"}
                  onError={(event) => {
                    event.currentTarget.onerror = null;
                    event.currentTarget.src =
                      "https://images.unsplash.com/photo-1566073771259-6a8506099945";
                  }}
                />

                <div className="st-bm-hotel-caption">
                  <span className="st-bm-gold-line" />
                  <p className="st-bm-visual-label">YOUR DESTINATION</p>
                  <h5>{hotel.hotelName || "Hotel Details"}</h5>
                  <p className="st-bm-location">
                    {hotel.location || "Location unavailable"}
                  </p>
                </div>

                <div className="st-bm-qr-section">
                  <h6>Booking Verification</h6>

                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(
                      booking._id || ""
                    )}`}
                    alt="Booking verification QR code"
                    className="st-bm-qr"
                  />

                  <p className="st-bm-qr-caption">
                    Scan to verify your booking
                  </p>
                </div>
              </aside>

              {/* BOOKING DETAILS */}
              <section className="st-bm-information">
                <div className="st-bm-section-heading">
                  <div>
                    <p className="st-bm-eyebrow-dark">
                      RESERVATION DETAILS
                    </p>
                    <h3 className="st-bm-hotel-name">
                      {hotel.hotelName || "Hotel Details"}
                    </h3>
                    <p className="st-bm-location">
                      {hotel.location || "Location unavailable"}
                    </p>
                  </div>

                  <span
                    className={`st-bm-badge ${
                      paymentSuccess
                        ? "st-bm-badge-success"
                        : "st-bm-badge-pending"
                    }`}
                  >
                    {paymentStatus}
                  </span>
                </div>

                <div className="st-bm-divider" />

                <h6 className="st-bm-section-title">
                  Your Stay
                </h6>

                <div className="st-bm-detail-grid">
                  <div className="st-bm-detail-item">
                    <span className="st-bm-detail-label">
                      Room Number
                    </span>
                    <p className="st-bm-detail-value">
                      {room.roomNumber || "N/A"}
                    </p>
                  </div>

                  <div className="st-bm-detail-item">
                    <span className="st-bm-detail-label">
                      Room Type
                    </span>
                    <p className="st-bm-detail-value">
                      {room.roomType || "N/A"}
                    </p>
                  </div>

                  <div className="st-bm-detail-item">
                    <span className="st-bm-detail-label">
                      Check In
                    </span>
                    <p className="st-bm-detail-value">
                      {formatDate(booking.checkIn)}
                    </p>
                  </div>

                  <div className="st-bm-detail-item">
                    <span className="st-bm-detail-label">
                      Check Out
                    </span>
                    <p className="st-bm-detail-value">
                      {formatDate(booking.checkOut)}
                    </p>
                  </div>

                  <div className="st-bm-detail-item">
                    <span className="st-bm-detail-label">
                      Guests
                    </span>
                    <p className="st-bm-detail-value">
                      {booking.guests || 1} Guest(s)
                    </p>
                  </div>

                  <div className="st-bm-detail-item">
                    <span className="st-bm-detail-label">
                      Booking Status
                    </span>
                    <p className="st-bm-detail-value">
                      <span className="st-bm-badge st-bm-badge-status">
                        {bookingStatus}
                      </span>
                    </p>
                  </div>
                </div>

                {/* PAYMENT SUMMARY */}
                <div className="st-bm-summary">
                  <div className="st-bm-summary-top">
                    <span className="st-bm-summary-label">
                      TOTAL AMOUNT
                    </span>
                    <span className="st-bm-summary-note">
                      StayEase Reservation
                    </span>
                  </div>

                  <div className="st-bm-summary-row">
                    <span className="st-bm-summary-label">
                      Amount Paid
                    </span>

                    <span className="st-bm-amount">
                      ₹{formatAmount(booking.totalAmount)}
                    </span>
                  </div>

                  <div className="st-bm-summary-row">
                    <span className="st-bm-summary-label">
                      Transaction ID
                    </span>

                    <span className="st-bm-transaction">
                      {transactionId}
                    </span>
                  </div>
                </div>

                <p className="st-bm-note">
                  Please retain this receipt for your records.
                  Thank you for choosing StayEase.
                </p>
              </section>
            </div>
          </div>

          {/* FOOTER */}
          <footer className="st-bm-footer">
            <button
              type="button"
              className="st-bm-btn st-bm-btn-close"
              onClick={onClose}
            >
              Close
            </button>

            <button
              type="button"
              className="st-bm-btn st-bm-btn-print"
              onClick={printBooking}
            >
              <span aria-hidden="true">▤</span>
              Print Receipt
            </button>
          </footer>
        </div>
      </div>
    </div>
  );
}

export default BookingModal;