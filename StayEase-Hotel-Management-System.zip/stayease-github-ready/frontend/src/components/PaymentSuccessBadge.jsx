
function PaymentSuccessBadge() {
  return (
    <span className="se-payment-success-badge">
      <span className="se-payment-badge-tick">✓</span>
      Payment Verified Successfully
    </span>
  );
}

export default PaymentSuccessBadge;
