import { useEffect, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";

import {
  FaHotel,
  FaUserCircle,
  FaBars,
  FaTimes,
  FaSignOutAlt,
  FaUser,
  FaClipboardList,
  FaTachometerAlt,
  FaMoon,
  FaSun,
} from "react-icons/fa";

import "../styles/navbar.css";

function Navbar() {
  const navigate = useNavigate();

  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const [darkMode, setDarkMode] = useState(
    localStorage.getItem("theme") === "dark"
  );

  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("user") || "null");
    } catch {
      return null;
    }
  });

  // Theme management
  useEffect(() => {
    document.body.classList.toggle("dark-mode", darkMode);

    localStorage.setItem("theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  // Navbar scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };

    handleScroll();

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  // Sync user data when navigating between pages
  useEffect(() => {
    const syncUser = () => {
      try {
        setUser(JSON.parse(localStorage.getItem("user") || "null"));
      } catch {
        setUser(null);
      }
    };

    window.addEventListener("storage", syncUser);
    window.addEventListener("auth-change", syncUser);

    return () => {
      window.removeEventListener("storage", syncUser);
      window.removeEventListener("auth-change", syncUser);
    };
  }, []);

  const closeMenu = () => {
    setMenuOpen(false);
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    setUser(null);
    closeMenu();

    window.dispatchEvent(new Event("auth-change"));

    navigate("/login");
  };

  const navLinkClass = ({ isActive }) =>
    `se-navbar-link${isActive ? " active" : ""}`;

  return (
    <nav
      className={`navbar navbar-expand-lg premium-navbar fixed-top ${
        scrolled ? "navbar-scrolled" : ""
      }`}
    >
      <div className="container se-navbar-container">

        {/* BRAND LOGO */}
        <Link
          to="/"
          className="navbar-brand premium-logo"
          onClick={closeMenu}
          aria-label="StayEase Home"
        >
          <span className="se-logo-icon">
            <FaHotel />
          </span>

          <span className="se-logo-content">
            <span className="se-logo-title">
              Stay<span>Ease</span>
            </span>

            <span className="se-logo-subtitle">
              LUXURY HOSPITALITY
            </span>
          </span>
        </Link>

        {/* MOBILE MENU BUTTON */}
        <button
          className="se-navbar-toggler"
          type="button"
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-label={menuOpen ? "Close navigation" : "Open navigation"}
          aria-expanded={menuOpen}
          aria-controls="se-navbar-menu"
        >
          {menuOpen ? <FaTimes /> : <FaBars />}
        </button>

        {/* NAVIGATION + ACTIONS */}
        <div
          id="se-navbar-menu"
          className={`collapse navbar-collapse se-navbar-menu ${
            menuOpen ? "show" : ""
          }`}
        >
          {/* NAVIGATION LINKS */}
          <ul className="navbar-nav se-navbar-links">
            <li className="nav-item">
              <NavLink
                to="/"
                end
                className={navLinkClass}
                onClick={closeMenu}
              >
                Home
              </NavLink>
            </li>

            <li className="nav-item">
              <NavLink
                to="/hotels"
                className={navLinkClass}
                onClick={closeMenu}
              >
                Hotels
              </NavLink>
            </li>

            <li className="nav-item">
              <NavLink
                to="/about"
                className={navLinkClass}
                onClick={closeMenu}
              >
                About
              </NavLink>
            </li>

            <li className="nav-item">
              <NavLink
                to="/contact"
                className={navLinkClass}
                onClick={closeMenu}
              >
                Contact
              </NavLink>
            </li>
          </ul>

          {/* RIGHT SIDE ACTIONS */}
          <div className="se-navbar-actions">
{/* 
            <button
              type="button"
              className="se-theme-toggle"
              onClick={() => setDarkMode((prev) => !prev)}
              aria-label={
                darkMode ? "Switch to light mode" : "Switch to dark mode"
              }
              title={darkMode ? "Light mode" : "Dark mode"}
            >
              {darkMode ? <FaSun /> : <FaMoon />}
            </button> */}

            {user ? (
              /* LOGGED-IN USER */
              <div className="dropdown se-user-dropdown">
                <button
                  type="button"
                  className="se-user-button dropdown-toggle"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <FaUserCircle className="se-user-avatar" />

                  <span className="se-user-name">
                    {user.name || "My Account"}
                  </span>
                </button>

                <ul className="dropdown-menu dropdown-menu-end se-user-menu">
                  <li className="se-user-menu-header">
                    <FaUserCircle className="se-user-menu-avatar" />

                    <div className="se-user-menu-details">
                      <strong>{user.name || "Guest"}</strong>
                      <small>{user.email || ""}</small>
                    </div>
                  </li>

                  <li>
                    <Link
                      to="/profile"
                      className="dropdown-item"
                      onClick={closeMenu}
                    >
                      <FaUser />
                      <span>My Profile</span>
                    </Link>
                  </li>

                  <li>
                    <Link
                      to="/my-bookings"
                      className="dropdown-item"
                      onClick={closeMenu}
                    >
                      <FaClipboardList />
                      <span>My Bookings</span>
                    </Link>
                  </li>

                  {user.role === "admin" && (
                    <li>
                      <Link
                        to="/admin"
                        className="dropdown-item"
                        onClick={closeMenu}
                      >
                        <FaTachometerAlt />
                        <span>Admin Dashboard</span>
                      </Link>
                    </li>
                  )}

                  <li>
                    <hr className="dropdown-divider" />
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item se-logout-button"
                      onClick={logout}
                    >
                      <FaSignOutAlt />
                      <span>Logout</span>
                    </button>
                  </li>
                </ul>
              </div>
            ) : (
              /* GUEST ACTIONS */
              <div className="se-auth-buttons">
                <Link
                  to="/login"
                  className="se-login-button"
                  onClick={closeMenu}
                >
                  Login
                </Link>

                <Link
                  to="/register"
                  className="se-register-button"
                  onClick={closeMenu}
                >
                  Register
                  <span className="se-register-arrow">↗</span>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;