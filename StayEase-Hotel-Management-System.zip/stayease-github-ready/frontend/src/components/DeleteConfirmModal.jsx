import { useEffect } from "react";
import { createPortal } from "react-dom";
import { FaTrashAlt, FaTimes } from "react-icons/fa";
import "../styles/DeleteConfirmModal.css";

function DeleteConfirmModal({
  show,
  title = "Are you sure?",
  message = "Are you sure you want to delete this item?",
  itemName = "",
  loading = false,
  onConfirm,
  onCancel,
}) {
  useEffect(() => {
    if (!show) return;

    const previousOverflow = document.body.style.overflow;

    const handleKeyDown = (event) => {
      if (event.key === "Escape" && !loading) {
        onCancel?.();
      }
    };

    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show, loading, onCancel]);

  if (!show) return null;

  return createPortal(
    <div
      className="se-delete-overlay"
      onMouseDown={(event) => {
        if (
          event.target === event.currentTarget &&
          !loading
        ) {
          onCancel?.();
        }
      }}
    >
      <div
        className="se-delete-modal"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="se-delete-title"
        aria-describedby="se-delete-message"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <button
          type="button"
          className="se-delete-close"
          onClick={onCancel}
          disabled={loading}
          aria-label="Close confirmation"
        >
          <FaTimes />
        </button>

        <div className="se-delete-icon">
          <FaTrashAlt />
        </div>

        <span className="se-delete-eyebrow">
          STAYEASE ADMINISTRATION
        </span>

        <h2 id="se-delete-title">{title}</h2>

        <p id="se-delete-message">
          {itemName
            ? `Are you sure you want to delete "${itemName}"?`
            : message}
        </p>

        <p className="se-delete-warning">
          This action cannot be undone.
        </p>

        <div className="se-delete-actions">
          <button
            type="button"
            className="se-delete-cancel"
            onClick={onCancel}
            disabled={loading}
          >
            Cancel
          </button>

          <button
            type="button"
            className="se-delete-confirm"
            onClick={onConfirm}
            disabled={loading}
          >
            {loading ? (
              <>
                <span className="se-delete-spinner" />
                Deleting...
              </>
            ) : (
              <>
                <FaTrashAlt />
                Confirm Delete
              </>
            )}
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}

export default DeleteConfirmModal;