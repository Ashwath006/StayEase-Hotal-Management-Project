import { Link } from "react-router-dom";
import {
  FaHotel,
  FaPhoneAlt,
  FaEnvelope,
  FaMapMarkerAlt,
  FaFacebookF,
  FaInstagram,
  FaTwitter,
  FaLinkedinIn,
  FaArrowRight
} from "react-icons/fa";
function Footer() {
  return (
    <footer className="footer">

      <div className="container">

        <div className="row gy-5">

          <div className="col-lg-4 col-md-6">

            <div className="footer-brand">

              <h2>

                <FaHotel className="me-2 footer-logo-icon" />

                StayEase

              </h2>

              <p>

                Experience luxury hotel booking with carefully
                selected premium stays, secure reservations,
                and exceptional hospitality around the world.

              </p>

              <div className="footer-social">

                <a href="#">
                  <FaFacebookF />
                </a>

                <a href="#">
                  <FaInstagram />
                </a>

                <a href="#">
                  <FaTwitter />
                </a>

                <a href="#">
                  <FaLinkedinIn />
                </a>

              </div>

            </div>

          </div>

          <div className="col-lg-2 col-md-6">

            <h5>Quick Links</h5>

            <ul>

              <li>
                <Link to="/">
                  <FaArrowRight className="me-2" />
                  Home
                </Link>
              </li>

              <li>
                <Link to="/hotels">
                  <FaArrowRight className="me-2" />
                  Hotels
                </Link>
              </li>

              <li>
                <Link to="/about">
                  <FaArrowRight className="me-2" />
                  About
                </Link>
              </li>

              <li>
                <Link to="/contact">
                  <FaArrowRight className="me-2" />
                  Contact
                </Link>
              </li>

            </ul>

          </div>
          <div className="col-lg-3 col-md-6">

            <h5>Explore</h5>

            <ul>

              <li>
                <Link to="/hotels">
                  Luxury Hotels
                </Link>
              </li>

              <li>
                <Link to="/hotels">
                  Beach Resorts
                </Link>
              </li>

              <li>
                <Link to="/hotels">
                  Mountain Retreats
                </Link>
              </li>

              <li>
                <Link to="/hotels">
                  City Hotels
                </Link>
              </li>

            </ul>

          </div>
          <div className="col-lg-3 col-md-6">

            <h5>Contact Us</h5>

            <div className="footer-contact">

              <p>

                <FaPhoneAlt className="me-3" />
                <Link to="/">
                  +919442850358
                </Link>
              </p>

              <p>

                <FaEnvelope className="me-3" />
                <Link to="https://mail.google.com/mail/u/0/#inbox?compose=new">
                support@stayease.com
                </Link>

              </p>

              <p>

                <FaMapMarkerAlt className="me-3" />

                Chennai, Tamil Nadu, India

              </p>

            </div>

          </div>

        </div>

        <div className="footer-bottom">

          <p>

            © {new Date().getFullYear()} StayEase.
            All Rights Reserved.

          </p>

          <div className="footer-policy">

            <Link to="/privacy">
              Privacy Policy
            </Link>

            <Link to="/terms">
              Terms & Conditions
            </Link>

          </div>

        </div>

      </div>

    </footer>
  );
}

export default Footer;