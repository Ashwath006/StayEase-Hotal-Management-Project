import { useEffect } from "react";
import { createPortal } from "react-dom";
import "../styles/ToastNotification.css";

function ToastNotification({
  message,
  type = "success",
  show,
  onClose,
}) {
  useEffect(() => {
    if (!show) return;

    const timer = setTimeout(() => {
      onClose?.();
    }, 3500);

    return () => clearTimeout(timer);
  }, [show, onClose]);

  if (!show) return null;

  return createPortal(
    <div className={`se-toast se-toast-${type}`}>
      <div className="se-toast-icon">
        {type === "success" ? "✓" : "!"}
      </div>

      <div className="se-toast-content">
        <h6>
          {type === "success" ? "Success!" : "Notice"}
        </h6>
        <p>{message}</p>
      </div>

      <button
        type="button"
        className="se-toast-close"
        onClick={onClose}
        aria-label="Close notification"
      >
        ×
      </button>
    </div>,
    document.body
  );
}

export default ToastNotification;