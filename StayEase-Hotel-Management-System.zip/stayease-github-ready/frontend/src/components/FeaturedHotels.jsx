import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";

import {
  FaMapMarkerAlt,
  FaStar,
  FaHeart,
  FaWifi,
  FaSwimmingPool,
  FaParking,
  FaArrowRight,
} from "react-icons/fa";

function FeaturedHotels() {

  const [hotels, setHotels] = useState([]);

  const [loading, setLoading] = useState(true);

  useEffect(() => {

    loadHotels();

  }, []);

  const loadHotels = async () => {

    try {

      const res = await API.get("/hotels");

      setHotels(res.data.hotels.slice(0,6));

    }

    catch(err){

      console.log(err);

    }

    finally{

      setLoading(false);

    }

  };

  if(loading){

    return(

      <section className="featured-hotels-section">

        <div className="container">

          <div className="text-center py-5">

            <div className="spinner-border text-primary"></div>

          </div>

        </div>

      </section>

    );

  }

  return(

<section className="featured-hotels-section">

<div className="container">

<div className="section-heading text-center mb-5">

<span className="section-tag">

FEATURED HOTELS

</span>

<h2>

Luxury Hotels For Your Next Stay

</h2>

<p>

Discover handpicked hotels with premium comfort,
world-class hospitality and unforgettable experiences.

</p>

</div>

<div className="row g-4">
          {hotels.map((hotel) => (

          <div
            className="col-xl-4 col-lg-4 col-md-6"
            key={hotel._id}
          >

            <div className="premium-hotel-card reveal">

              {/* IMAGE */}

<div className="hotel-image">

  {/* Featured Badge */}

  <div className="featured-badge">

    ⭐ Featured

  </div>

  {/* Wishlist */}

  <button className="wishlist-btn">

    <FaHeart />

  </button>

  <img
    src={
      hotel.images && hotel.images.length > 0
        ? hotel.images[0]
        : "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200"
    }
    alt={hotel.hotelName}
  />

  {/* Rating */}

  <div className="rating-badge">

    <FaStar />

    <span>

      {hotel.rating || "4.8"}

    </span>

  </div>

</div>              {/* BODY */}

              <div className="hotel-content">

                <h4 className="hotel-title">

  {hotel.hotelName}

</h4>

                <p className="hotel-location">

                  <FaMapMarkerAlt className="me-2 text-danger" />

                  {hotel.location}

                </p>

                {/* Amenities */}

                <div className="hotel-features">

                  <span>

                    <FaWifi />

                    WiFi

                  </span>

                  <span>

                    <FaSwimmingPool />

                    Pool

                  </span>

                  <span>

                    <FaParking />

                    Parking

                  </span>

                </div>

                {/* Footer */}

                <div className="hotel-footer">

                  <div>

                    <small>

                      Starting From

                    </small>

                    <h3>

                      ₹{hotel.price}

                      <span>

                        /night

                      </span>

                    </h3>

                  </div>

                  <Link
                    to={`/hotel/${hotel._id}`}
                    className="book-btn"
                  >

                    Book Now

                    <FaArrowRight className="ms-2" />

                  </Link>

                </div>

              </div>

            </div>

          </div>

        ))}

      </div>

           <div className="text-center mt-5">

        <Link
          to="/hotels"
          className="btn premium-outline-btn px-5 py-3"
        >

          Explore All Hotels

        </Link>

      </div>

    </div>

</section>

  );

}

export default FeaturedHotels;