import API from "../services/api";
import { toast } from "react-toastify";

/* =========================
   API HELPERS
========================= */

export const apiGet = async (url) => {
  try {
    const res = await API.get(url);
    return res.data;
  } catch (err) {
    toast.error(err.response?.data?.message || "API Error");
    return null;
  }
};

export const apiPost = async (url, body) => {
  try {
    const res = await API.post(url, body);
    toast.success(res.data.message || "Success");
    return res.data;
  } catch (err) {
    toast.error(err.response?.data?.message || "API Error");
    return null;
  }
};

export const apiPut = async (url, body) => {
  try {
    const res = await API.put(url, body);
    toast.success(res.data.message || "Updated");
    return res.data;
  } catch (err) {
    toast.error(err.response?.data?.message || "Update Failed");
    return null;
  }
};

export const apiDelete = async (url) => {
  try {
    const res = await API.delete(url);
    toast.success(res.data.message || "Deleted");
    return res.data;
  } catch (err) {
    toast.error(err.response?.data?.message || "Delete Failed");
    return null;
  }
};

/* =========================
   LOCAL STORAGE HELPERS
========================= */

export const getUser = () => {
  return JSON.parse(localStorage.getItem("user") || "null");
};

export const setUser = (user) => {
  localStorage.setItem("user", JSON.stringify(user));
};

export const logoutUser = (navigate) => {
  localStorage.clear();
  navigate("/login");
};