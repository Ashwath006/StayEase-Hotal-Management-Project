import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import API from "../services/api";
import { toast, ToastContainer } from "react-toastify";
import LoadingSpinner from "../components/LoadingSpinner";
import "../styles/Booking.css";

function Booking() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [room, setRoom] = useState(null);
  const [loading, setLoading] = useState(true);

  const [booking, setBooking] = useState({
    checkIn: "",
    checkOut: "",
    guests: 1,
  });

  const today = new Date();
  const minDate = [
    today.getFullYear(),
    String(today.getMonth() + 1).padStart(2, "0"),
    String(today.getDate()).padStart(2, "0"),
  ].join("-");

  useEffect(() => {
    let active = true;

    const fetchRoom = async () => {
      try {
        setLoading(true);

        const res = await API.get(`/rooms/${id}`);

        if (active) {
          setRoom(res.data.room);
        }
      } catch (error) {
        if (active) {
          toast.error("Failed to load room details.");
          setRoom(null);
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    fetchRoom();

    return () => {
      active = false;
    };
  }, [id]);

  const handleChange = (event) => {
    const { name, value } = event.target;

    setBooking((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  const handleBooking = (event) => {
    event.preventDefault();

    if (!room) {
      toast.error("Room details are unavailable.");
      return;
    }

    if (!room.available) {
      toast.error("This room is currently unavailable.");
      return;
    }

    if (!booking.checkIn || !booking.checkOut) {
      toast.error("Please select check-in and check-out dates.");
      return;
    }

    if (
      booking.checkIn < minDate ||
      booking.checkOut <= booking.checkIn
    ) {
      toast.error("Please select valid booking dates.");
      return;
    }

    const guests = Number(booking.guests);
    const capacity = Number(room.capacity || 1);

    if (!Number.isInteger(guests) || guests < 1 || guests > capacity) {
      toast.error(`This room accommodates up to ${capacity} guest(s).`);
      return;
    }

    // Continue to payment without creating a booking yet.
    navigate(`/payment/${id}`, {
      state: {
        ...booking,
        guests,
        room,
      },
    });
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!room) {
    return (
      <div className="booking-page">
        <div className="booking-empty">
          <span className="booking-empty-icon">⌂</span>
          <h2>Room Unavailable</h2>
          <p>We couldn't load this room's details.</p>
          <button
            className="booking-btn booking-btn-gold"
            onClick={() => navigate("/hotels")}
          >
            Explore Hotels
          </button>
        </div>
        <ToastContainer position="top-right" />
      </div>
    );
  }

  const roomImage =
    (Array.isArray(room.images) && room.images[0]) ||
    room.image ||
    (Array.isArray(room.hotel?.images) && room.hotel.images[0]) ||
    room.hotel?.image ||
    "";

  return (
    <main className="booking-page">
      <div className="booking-container">
        {/* PAGE INTRO */}
        <header className="booking-intro">
          <span className="booking-eyebrow">
            STAYEASE · ROYAL COLLECTION
          </span>

          <h1>Your Private Escape</h1>

          <p>
            Discover comfort, elegance and a stay worth remembering.
          </p>

          <div className="booking-intro-line" />
        </header>

        {/* MAIN BOOKING CARD */}
        <section className="booking-card">
          {/* ROOM INFORMATION */}
          <aside className="booking-room-panel">
            <div className="booking-room-image-wrap">
              {roomImage ? (
                <img
                  src={roomImage}
                  alt={`${room.roomType || "Hotel"} room`}
                  className="booking-room-image"
                  onError={(event) => {
                    event.currentTarget.style.display = "none";
                  }}
                />
              ) : (
                <div className="booking-image-placeholder">
                  <span>STAYEASE</span>
                  <span className="booking-placeholder-icon">✧</span>
                  <small>ROYAL COLLECTION</small>
                </div>
              )}

              <span
                className={`booking-availability ${
                  room.available
                    ? "booking-availability-open"
                    : "booking-availability-closed"
                }`}
              >
                <span className="booking-status-dot" />
                {room.available ? "Available" : "Booked"}
              </span>
            </div>

            <div className="booking-room-content">
              <span className="booking-eyebrow">
                YOUR ACCOMMODATION
              </span>

              <h2>Room Details</h2>

              <p className="booking-room-subtitle">
                {room.roomType || "Premium Room"}
              </p>

              <div className="booking-room-price">
                <span className="booking-currency">₹</span>
                {Number(room.price || 0).toLocaleString("en-IN")}
                <small>/ night</small>
              </div>

              <div className="booking-gold-divider" />

              <div className="booking-room-detail">
                <span>Room Number</span>
                <strong>{room.roomNumber || "N/A"}</strong>
              </div>

              <div className="booking-room-detail">
                <span>Room Type</span>
                <strong>{room.roomType || "N/A"}</strong>
              </div>

              <div className="booking-room-detail">
                <span>Guest Capacity</span>
                <strong>
                  {room.capacity || 1} Guest(s)
                </strong>
              </div>

              <div className="booking-room-detail">
                <span>Availability</span>
                <strong
                  className={
                    room.available
                      ? "booking-text-available"
                      : "booking-text-unavailable"
                  }
                >
                  {room.available ? "Available" : "Booked"}
                </strong>
              </div>

              <div className="booking-room-footer">
                <span className="booking-shield">✦</span>
                <p>Thoughtfully designed for your comfort.</p>
              </div>
            </div>
          </aside>

          {/* BOOKING FORM */}
          <section className="booking-form-panel">
            <div className="booking-form-heading">
              <span className="booking-eyebrow-dark">
                MAKE IT YOURS
              </span>

              <h2>Book Your Stay</h2>

              <p>
                Choose your dates and prepare for an exceptional
                experience.
              </p>
            </div>

            <form onSubmit={handleBooking}>
              <div className="booking-field">
                <label htmlFor="booking-checkin">
                  <span className="booking-field-icon">↗</span>
                  Check In
                </label>

                <input
                  id="booking-checkin"
                  type="date"
                  name="checkIn"
                  min={minDate}
                  value={booking.checkIn}
                  onChange={handleChange}
                  required
                  disabled={!room.available}
                />
              </div>

              <div className="booking-field">
                <label htmlFor="booking-checkout">
                  <span className="booking-field-icon">↙</span>
                  Check Out
                </label>

                <input
                  id="booking-checkout"
                  type="date"
                  name="checkOut"
                  min={booking.checkIn || minDate}
                  value={booking.checkOut}
                  onChange={handleChange}
                  required
                  disabled={!room.available}
                />
              </div>

              <div className="booking-field">
                <label htmlFor="booking-guests">
                  <span className="booking-field-icon">♙</span>
                  Number of Guests
                </label>

                <select
                  id="booking-guests"
                  name="guests"
                  value={booking.guests}
                  onChange={handleChange}
                  disabled={!room.available}
                >
                  {Array.from(
                    { length: Math.max(1, Number(room.capacity) || 1) },
                    (_, index) => index + 1
                  ).map((guestCount) => (
                    <option key={guestCount} value={guestCount}>
                      {guestCount} {guestCount === 1 ? "Guest" : "Guests"}
                    </option>
                  ))}
                </select>
              </div>

              <div className="booking-secure-note">
                <span>♢</span>
                <div>
                  <strong>A seamless reservation</strong>
                  <p>Review your stay before proceeding to payment.</p>
                </div>
              </div>

              <button
                type="submit"
                className="booking-btn booking-btn-gold booking-submit"
                disabled={!room.available}
              >
                <span>
                  {room.available
                    ? "Proceed to Payment"
                    : "Room Unavailable"}
                </span>
                <span className="booking-btn-arrow">→</span>
              </button>

              <p className="booking-form-footnote">
                Your reservation details will be passed securely
                to the next step.
              </p>
            </form>
          </section>
        </section>

        <footer className="booking-page-footer">
          <span>STAYEASE</span>
          <span>YOUR COMFORT. OUR SIGNATURE.</span>
        </footer>
      </div>

      <ToastContainer position="top-right" />
    </main>
  );
}

export default Booking;