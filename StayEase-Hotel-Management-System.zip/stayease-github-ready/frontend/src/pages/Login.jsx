import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import API from "../services/api";
import { useAuth } from "../context/AuthContext";
import ToastNotification from "../components/ToastNotification";
import "../styles/Login.css";

function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [toastData, setToastData] = useState({
    message: "",
    type: "success",
    show: false,
  });

  const showToast = (message, type = "success") => {
    setToastData({
      message,
      type,
      show: true,
    });
  };

  const closeToast = () => {
    setToastData((prev) => ({
      ...prev,
      show: false,
    }));
  };

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (loading) return;

    setLoading(true);

    try {
      const res = await API.post("/auth/login", form);
      login(res.data.user, res.data.token);
      window.dispatchEvent(new Event("auth-change"));
            showToast("Login successful! Welcome to StayEase.", "success");
      setTimeout(() => {
        if (res.data.user.role === "admin") {
          navigate("/admin");
        } else {
          navigate("/");
        }
      }, 1000);
    } catch (err) {
      showToast(
        err.response?.data?.message || "Login failed. Please try again.",
        "error"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="se-login-page">
      <div className="se-login-background-glow se-login-glow-one"></div>
      <div className="se-login-background-glow se-login-glow-two"></div>

      <div className="se-login-wrapper">
        {/* BRAND HEADER */}
        <header className="se-login-header">
          <Link to="/" className="se-login-brand">
            <span className="se-login-brand-icon">S</span>

            <span className="se-login-brand-name">
              Stay<span>Ease</span>
              <small>YOUR COMFORT, OUR PRIORITY</small>
            </span>
          </Link>

          <Link to="/" className="se-login-home-link">
            <span>←</span> Back to Home
          </Link>
        </header>

        {/* LOGIN LAYOUT */}
        <section className="se-login-layout">
          {/* LEFT LUXURY PANEL */}
          <div className="se-login-showcase">
            <div className="se-login-showcase-content">
              <span className="se-login-eyebrow">
                <span className="se-login-eyebrow-line"></span>
                THE ART OF HOSPITALITY
              </span>

              <h1>
                Every stay
                <br />
                deserves to be
                <br />
                <span>extraordinary.</span>
              </h1>

              <p>
                Discover exceptional stays, thoughtful comfort, and
                unforgettable experiences. Your next journey begins here.
              </p>

              <div className="se-login-features">
                <div className="se-login-feature">
                  <span className="se-login-feature-icon">✦</span>
                  <div>
                    <strong>Exceptional Stays</strong>
                    <small>Handpicked comfort and quality</small>
                  </div>
                </div>

                <div className="se-login-feature">
                  <span className="se-login-feature-icon">◇</span>
                  <div>
                    <strong>Seamless Booking</strong>
                    <small>Your stay, effortlessly managed</small>
                  </div>
                </div>

                <div className="se-login-feature">
                  <span className="se-login-feature-icon">✓</span>
                  <div>
                    <strong>Trusted Experience</strong>
                    <small>Comfort from booking to checkout</small>
                  </div>
                </div>
              </div>
            </div>

            <div className="se-login-showcase-footer">
              <span>TRAVEL BEAUTIFULLY</span>
              <span>STAY EXCEPTIONALLY.</span>
            </div>
          </div>

          {/* LOGIN FORM CARD */}
          <div className="se-login-form-panel">
            <div className="se-login-card">
              <div className="se-login-card-top">
                <span className="se-login-card-icon">✧</span>
                <span className="se-login-card-label">MEMBER ACCESS</span>
              </div>

              <h2>Welcome back</h2>

              <p className="se-login-subtitle">
                Sign in to continue your journey with StayEase.
              </p>

              <form onSubmit={handleSubmit}>
                <div className="se-login-field">
                  <label htmlFor="login-email">Email Address</label>

                  <div className="se-login-input-wrap">
                    <span className="se-login-input-icon">✉</span>

                    <input
                      id="login-email"
                      type="email"
                      name="email"
                      placeholder="Enter your email address"
                      value={form.email}
                      onChange={handleChange}
                      autoComplete="email"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                <div className="se-login-field">
                  <label htmlFor="login-password">Password</label>

                  <div className="se-login-input-wrap">
                    <span className="se-login-input-icon">♙</span>

                    <input
                      id="login-password"
                      type={showPassword ? "text" : "password"}
                      name="password"
                      placeholder="Enter your password"
                      value={form.password}
                      onChange={handleChange}
                      autoComplete="current-password"
                      required
                      disabled={loading}
                    />

                    <button
                      type="button"
                      className="se-login-password-toggle"
                      onClick={() => setShowPassword((prev) => !prev)}
                      aria-label={
                        showPassword ? "Hide password" : "Show password"
                      }
                      disabled={loading}
                    >
                      {showPassword ? "Hide" : "Show"}
                    </button>
                  </div>
                </div>

                <div className="se-login-form-options">
                  <span className="se-login-secure-note">
                    <span>✓</span> Secure sign in
                  </span>

                  <Link to="/reset-password" className="se-login-forgot">
                    Forgot password?
                  </Link>
                </div>

                <button
                  type="submit"
                  className="se-login-submit"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="se-login-spinner"></span>
                      Signing you in...
                    </>
                  ) : (
                    <>
                      Sign In
                      <span className="se-login-submit-arrow">→</span>
                    </>
                  )}
                </button>
              </form>

              <div className="se-login-divider">
                <span></span>
                <small>YOUR JOURNEY STARTS HERE</small>
                <span></span>
              </div>

              <p className="se-login-register-text">
                New to StayEase?{" "}
                <Link to="/register">Create an account</Link>
              </p>

              <div className="se-login-privacy">
                <span>♢</span>
                Your account and booking details are protected.
              </div>
            </div>
          </div>
        </section>

        <footer className="se-login-footer">
          <span>© {new Date().getFullYear()} StayEase</span>
          <span>MADE FOR MEMORABLE STAYS</span>
        </footer>
      </div>

      {/* PAYMENT SUCCESS PAGE-ல் பயன்படுத்திய அதே TOAST */}
      <ToastNotification
        message={toastData.message}
        type={toastData.type}
        show={toastData.show}
        onClose={closeToast}
      />
    </main>
  );
}

export default Login;