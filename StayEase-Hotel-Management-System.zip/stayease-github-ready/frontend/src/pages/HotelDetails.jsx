import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import API from "../services/api";
import { toast, ToastContainer } from "react-toastify";
import LoadingSpinner from "../components/LoadingSpinner";
import {
  FaMapMarkerAlt,
  FaStar,
  FaWifi,
  FaParking,
  FaSnowflake,
  FaSwimmingPool,
  FaArrowRight,
  FaBed,
  FaUsers,
  FaCheckCircle,
  FaRegCommentDots,
} from "react-icons/fa";
import "../styles/hotelDetails.css";

function HotelDetails() {
  const { id } = useParams();

  const [hotel, setHotel] = useState(null);
  const [rooms, setRooms] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hotelError, setHotelError] = useState(false);
  const [submittingReview, setSubmittingReview] = useState(false);

  const [review, setReview] = useState({
    rating: "5",
    comment: "",
  });

  const [user, setUser] = useState(null);

  const carouselId = `hotelCarousel-${id}`;

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem("user");
      setUser(storedUser ? JSON.parse(storedUser) : null);
    } catch {
      setUser(null);
    }
  }, []);

  useEffect(() => {
    let active = true;

    const loadHotelPage = async () => {
      setLoading(true);
      setHotelError(false);
      setHotel(null);
      setRooms([]);
      setReviews([]);

      const results = await Promise.allSettled([
        API.get(`/hotels/${id}`),
        API.get(`/rooms?hotelId=${id}`),
        API.get(`/reviews/${id}`),
      ]);

      if (!active) return;

      const [hotelResult, roomsResult, reviewsResult] = results;

      if (hotelResult.status === "fulfilled") {
        const data = hotelResult.value.data;
        const hotelData = data.hotel || data;
        setHotel(hotelData);
      } else {
        console.error("Failed to load hotel:", hotelResult.reason);
        setHotelError(true);
      }

      if (roomsResult.status === "fulfilled") {
        const data = roomsResult.value.data;
        setRooms(Array.isArray(data.rooms) ? data.rooms : []);
      } else {
        console.error("Failed to load rooms:", roomsResult.reason);
      }

      if (reviewsResult.status === "fulfilled") {
        const data = reviewsResult.value.data;
        setReviews(Array.isArray(data.reviews) ? data.reviews : []);
      } else {
        console.error("Failed to load reviews:", reviewsResult.reason);
      }

      setLoading(false);
    };

    loadHotelPage();

    return () => {
      active = false;
    };
  }, [id]);

  const submitReview = async (event) => {
    event.preventDefault();

    if (!user?._id) {
      toast.info("Please log in to submit a review.");
      return;
    }

    if (!review.comment.trim()) {
      toast.warning("Please write a review before submitting.");
      return;
    }

    try {
      setSubmittingReview(true);

      await API.post("/reviews", {
        userId: user._id,
        hotelId: id,
        rating: Number(review.rating),
        comment: review.comment.trim(),
      });

      toast.success("Review added successfully!");

      setReview({
        rating: "5",
        comment: "",
      });

      const res = await API.get(`/reviews/${id}`);
      setReviews(
        Array.isArray(res.data.reviews) ? res.data.reviews : []
      );
    } catch (err) {
      toast.error(
        err.response?.data?.message || "Failed to submit review."
      );
    } finally {
      setSubmittingReview(false);
    }
  };

  const getAmenityIcon = (amenity) => {
    const value = String(amenity).toLowerCase();

    if (value.includes("wifi") || value.includes("internet")) {
      return <FaWifi />;
    }

    if (value.includes("parking")) {
      return <FaParking />;
    }

    if (
      value.includes("air conditioning") ||
      value.includes("ac") ||
      value.includes("snow")
    ) {
      return <FaSnowflake />;
    }

    if (value.includes("pool") || value.includes("swimming")) {
      return <FaSwimmingPool />;
    }

    return <FaCheckCircle />;
  };

  if (loading) {
    return (
      <div className="st-hd-loading">
        <LoadingSpinner />
        <p>Preparing your stay experience...</p>
      </div>
    );
  }

  if (hotelError || !hotel) {
    return (
      <main className="st-hd-page">
        <div className="container">
          <div className="st-hd-state">
            <span className="st-hd-state-icon">!</span>
            <h2>Hotel Not Found</h2>
            <p>
              We couldn't load this hotel. It may have been removed,
              or there may be a connection issue.
            </p>
            <Link to="/hotels" className="st-hd-primary-btn">
              Explore Hotels <FaArrowRight />
            </Link>
          </div>
        </div>
        <ToastContainer position="top-right" />
      </main>
    );
  }

  const hotelImages =
    Array.isArray(hotel.images) && hotel.images.length > 0
      ? hotel.images
      : [
          "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1400&q=85",
        ];

  return (
    <main className="st-hd-page">
      {/* HERO */}
      <section className="st-hd-hero">
        <div className="container">
          <div className="st-hd-breadcrumb">
            <Link to="/">Home</Link>
            <span>/</span>
            <Link to="/hotels">Hotels</Link>
            <span>/</span>
            <span>{hotel.hotelName}</span>
          </div>

          <div className="st-hd-hero-content">
            <span className="st-hd-eyebrow">
              <span></span>
              STAYEASE COLLECTION
              <span></span>
            </span>

            <h1>{hotel.hotelName}</h1>

            <p className="st-hd-hero-location">
              <FaMapMarkerAlt />
              {hotel.location || "Discover this destination"}
            </p>

            <div className="st-hd-hero-rating">
              <FaStar />
              <strong>{Number(hotel.rating || 0).toFixed(1)}</strong>
              <span>/ 5 guest rating</span>
            </div>
          </div>
        </div>
      </section>

      <section className="st-hd-content">
        <div className="container">
          {/* IMAGE GALLERY + PRICE CARD */}
          <div className="row g-4 st-hd-overview">
            <div className="col-lg-7">
              <div
                id={carouselId}
                className="carousel slide st-hd-gallery"
                data-bs-ride="carousel"
              >
                <div className="carousel-inner">
                  {hotelImages.map((img, index) => (
                    <div
                      key={`${img}-${index}`}
                      className={`carousel-item ${
                        index === 0 ? "active" : ""
                      }`}
                    >
                      <img
                        src={img}
                        className="st-hd-gallery-image"
                        alt={`${hotel.hotelName} view ${index + 1}`}
                        onError={(event) => {
                          event.currentTarget.src =
                            "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1400&q=85";
                        }}
                      />
                    </div>
                  ))}
                </div>

                {hotelImages.length > 1 && (
                  <>
                    <button
                      className="carousel-control-prev st-hd-carousel-control"
                      type="button"
                      data-bs-target={`#${carouselId}`}
                      data-bs-slide="prev"
                      aria-label="Previous image"
                    >
                      <span className="carousel-control-prev-icon"></span>
                    </button>

                    <button
                      className="carousel-control-next st-hd-carousel-control"
                      type="button"
                      data-bs-target={`#${carouselId}`}
                      data-bs-slide="next"
                      aria-label="Next image"
                    >
                      <span className="carousel-control-next-icon"></span>
                    </button>

                    <div className="st-hd-gallery-counter">
                      {hotelImages.length} Photos
                    </div>
                  </>
                )}
              </div>
            </div>

            <div className="col-lg-5">
              <aside className="st-hd-price-card">
                <span className="st-hd-card-eyebrow">
                  YOUR PERFECT GETAWAY
                </span>

                <h2>Experience a memorable stay.</h2>

                <p className="st-hd-price-description">
                  Enjoy comfort, thoughtful amenities, and a relaxing
                  experience at {hotel.hotelName}.
                </p>

                <div className="st-hd-price-divider"></div>

                <span className="st-hd-price-caption">
                  Starting price
                </span>

                <div className="st-hd-main-price">
                  <span>₹</span>
                  {Number(hotel.price || 0).toLocaleString("en-IN")}
                  <small>/ night</small>
                </div>

                <div className="st-hd-rating-summary">
                  <span className="st-hd-rating-star">
                    <FaStar />
                  </span>
                  <div>
                    <strong>
                      {Number(hotel.rating || 0).toFixed(1)} / 5
                    </strong>
                    <small>Hotel rating</small>
                  </div>
                </div>

                <a href="#st-hd-rooms" className="st-hd-primary-btn">
                  Explore Available Rooms <FaArrowRight />
                </a>

                <p className="st-hd-secure-note">
                  <FaCheckCircle />
                  Find the right room for your stay
                </p>
              </aside>
            </div>
          </div>

          {/* DESCRIPTION */}
          <section className="st-hd-section st-hd-about">
            <div className="st-hd-section-heading">
              <span className="st-hd-section-label">GET TO KNOW US</span>
              <h2>About This Hotel</h2>
              <p>Discover what makes this stay special.</p>
            </div>

            <div className="st-hd-about-card">
              <p>
                {hotel.description ||
                  "Discover a comfortable stay with welcoming hospitality and amenities designed to make your visit enjoyable."}
              </p>

              <div className="st-hd-location-line">
                <span className="st-hd-detail-icon">
                  <FaMapMarkerAlt />
                </span>
                <div>
                  <small>DESTINATION</small>
                  <strong>{hotel.location || "Location not specified"}</strong>
                </div>
              </div>
            </div>
          </section>

          {/* AMENITIES */}
          <section className="st-hd-section">
            <div className="st-hd-section-heading">
              <span className="st-hd-section-label">COMFORT & CONVENIENCE</span>
              <h2>Hotel Amenities</h2>
              <p>Thoughtful facilities to make your stay comfortable.</p>
            </div>

            {Array.isArray(hotel.amenities) && hotel.amenities.length > 0 ? (
              <div className="row g-3">
                {hotel.amenities.map((amenity, index) => (
                  <div
                    className="col-6 col-md-4 col-lg-3"
                    key={`${amenity}-${index}`}
                  >
                    <div className="st-hd-amenity">
                      <span className="st-hd-amenity-icon">
                        {getAmenityIcon(amenity)}
                      </span>
                      <span>{amenity}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="st-hd-info-message">
                Hotel amenities have not been added yet.
              </div>
            )}
          </section>

          {/* ROOMS */}
          <section className="st-hd-section" id="st-hd-rooms">
            <div className="st-hd-section-heading st-hd-rooms-heading">
              <div>
                <span className="st-hd-section-label">CHOOSE YOUR COMFORT</span>
                <h2>Available Rooms</h2>
                <p>Select a room that suits your travel needs.</p>
              </div>

              <span className="st-hd-room-count">
                {rooms.length} {rooms.length === 1 ? "Room" : "Rooms"}
              </span>
            </div>

            {rooms.length === 0 ? (
              <div className="st-hd-state st-hd-rooms-empty">
                <span className="st-hd-state-icon">
                  <FaBed />
                </span>
                <h3>No Rooms Available</h3>
                <p>
                  There are currently no rooms listed for this hotel.
                  Please check again later.
                </p>
                <Link to="/hotels" className="st-hd-secondary-btn">
                  Browse Other Hotels
                </Link>
              </div>
            ) : (
              <div className="row g-4">
                {rooms.map((room) => (
                  <div className="col-md-6 col-lg-4" key={room._id}>
                    <article className="st-hd-room-card">
                      <div className="st-hd-room-top">
                        <div className="st-hd-room-icon">
                          <FaBed />
                        </div>

                        <span
                          className={`st-hd-room-status ${
                            room.available ? "is-available" : "is-booked"
                          }`}
                        >
                          <span></span>
                          {room.available ? "Available" : "Unavailable"}
                        </span>
                      </div>

                      <span className="st-hd-room-overline">
                        {room.roomType || "Guest Room"}
                      </span>

                      <h3>
                        Room {room.roomNumber || "—"}
                      </h3>

                      <div className="st-hd-room-meta">
                        <span>
                          <FaUsers />
                          Capacity: {room.capacity || 1}
                        </span>
                        <span>
                          <FaBed />
                          {room.beds || 1}{" "}
                          {Number(room.beds || 1) === 1 ? "Bed" : "Beds"}
                        </span>
                      </div>

                      {Array.isArray(room.amenities) &&
                        room.amenities.length > 0 && (
                          <div className="st-hd-room-amenities">
                            {room.amenities.slice(0, 3).map((amenity, index) => (
                              <span key={`${amenity}-${index}`}>
                                {amenity}
                              </span>
                            ))}
                          </div>
                        )}

                      <div className="st-hd-room-divider"></div>

                      <div className="st-hd-room-footer">
                        <div>
                          <small>Price per night</small>
                          <strong>
                            ₹{Number(room.price || 0).toLocaleString("en-IN")}
                          </strong>
                        </div>

                        {room.available ? (
                          <Link
                            to={`/booking/${room._id}`}
                            className="st-hd-room-book-btn"
                          >
                            Book Now <FaArrowRight />
                          </Link>
                        ) : (
                          <button
                            type="button"
                            className="st-hd-room-book-btn is-disabled"
                            disabled
                          >
                            Unavailable
                          </button>
                        )}
                      </div>
                    </article>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* REVIEWS */}
          <section className="st-hd-section" id="st-hd-reviews">
            <div className="st-hd-section-heading">
              <span className="st-hd-section-label">GUEST EXPERIENCES</span>
              <h2>Customer Reviews</h2>
              <p>Read guest feedback and share your experience.</p>
            </div>

            <div className="row g-4">
              <div className="col-lg-5">
                <form className="st-hd-review-form" onSubmit={submitReview}>
                  <div className="st-hd-review-form-heading">
                    <span className="st-hd-review-icon">
                      <FaRegCommentDots />
                    </span>
                    <div>
                      <h3>Write a Review</h3>
                      <p>Tell others about your stay.</p>
                    </div>
                  </div>

                  {!user?._id && (
                    <p className="st-hd-login-note">
                      Please log in before submitting a review.
                    </p>
                  )}

                  <label htmlFor="st-hd-rating">Your Rating</label>
                  <select
                    id="st-hd-rating"
                    className="form-select st-hd-form-control"
                    value={review.rating}
                    onChange={(event) =>
                      setReview((previous) => ({
                        ...previous,
                        rating: event.target.value,
                      }))
                    }
                  >
                    <option value="5">★★★★★ — Excellent</option>
                    <option value="4">★★★★ — Very Good</option>
                    <option value="3">★★★ — Good</option>
                    <option value="2">★★ — Fair</option>
                    <option value="1">★ — Poor</option>
                  </select>

                  <label htmlFor="st-hd-comment">Your Experience</label>
                  <textarea
                    id="st-hd-comment"
                    className="form-control st-hd-form-control"
                    rows="5"
                    maxLength={1000}
                    placeholder="Share your experience with this hotel..."
                    value={review.comment}
                    onChange={(event) =>
                      setReview((previous) => ({
                        ...previous,
                        comment: event.target.value,
                      }))
                    }
                  />

                  <button
                    type="submit"
                    className="st-hd-primary-btn st-hd-submit-btn"
                    disabled={submittingReview}
                  >
                    {submittingReview ? "Submitting..." : "Submit Review"}
                    {!submittingReview && <FaArrowRight />}
                  </button>
                </form>
              </div>

              <div className="col-lg-7">
                <div className="st-hd-reviews-list">
                  <div className="st-hd-reviews-list-header">
                    <h3>Guest Feedback</h3>
                    <span>
                      {reviews.length}{" "}
                      {reviews.length === 1 ? "Review" : "Reviews"}
                    </span>
                  </div>

                  {reviews.length === 0 ? (
                    <div className="st-hd-no-reviews">
                      <span>
                        <FaRegCommentDots />
                      </span>
                      <h4>No Reviews Yet</h4>
                      <p>Be the first to share your experience.</p>
                    </div>
                  ) : (
                    reviews.map((item) => (
                      <article className="st-hd-review-item" key={item._id}>
                        <div className="st-hd-review-avatar">
                          {(item.userId?.name || "G")
                            .trim()
                            .charAt(0)
                            .toUpperCase()}
                        </div>

                        <div className="st-hd-review-content">
                          <div className="st-hd-review-user-row">
                            <h4>{item.userId?.name || "Guest"}</h4>

                            <span className="st-hd-review-rating">
                              <FaStar /> {Number(item.rating || 0)}
                            </span>
                          </div>

                          <div className="st-hd-review-stars" aria-label={`${item.rating} out of 5 stars`}>
                            {"★".repeat(
                              Math.max(0, Math.min(5, Number(item.rating) || 0))
                            )}
                            <span>
                              {"★".repeat(
                                5 -
                                  Math.max(
                                    0,
                                    Math.min(5, Number(item.rating) || 0)
                                  )
                              )}
                            </span>
                          </div>

                          <p>{item.comment}</p>
                        </div>
                      </article>
                    ))
                  )}
                </div>
              </div>
            </div>
          </section>

          {/* BACK TO HOTELS */}
          <div className="st-hd-back-row">
            <Link to="/hotels" className="st-hd-back-link">
              <span>←</span> Back to All Hotels
            </Link>
          </div>
        </div>
      </section>

      <ToastContainer position="top-right" autoClose={3000} />
    </main>
  );
}

export default HotelDetails;