import "./../styles/home.css";
import "./../styles/newsletter.css";
import "./../styles/finalCta.css";
import "./../styles/floatingButtons.css";
import "./../styles/popularDestinations.css"
import Footer from "../components/Footer";
import FeaturedHotels from "../components/FeaturedHotels";
import PopularDestinations from "../components/PopularDestinations";
import {
  FaHotel,
  FaUtensils,
  FaDumbbell,
  FaCar,
  FaConciergeBell,
  FaSwimmingPool,
  FaWifi,
  FaSpa,
  FaShieldAlt,
  FaBolt
} from "react-icons/fa";
import CountUp from "react-countup";
import ScrollTrigger from "react-scroll-trigger";
import { useState,useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";

function Home() {
  const navigate = useNavigate();
  const [showTop, setShowTop] = useState(false);
  useEffect(()=>{

    const reveals=document.querySelectorAll(".reveal");


    const observer=new IntersectionObserver(
        (entries)=>{

            entries.forEach((entry)=>{

                if(entry.isIntersecting){

                    entry.target.classList.add("active");

                }

            });

        },
        {
            threshold:0.15
        }
    );


    reveals.forEach((item)=>{

        observer.observe(item);

    });


    return()=>{

        reveals.forEach((item)=>{

            observer.unobserve(item);

        });

    };


},[]);

useEffect(()=>{

    const handleScroll = ()=>{

        if(window.scrollY > 500){

            setShowTop(true);

        }
        else{

            setShowTop(false);

        }

    };


    window.addEventListener(
        "scroll",
        handleScroll
    );


    return()=>{

        window.removeEventListener(
            "scroll",
            handleScroll
        );

    };


},[]);
const scrollTop = ()=>{

    window.scrollTo({

        top:0,

        behavior:"smooth"

    });

};
const [counts, setCounts] = useState({
    rooms:0,
    hotels:0,
    guests:0,
    years:0
});


useEffect(()=>{

    let start = 0;


    const interval = setInterval(()=>{

        start += 10;


        setCounts({

            rooms:
            start >= 500 ? 500 : start,


            hotels:
            start >= 120 ? 120 : start,


            guests:
            start >= 50000 ? 50000 : start * 100,


            years:
            start >= 15 ? 15 : start

        });



        if(start >= 500){

            clearInterval(interval);

        }


    },20);



    return()=>clearInterval(interval);


},[]);
  const [searchData, setSearchData] = useState({
    location: "",
    checkIn: "",
    checkOut: "",
    guests: "",
  });
const [counterOn, setCounterOn] = useState(false);
  const handleChange = (e) => {
    setSearchData({
      ...searchData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSearch = () => {
    const params = new URLSearchParams();

    if (searchData.location) {
      params.append("location", searchData.location);
    }

    if (searchData.checkIn) {
      params.append("checkIn", searchData.checkIn);
    }

    if (searchData.checkOut) {
      params.append("checkOut", searchData.checkOut);
    }

    if (searchData.guests) {
      params.append("guests", searchData.guests);
    }

    navigate(`/hotels?${params.toString()}`);
  };

  return (
    <>
          <section className="hero-section">

        <div className="hero-overlay"></div>

        <div className="container">

          <div className="row align-items-center min-vh-100">

            {/* Left Content */}

            <div className="col-lg-6 text-white hero-content">

              <span className="hero-badge">
                ⭐ Trusted by 25,000+ Happy Guests
              </span>

              <h1 className="hero-title mt-4">
                Discover Luxury Hotels
                <br />
                For Your Perfect Stay
              </h1>

              <p className="hero-subtitle">
                Book premium hotels at the best prices with instant
                confirmation, secure payment and world-class hospitality.
              </p>

              <div className="hero-features">

                <div>
                  ✔ Instant Booking
                </div>

                <div>
                  ✔ Best Price Guarantee
                </div>

                <div>
                  ✔ Free Cancellation
                </div>

              </div>

            </div>

            {/* Search Card */}

            <div className="col-lg-6 mt-5 mt-lg-0">

              <div className="premium-search-card">

                <h3 className="fw-bold mb-4 text-center">

                  Find Your Perfect Hotel

                </h3>

                <div className="row g-3">

                  <div className="col-12">

                    <label className="form-label fw-semibold">
                      Destination
                    </label>

                    <input
                      type="text"
                      className="form-control premium-input"
                      placeholder="Enter city or hotel"
                      name="location"
                      value={searchData.location}
                      onChange={handleChange}
                    />

                  </div>

                  <div className="col-md-6">

                    <label className="form-label fw-semibold">
                      Check In
                    </label>

                    <input
                      type="date"
                      className="form-control premium-input"
                      name="checkIn"
                      value={searchData.checkIn}
                      onChange={handleChange}
                    />

                  </div>

                  <div className="col-md-6">

                    <label className="form-label fw-semibold">
                      Check Out
                    </label>

                    <input
                      type="date"
                      className="form-control premium-input"
                      name="checkOut"
                      value={searchData.checkOut}
                      onChange={handleChange}
                    />

                  </div>

                  <div className="col-12">

                    <label className="form-label fw-semibold">
                      Guests
                    </label>

                    <select
                      className="form-select premium-input"
                      name="guests"
                      value={searchData.guests}
                      onChange={handleChange}
                    >
                      <option value="">Select Guests</option>
                      <option value="1">1 Guest</option>
                      <option value="2">2 Guests</option>
                      <option value="3">3 Guests</option>
                      <option value="4">4 Guests</option>
                      <option value="5">5+ Guests</option>
                    </select>

                  </div>

                  <div className="col-12">

                    <button
                      className="btn premium-search-btn w-100"
                      onClick={handleSearch}
                    >
                      🔍 Search Hotels
                    </button>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

      </section>
            <section className="why-section">

        <div className="container">

          <div className="section-heading text-center">

            <span className="section-tag">
              WHY CHOOSE US
            </span>

            <h2>
              Experience Luxury
              <br />
              Like Never Before
            </h2>

            <p>
              StayEase brings together premium hotels, unbeatable prices
              and seamless booking experiences across India.
            </p>

          </div>

          <div className="row g-4 mt-4">

            <div className="col-lg-3 col-md-6">

              <div className="feature-card reveal">

                <div className="feature-icon">
                  🏨
                </div>

                <h4>
                  Luxury Hotels
                </h4>

                <p>
                  Carefully selected premium hotels with exceptional
                  hospitality and modern amenities.
                </p>

              </div>

            </div>

            <div className="col-lg-3 col-md-6">

              <div className="feature-card reveal">

                <div className="feature-icon">
                  💰
                </div>

                <h4>
                  Best Price
                </h4>

                <p>
                  Get exclusive offers and the lowest prices without
                  compromising on quality.
                </p>

              </div>

            </div>

            <div className="col-lg-3 col-md-6">

              <div className="feature-card reveal">

                <div className="feature-icon">
                  ⚡
                </div>

                <h4>
                  Instant Booking
                </h4>

                <p>
                  Secure your room instantly with real-time confirmation
                  and zero waiting time.
                </p>

              </div>

            </div>

            <div className="col-lg-3 col-md-6">

              <div className="feature-card reveal">

                <div className="feature-icon">
                  🛡️
                </div>

                <h4>
                  Secure Payments
                </h4>

                <p>
                  Protected payment gateway ensuring safe and reliable
                  online transactions.
                </p>

              </div>

            </div>

          </div>

        </div>

      </section>
      <PopularDestinations />

      <section className="featured-section py-5">

        <div className="container">

          <FeaturedHotels />

        </div>

      </section>
      
<section className="facilities-section">

  <div className="container">

    <div className="section-heading text-center">

      <span className="section-tag">
            Luxury Facilities</span>

      <h2>
        Everything You Need For
        A Perfect Stay
      </h2>

      <p>
        Enjoy premium amenities designed
        for your comfort and relaxation.
      </p>

    </div>


    <div className="row g-4 mt-4">


      <div className="col-lg-4 col-md-6">

        <div className="facility-card reveal"style={{animationDelay:"0.2s"}}>

          <div className="facility-icon">
            🏊
          </div>

          <h4>
            Swimming Pool
          </h4>

          <p>
            Relax and enjoy our luxury pool experience.
          </p>

        </div>

      </div>



      <div className="col-lg-4 col-md-6">

        <div className="facility-card reveal" style={{
animationDelay:"0.4s"
}}>

          <div className="facility-icon">
            🍽
          </div>

          <h4>
            Fine Dining
          </h4>

          <p>
            Taste delicious cuisines prepared by experts.
          </p>

        </div>

      </div>



      <div className="col-lg-4 col-md-6">

       <div 
className="facility-card reveal"
style={{
animationDelay:"0.2s"
}}
>

          <div className="facility-icon">
            🏋
          </div>

          <h4>
            Fitness Center
          </h4>

          <p>
            Modern gym facilities for our guests.
          </p>

        </div>

      </div>



      <div className="col-lg-4 col-md-6">

        <div className="facility-card reveal" style={{
animationDelay:"0.4s"
}}>

          <div className="facility-icon">
            📶
          </div>

          <h4>
            High Speed WiFi
          </h4>

          <p>
            Stay connected with fast internet.
          </p>

        </div>

      </div>



      <div className="col-lg-4 col-md-6">

        <div className="facility-card reveal" style={{
animationDelay:"0.6s"
}}>

          <div className="facility-icon">
            🚗
          </div>

          <h4>
            Free Parking
          </h4>

          <p>
            Safe and spacious parking facilities.
          </p>

        </div>

      </div>



      <div className="col-lg-4 col-md-6">

        <div className="facility-card reveal" style={{
animationDelay:"0.6s"
}}>

          <div className="facility-icon">
            🛎
          </div>

          <h4>
            24/7 Service
          </h4>

          <p>
            Premium support available anytime.
          </p>

        </div>

      </div>


    </div>


  </div>

</section>
  {/* =========================
    Statistics Counter Section
========================= */}

<section className="stats-section">

  <div className="container">

    <div className="stats-wrapper">


      <div className="row g-4">


        <div className="col-lg-3 col-md-6">

          <div className="stat-card reveal">

            <div className="stat-icon">
              🏨
            </div>

            <h2>
{counts.rooms}+
</h2>
            <p>
              Luxury Rooms
            </p>

          </div>

        </div>



        <div className="col-lg-3 col-md-6">

          <div className="stat-card reveal">

            <div className="stat-icon">
              🌎
            </div>

            <h2>
{counts.hotels}+
</h2>

            <p>
              Premium Hotels
            </p>

          </div>

        </div>



        <div className="col-lg-3 col-md-6">

          <div className="stat-card reveal">

            <div className="stat-icon">
              😊
            </div>

          <h2>
{counts.guests}+
</h2>

            <p>
              Happy Guests
            </p>

          </div>

        </div>



        <div className="col-lg-3 col-md-6">

          <div className="stat-card reveal">

            <div className="stat-icon">
              ⭐
            </div>

          <h2>
{counts.years}+
</h2>

            <p>
              Years Experience
            </p>

          </div>

        </div>


      </div>


    </div>

  </div>

</section>
{/* =========================
    Premium Offer Banner
========================= */}

<section className="offer-section">

  <div className="container">

    <div className="offer-box">


      <div className="offer-content">


        <span>
          SPECIAL OFFER
        </span>


        <h2>
          Experience Luxury Stay
          <br />
          With 30% Exclusive Discount
        </h2>


        <p>
          Book your dream hotel today and enjoy
          premium comfort with unforgettable memories.
        </p>


        <button className="offer-btn">
          Book Now
        </button>


      </div>


    </div>

  </div>

</section>

  {/* =========================
          CUSTOMER REVIEWS
      ========================== */}

      <section className="reviews-section">

        <div className="container">

          <div className="section-heading text-center mb-5">

            <span className="section-tag">
              TESTIMONIALS
            </span>

            <h2>
              What Our Guests Say
            </h2>

            <p>
              Thousands of travelers trust StayEase for memorable
              hotel experiences across India.
            </p>

          </div>

          <div className="row g-4">

            <div className="col-lg-4">

              <div className="review-card">

                <div className="review-stars">
                  ⭐⭐⭐⭐⭐
                </div>

                <p className="review-text">
                  The booking experience was seamless. The hotel exceeded
                  our expectations with outstanding hospitality and
                  luxurious rooms.
                </p>

                <div className="review-user">

                  <div className="review-avatar">
                    R
                  </div>

                  <div>

                    <h6 className="mb-0">
                      Rahul Sharma
                    </h6>

                    <small>
                      Chennai
                    </small>

                  </div>

                </div>

              </div>

            </div>

            <div className="col-lg-4">

              <div className="review-card">

                <div className="review-stars">
                  ⭐⭐⭐⭐⭐
                </div>

                <p className="review-text">
                  Premium rooms, secure online booking and excellent
                  customer support. I will definitely book again.
                </p>

                <div className="review-user">

                  <div className="review-avatar">
                    P
                  </div>

                  <div>

                    <h6 className="mb-0">
                      Priya Nair
                    </h6>

                    <small>
                      Bangalore
                    </small>

                  </div>

                </div>

              </div>

            </div>

            <div className="col-lg-4">

              <div className="review-card">

                <div className="review-stars">
                  ⭐⭐⭐⭐⭐
                </div>

                <p className="review-text">
                  Best hotel booking platform. Affordable prices,
                  instant confirmation and premium hotel collection.
                </p>

                <div className="review-user">

                  <div className="review-avatar">
                    A
                  </div>

                  <div>

                    <h6 className="mb-0">
                      Arjun Kumar
                    </h6>

                    <small>
                      Hyderabad
                    </small>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

      </section>

      {/* =========================
          NEWSLETTER
      ========================== */}

      <section className="newsletter-section">

        <div className="container">

          <div className="newsletter-card">

            <div className="row align-items-center">

              <div className="col-lg-6">

                <span className="section-tag">
                  NEWSLETTER
                </span>

                <h2 className="mt-3">
                  Get Exclusive Hotel Deals
                </h2>

                <p>
                  Subscribe to receive premium hotel offers,
                  travel tips and exclusive discounts directly
                  to your inbox.
                </p>

              </div>

              <div className="col-lg-6">

                <div className="row g-3">

                  <div className="col-md-8">

                    <input
                      type="email"
                      className="form-control premium-input"
                      placeholder="Enter your email"
                    />

                  </div>

                  <div className="col-md-4">

                    <button className="btn premium-search-btn w-100">

                      Subscribe

                    </button>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

      </section>

      {/* =========================
          FINAL CTA
      ========================== */}

      <section className="final-cta">

        <div className="container">

          <div className="cta-card">

            <span className="section-tag text-white">
              READY TO TRAVEL?
            </span>

            <h2 className="mt-4">

              Your Luxury Stay
              <br />
              Starts Here

            </h2>

            <p>
              Explore premium hotels, compare prices and
              enjoy a smooth booking experience with StayEase.
            </p>

            <Link
              to="/hotels"
              className="btn premium-light-btn mt-3"
            >

              Explore Hotels →

            </Link>

          </div>

        </div>

      </section>
{/* BACK TO TOP */}

{
showTop && (

<button
className="back-top-btn"
onClick={scrollTop}
>

↑

</button>

)

}
<Link
to="/hotels"
className="floating-book-btn"
>

🏨 Book Now

</Link>
      {/* =========================
          FOOTER
      ========================== */}

      <Footer />

    </>

  );

}

export default Home;