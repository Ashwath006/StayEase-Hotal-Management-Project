
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import PaymentSuccessBadge from "../components/PaymentSuccessBadge";
import ToastNotification from "../components/ToastNotification";

function PaymentSuccess() {
  const { state } = useLocation();
  const navigate = useNavigate();

  const [showTick, setShowTick] = useState(false);
  const [showContent, setShowContent] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [copyMessage, setCopyMessage] = useState("");

  const booking = state?.booking || {};

  const paymentId =
    booking.razorpayPaymentId ||
    state?.razorpay_payment_id ||
    "";

  const bookingId = booking._id || "";

  const amount = Number(
    booking.totalAmount ?? state?.amount ?? 0
  );

  const paymentTime = booking.createdAt
    ? new Date(booking.createdAt).toLocaleString("en-IN")
    : new Date().toLocaleString("en-IN");

  const hotelName =
    state?.hotelName || booking.hotelId?.hotelName || "StayEase Hotel";

  const roomNumber =
    state?.roomNumber || booking.roomId?.roomNumber || "—";

  const roomType =
    state?.roomType || booking.roomId?.roomType || "—";

  const guests = state?.guests ?? booking.guests ?? 1;

  const formatDate = (date) => {
    if (!date) return "—";

    const parsed = new Date(date);

    if (Number.isNaN(parsed.getTime())) return "—";

    return parsed.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  useEffect(() => {
    const tickTimer = setTimeout(() => setShowTick(true), 250);
    const contentTimer = setTimeout(() => setShowContent(true), 500);
    const toastTimer = setTimeout(() => setShowToast(true), 700);

    return () => {
      clearTimeout(tickTimer);
      clearTimeout(contentTimer);
      clearTimeout(toastTimer);
    };
  }, []);

  const copyTransaction = async () => {
    if (!paymentId) {
      setCopyMessage("Payment ID is not available.");
      return;
    }

    try {
      await navigator.clipboard.writeText(paymentId);
      setCopyMessage("Payment ID copied successfully!");
    } catch {
      setCopyMessage("Copy failed. Please copy the ID manually.");
    }

    setTimeout(() => setCopyMessage(""), 2500);
  };

  return (
    <main className="se-payment-page">
      <div className="se-payment-container">

        {/* Premium Brand Header */}
        <header className="se-premium-header">
          <div className="se-brand">
            <div className="se-brand-icon">S</div>

            <div>
              <h1>StayEase</h1>
              <p>THE ART OF LUXURY STAYS</p>
            </div>
          </div>

          <div className="se-header-status">
            <span className="se-live-dot"></span>
            Booking Receipt
          </div>
        </header>

        {/* Receipt Card */}
        <article className="se-luxury-receipt">

          <div className="se-receipt-top-line"></div>

          {/* Success Section */}
          <section className="se-success-section">
            {showTick && (
              <div className="se-success-animation">
                <div className="se-success-ring">
                  <span>✓</span>
                </div>
              </div>
            )}

            <p className="se-eyebrow">PAYMENT CONFIRMATION</p>

            <h2>Payment Successful</h2>

            <p className="se-success-description">
              Thank you for choosing StayEase.
              Your payment details are displayed below.
            </p>

            <PaymentSuccessBadge />
          </section>

          {/* Amount Highlight */}
          <section className="se-payment-hero">
            <div className="se-payment-hero-content">
              <span className="se-amount-label">
                TOTAL AMOUNT PAID
              </span>

              <h3>
                ₹{amount.toLocaleString("en-IN")}
              </h3>

              <div className="se-paid-status">
                <span>✓</span> Payment received
              </div>
            </div>

            <div className="se-hero-watermark">S</div>
          </section>

          {showContent && (
            <div className="se-receipt-content">

              {/* Booking Information */}
              <section className="se-info-section">
                <div className="se-section-title">
                  <div className="se-title-icon">01</div>

                  <div>
                    <h3>Booking Details</h3>
                    <p>Your stay information</p>
                  </div>
                </div>

                <div className="se-info-grid">
                  <div className="se-info-item">
                    <span className="se-info-label">Hotel</span>
                    <strong>{hotelName}</strong>
                  </div>

                  <div className="se-info-item">
                    <span className="se-info-label">Room Number</span>
                    <strong>{roomNumber}</strong>
                  </div>

                  <div className="se-info-item">
                    <span className="se-info-label">Room Type</span>
                    <strong>{roomType}</strong>
                  </div>

                  <div className="se-info-item">
                    <span className="se-info-label">Guests</span>
                    <strong>{guests}</strong>
                  </div>

                  <div className="se-info-item">
                    <span className="se-info-label">Check-in</span>
                    <strong>
                      {formatDate(state?.checkIn || booking.checkIn)}
                    </strong>
                  </div>

                  <div className="se-info-item">
                    <span className="se-info-label">Check-out</span>
                    <strong>
                      {formatDate(state?.checkOut || booking.checkOut)}
                    </strong>
                  </div>
                </div>

                <div className="se-reference-box">
                  <div>
                    <span className="se-info-label">BOOKING REFERENCE</span>
                    <strong className="se-reference-id">
                      {bookingId || "Not available"}
                    </strong>
                  </div>

                  <span className="se-reference-icon">▤</span>
                </div>
              </section>

              {/* Payment Information */}
              <section className="se-info-section">
                <div className="se-section-title">
                  <div className="se-title-icon">02</div>

                  <div>
                    <h3>Payment Information</h3>
                    <p>Transaction details and receipt</p>
                  </div>
                </div>

                <div className="se-transaction-list">
                  <div className="se-transaction-row">
                    <span>Payment Status</span>
                    <strong className="se-status-success">
                      <span>✓</span> Paid
                    </strong>
                  </div>

                  <div className="se-transaction-row">
                    <span>Payment Method</span>
                    <strong>
                      {state?.method?.toUpperCase() || "RAZORPAY"}
                    </strong>
                  </div>

                  <div className="se-transaction-row">
                    <span>Payment Time</span>
                    <strong>{paymentTime}</strong>
                  </div>

                  <div className="se-transaction-row se-payment-id-row">
                    <span>Razorpay Payment ID</span>
                    <strong className="se-payment-id">
                      {paymentId || "Not available"}
                    </strong>
                  </div>
                </div>

                {!paymentId && (
                  <div className="se-payment-warning">
                    Payment ID was not passed to this page.
                    Please check your payment verification response.
                  </div>
                )}
              </section>

              {/* Thank You Note */}
              <section className="se-thankyou-section">
                <div className="se-thankyou-icon">✦</div>

                <h3>Thank You for Staying with Us</h3>

                <p>
                  We look forward to making your stay
                  comfortable, memorable and exceptional.
                </p>
              </section>

              {/* Actions */}
              <div className="se-receipt-actions">
                <button
                  type="button"
                  className="se-btn se-btn-primary"
                  onClick={() =>
                    navigate("/my-bookings", { replace: true })
                  }
                >
                  <span>▣</span>
                  View My Bookings
                </button>

                <button
                  type="button"
                  className="se-btn se-btn-outline"
                  onClick={copyTransaction}
                  disabled={!paymentId}
                >
                  <span>⧉</span>
                  Copy Payment ID
                </button>

                <button
                  type="button"
                  className="se-btn se-btn-outline"
                  onClick={() => window.print()}
                >
                  <span>⇩</span>
                  Print / Save PDF
                </button>

                <button
                  type="button"
                  className="se-home-link"
                  onClick={() => navigate("/", { replace: true })}
                >
                  ← Back to Home
                </button>
              </div>

              {copyMessage && (
                <div className="se-copy-message" role="status">
                  ✓ {copyMessage}
                </div>
              )}
            </div>
          )}

          {/* Footer */}
          <footer className="se-premium-footer">
            <div className="se-footer-brand">StayEase</div>

            <p>
              YOUR COMFORT, OUR PRIORITY
            </p>

            <span>Thank you for trusting us with your stay.</span>
          </footer>
        </article>

        <p className="se-bottom-note">
          Please retain your booking reference for future assistance.
        </p>
      </div>

      <ToastNotification
        message="Your hotel booking payment was successful!"
        type="success"
        show={showToast}
        onClose={() => setShowToast(false)}
      />

      <style>{`
        .se-payment-page {
          min-height: 100vh;
          padding: 38px 18px 28px;
          background:
            radial-gradient(ellipse at top left, rgba(212,175,55,.10), transparent 35%),
            linear-gradient(135deg, #f4f6fa 0%, #edf2f7 50%, #f8f5ed 100%);
          color: #172b43;
          font-family: Inter, "Segoe UI", sans-serif;
        }

        .se-payment-container {
          width: 100%;
          max-width: 850px;
          margin: 0 auto;
        }

        .se-premium-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 18px;
          margin-bottom: 22px;
          padding: 0 8px;
        }

        .se-brand {
          display: flex;
          align-items: center;
          gap: 13px;
        }

        .se-brand-icon {
          display: grid;
          place-items: center;
          width: 52px;
          height: 52px;
          border: 1px solid #c5a75b;
          border-radius: 15px;
          background: #10253e;
          color: #e5ca80;
          font-family: Georgia, serif;
          font-size: 29px;
          font-weight: 700;
          box-shadow: 0 7px 18px rgba(16,37,62,.14);
        }

        .se-brand h1 {
          margin: 0;
          color: #10253e;
          font-family: Georgia, serif;
          font-size: 28px;
          font-weight: 700;
          letter-spacing: .3px;
        }

        .se-brand p {
          margin: 4px 0 0;
          color: #9a7b34;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 2px;
        }

        .se-header-status {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 10px 14px;
          border: 1px solid #e0e6ed;
          border-radius: 30px;
          background: rgba(255,255,255,.75);
          color: #516176;
          font-size: 12px;
          font-weight: 700;
        }

        .se-live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #20a464;
        }

        .se-luxury-receipt {
          position: relative;
          overflow: hidden;
          border: 1px solid rgba(205,175,104,.3);
          border-radius: 22px;
          background: #fff;
          box-shadow: 0 24px 75px rgba(22,42,65,.12);
        }

        .se-receipt-top-line {
          height: 5px;
          background: linear-gradient(90deg, #94722e, #e8d49b, #a98539, #e8d49b);
        }

        .se-success-section {
          padding: 42px 26px 30px;
          text-align: center;
        }

        .se-success-animation {
          margin-bottom: 20px;
          animation: se-success-appear .55s ease-out;
        }

        .se-success-ring {
          display: grid;
          place-items: center;
          width: 86px;
          height: 86px;
          margin: 0 auto;
          border: 1px solid #a5dfba;
          border-radius: 50%;
          background: linear-gradient(145deg, #effcf3, #d9f5e3);
          box-shadow: 0 0 0 8px #f4fbf6, 0 10px 25px rgba(22,163,74,.10);
          color: #15803d;
          font-size: 48px;
          font-weight: 700;
        }

        .se-eyebrow {
          margin: 0 0 10px;
          color: #a18137;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 2.4px;
        }

        .se-success-section h2 {
          margin: 0 0 12px;
          color: #10253e;
          font-family: Georgia, "Times New Roman", serif;
          font-size: clamp(28px, 5vw, 39px);
          font-weight: 700;
        }

        .se-success-description {
          max-width: 460px;
          margin: 0 auto 20px;
          color: #778496;
          font-size: 14px;
          line-height: 1.8;
        }

        .se-payment-success-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 16px;
          border: 1px solid #b8e7c8;
          border-radius: 30px;
          background: #effaf2;
          color: #187344;
          font-size: 12px;
          font-weight: 800;
          letter-spacing: .15px;
        }

        .se-payment-badge-tick {
          display: inline-grid;
          place-items: center;
          width: 21px;
          height: 21px;
          border-radius: 50%;
          background: #21874d;
          color: #fff;
          font-size: 13px;
          font-weight: 900;
        }

        .se-payment-hero {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          min-height: 172px;
          overflow: hidden;
          margin: 0 30px 32px;
          padding: 27px 20px;
          border: 1px solid rgba(225,202,143,.45);
          border-radius: 16px;
          background: linear-gradient(120deg, #10253e 0%, #173c52 65%, #20544f 100%);
          text-align: center;
        }

        .se-payment-hero-content {
          position: relative;
          z-index: 2;
        }

        .se-amount-label {
          color: #dfc985;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 2px;
        }

        .se-payment-hero h3 {
          margin: 10px 0 12px;
          color: #fff;
          font-family: Georgia, serif;
          font-size: clamp(34px, 6vw, 46px);
          font-weight: 700;
          overflow-wrap: anywhere;
        }

        .se-paid-status {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border: 1px solid rgba(255,255,255,.19);
          border-radius: 30px;
          background: rgba(255,255,255,.09);
          color: #e7f9ed;
          font-size: 11px;
          font-weight: 700;
        }

        .se-paid-status span {
          color: #87e3a6;
          font-size: 14px;
        }

        .se-hero-watermark {
          position: absolute;
          right: 20px;
          bottom: -65px;
          color: rgba(255,255,255,.045);
          font-family: Georgia, serif;
          font-size: 210px;
          font-weight: 800;
          line-height: 1;
          pointer-events: none;
        }

        .se-receipt-content {
          padding: 0 30px 32px;
          animation: se-content-appear .5s ease-out;
        }

        .se-info-section {
          margin-bottom: 25px;
          padding: 25px;
          border: 1px solid #e8edf2;
          border-radius: 15px;
          background: #fff;
        }

        .se-section-title {
          display: flex;
          align-items: center;
          gap: 13px;
          margin-bottom: 24px;
          padding-bottom: 18px;
          border-bottom: 1px solid #edf0f4;
        }

        .se-title-icon {
          display: grid;
          place-items: center;
          flex-shrink: 0;
          width: 43px;
          height: 43px;
          border: 1px solid #e7d7ac;
          border-radius: 12px;
          background: #fbf7ec;
          color: #98762d;
          font-size: 13px;
          font-weight: 900;
        }

        .se-section-title h3 {
          margin: 0 0 5px;
          color: #162b43;
          font-size: 17px;
          font-weight: 800;
        }

        .se-section-title p {
          margin: 0;
          color: #8994a3;
          font-size: 12px;
        }

        .se-info-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 25px 22px;
        }

        .se-info-item {
          min-width: 0;
        }

        .se-info-label {
          display: block;
          margin-bottom: 8px;
          color: #8994a3;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 1px;
          text-transform: uppercase;
        }

        .se-info-item strong {
          display: block;
          color: #1b2d42;
          font-size: 14px;
          font-weight: 700;
          overflow-wrap: anywhere;
        }

        .se-reference-box {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
          margin-top: 28px;
          padding: 17px;
          border: 1px dashed #d7dfe8;
          border-radius: 12px;
          background: #f8fafc;
        }

        .se-reference-id {
          display: block;
          color: #17334e;
          font-size: 13px;
          overflow-wrap: anywhere;
        }

        .se-reference-icon {
          color: #b3944e;
          font-size: 28px;
        }

        .se-transaction-list {
          display: flex;
          flex-direction: column;
          gap: 0;
        }

        .se-transaction-row {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 20px;
          padding: 15px 0;
          border-bottom: 1px solid #eff2f5;
          color: #7d8998;
          font-size: 13px;
        }

        .se-transaction-row:last-child {
          border-bottom: 0;
        }

        .se-transaction-row > strong {
          color: #1b2d42;
          font-size: 12px;
          text-align: right;
          overflow-wrap: anywhere;
        }

        .se-status-success {
          color: #18834b !important;
        }

        .se-status-success span {
          margin-right: 4px;
        }

        .se-payment-id-row {
          flex-direction: column;
          gap: 9px;
        }

        .se-payment-id-row > strong {
          width: 100%;
          text-align: left;
          font-size: 12px;
        }

        .se-payment-warning {
          margin-top: 15px;
          padding: 13px;
          border: 1px solid #f1dfb5;
          border-radius: 10px;
          background: #fff9e9;
          color: #815c17;
          font-size: 12px;
          line-height: 1.6;
        }

        .se-thankyou-section {
          padding: 24px 18px;
          text-align: center;
        }

        .se-thankyou-icon {
          margin-bottom: 10px;
          color: #b0924b;
          font-size: 27px;
        }

        .se-thankyou-section h3 {
          margin: 0 0 9px;
          color: #18324a;
          font-family: Georgia, serif;
          font-size: 22px;
          font-weight: 700;
        }

        .se-thankyou-section p {
          max-width: 430px;
          margin: 0 auto;
          color: #8290a0;
          font-size: 13px;
          line-height: 1.8;
        }

        .se-receipt-actions {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 12px;
          margin-top: 8px;
        }

        .se-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          min-height: 49px;
          padding: 12px 15px;
          border: 1px solid transparent;
          border-radius: 10px;
          font-size: 12px;
          font-weight: 800;
          cursor: pointer;
          transition: transform .2s ease, box-shadow .2s ease, background .2s ease;
        }

        .se-btn:hover:not(:disabled) {
          transform: translateY(-2px);
        }

        .se-btn:disabled {
          cursor: not-allowed;
          opacity: .5;
        }

        .se-btn-primary {
          background: linear-gradient(110deg, #10253e, #1b4654);
          color: #fff;
          box-shadow: 0 7px 16px rgba(16,37,62,.13);
        }

        .se-btn-primary:hover {
          box-shadow: 0 10px 23px rgba(16,37,62,.2);
        }

        .se-btn-outline {
          border-color: #dfe5eb;
          background: #fff;
          color: #344a60;
        }

        .se-btn-outline:hover:not(:disabled) {
          border-color: #c8ae69;
          background: #fdfbf5;
        }

        .se-home-link {
          grid-column: 1 / -1;
          justify-self: center;
          margin-top: 5px;
          padding: 10px;
          border: 0;
          background: transparent;
          color: #7b8795;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
        }

        .se-home-link:hover {
          color: #a18137;
        }

        .se-copy-message {
          margin-top: 15px;
          padding: 12px;
          border: 1px solid #bce5c9;
          border-radius: 10px;
          background: #effaf2;
          color: #187344;
          font-size: 13px;
          text-align: center;
        }

        .se-premium-footer {
          padding: 25px 18px;
          border-top: 1px solid #edf0f4;
          background: #fafbfd;
          text-align: center;
        }

        .se-footer-brand {
          color: #17304a;
          font-family: Georgia, serif;
          font-size: 21px;
          font-weight: 700;
        }

        .se-premium-footer p {
          margin: 5px 0 9px;
          color: #a18137;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 2px;
        }

        .se-premium-footer > span {
          color: #8a95a3;
          font-size: 11px;
        }

        .se-bottom-note {
          margin: 18px 0 0;
          color: #7f8a98;
          font-size: 11px;
          text-align: center;
        }

        @keyframes se-success-appear {
          from {
            opacity: 0;
            transform: scale(.7);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes se-content-appear {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @media (max-width: 600px) {
          .se-payment-page {
            padding: 22px 12px;
          }

          .se-premium-header {
            align-items: flex-start;
            padding: 0 2px;
          }

          .se-brand-icon {
            width: 45px;
            height: 45px;
          }

          .se-brand h1 {
            font-size: 24px;
          }

          .se-brand p {
            font-size: 8px;
            letter-spacing: 1.2px;
          }

          .se-header-status {
            padding: 8px 10px;
            font-size: 10px;
          }

          .se-luxury-receipt {
            border-radius: 17px;
          }

          .se-success-section {
            padding: 34px 16px 25px;
          }

          .se-payment-hero {
            margin: 0 15px 24px;
            min-height: 155px;
          }

          .se-receipt-content {
            padding: 0 15px 24px;
          }

          .se-info-section {
            padding: 18px 15px;
          }

          .se-info-grid {
            gap: 22px 12px;
          }

          .se-info-item strong {
            font-size: 12px;
          }

          .se-transaction-row {
            gap: 12px;
            font-size: 12px;
          }

          .se-transaction-row > strong {
            max-width: 60%;
          }

          .se-payment-id-row > strong {
            max-width: 100%;
          }

          .se-receipt-actions {
            grid-template-columns: 1fr;
          }

          .se-home-link {
            grid-column: auto;
          }
        }

        @media print {
          body {
            background: #fff !important;
          }

          .se-payment-page {
            min-height: 0 !important;
            padding: 0 !important;
            background: #fff !important;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }

          .se-payment-container {
            max-width: none !important;
          }

          .se-premium-header {
            margin-bottom: 12px;
          }

          .se-luxury-receipt {
            border: 1px solid #ddd !important;
            border-radius: 0 !important;
            box-shadow: none !important;
          }

          .se-receipt-actions,
          .se-copy-message,
          .se-bottom-note,
          .se-toast {
            display: none !important;
          }

          .se-payment-hero,
          .se-info-section,
          .se-thankyou-section,
          .se-premium-footer {
            break-inside: avoid;
          }

          .se-payment-hero,
          .se-premium-header,
          .se-premium-footer {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }

          @page {
            size: A4;
            margin: 12mm;
          }
        }
      `}</style>
    </main>
  );
}

export default PaymentSuccess;
