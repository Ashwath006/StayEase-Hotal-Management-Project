
import {
  FaPhoneAlt,
  FaEnvelope,
  FaMapMarkerAlt,
  FaClock,
  FaArrowRight,
  FaShieldAlt,
  FaGem,
  FaHeart,
  FaGlobeAsia,
  FaStar,
  FaCheckCircle,
  FaQuoteRight,
  FaCrown,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import "../styles/home.css";
import "../styles/About.css";

const teamMembers = [
  {
    name: "Ashwath",
    role: "Founder & CEO",
    image:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=500&q=85",
    description: "Building exceptional travel experiences.",
  },
  {
    name: "Arjun",
    role: "Operations Manager",
    image:
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=500&q=85",
    description: "Ensuring every stay feels effortless.",
  },
  {
    name: "G-Tec",
    role: "Customer Support",
    image:
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=500&q=85",
    description: "Here to make every guest feel valued.",
  },
];

const features = [
  {
    icon: <FaGem />,
    number: "01",
    title: "Exceptional Stays",
    description:
      "Discover carefully selected hotels and premium resorts designed for memorable experiences.",
  },
  {
    icon: <FaStar />,
    number: "02",
    title: "Outstanding Value",
    description:
      "Explore available rates and offers to find the right stay for your travel plans.",
  },
  {
    icon: <FaShieldAlt />,
    number: "03",
    title: "Secure Reservations",
    description:
      "Enjoy a streamlined reservation experience with secure payment processing.",
  },
  {
    icon: <FaHeart />,
    number: "04",
    title: "Guest-First Service",
    description:
      "We put comfort, convenience, and a welcoming experience at the heart of every stay.",
  },
];

const values = [
  {
    icon: <FaShieldAlt />,
    title: "Trust",
    description:
      "Clear information and a booking experience built around confidence.",
  },
  {
    icon: <FaCrown />,
    title: "Luxury",
    description:
      "Thoughtfully presented stays for travelers who appreciate quality.",
  },
  {
    icon: <FaHeart />,
    title: "Comfort",
    description:
      "Making every stage of your journey feel easier and more enjoyable.",
  },
  {
    icon: <FaGlobeAsia />,
    title: "Innovation",
    description:
      "Modern technology that helps simplify the way you discover and book.",
  },
];

function About() {
  return (
    <main className="se-about">
      {/* HERO */}
      <section className="se-about-hero">
        <div className="se-about-hero-pattern" />

        <div className="container position-relative">
          <div className="row align-items-center g-5">
            <div className="col-lg-6">
              <div className="se-about-hero-copy">
                <span className="se-about-eyebrow">
                  <span className="se-about-eyebrow-line" />
                  THE ART OF HOSPITALITY
                </span>

                <h1>
                  Redefining
                  <br />
                  <span>Luxury</span> Hotel
                  <br />
                  Experiences.
                </h1>

                <p className="se-about-lead">
                  Every journey deserves something extraordinary.
                  Discover remarkable destinations, thoughtfully
                  selected stays, and a more seamless way to travel
                  with StayEase.
                </p>

                <div className="se-about-hero-actions">
                  <Link to="/hotels" className="se-about-gold-btn">
                    Explore Hotels <FaArrowRight />
                  </Link>

                  <Link to="/contact" className="se-about-outline-btn">
                    Contact Us
                  </Link>
                </div>

                <div className="se-about-hero-note">
                  <span className="se-about-note-icon">
                    <FaCheckCircle />
                  </span>
                  <span>
                    <strong>Thoughtful stays. Memorable journeys.</strong>
                    <small>Your next escape begins here.</small>
                  </span>
                </div>
              </div>
            </div>

            <div className="col-lg-6">
              <div className="se-about-hero-visual">
                <div className="se-about-image-frame">
                  <img
                    src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=85"
                    alt="Elegant luxury hotel and resort"
                    className="se-about-hero-image"
                  />

                  <div className="se-about-image-shade" />

                  <div className="se-about-image-caption">
                    <span>THE STAYEASE EXPERIENCE</span>
                    <h3>Where every stay feels special.</h3>
                  </div>
                </div>

                <div className="se-about-floating-card">
                  <span className="se-about-floating-icon">
                    <FaCrown />
                  </span>
                  <div>
                    <strong>Stay in Style</strong>
                    <span>Travel beyond ordinary.</span>
                  </div>
                </div>

                <div className="se-about-image-decoration">
                  <span>✦</span>
                  <span>STAYEASE</span>
                  <span>✦</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* OUR STORY */}
      <section className="se-about-story">
        <div className="container">
          <div className="row align-items-center g-5">
            <div className="col-lg-6">
              <div className="se-about-story-visual">
                <img
                  src="https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1000&q=85"
                  alt="Beautiful hotel interiors"
                  className="se-about-story-image"
                />

                <div className="se-about-story-stamp">
                  <FaCrown />
                  <span>THE STAYEASE</span>
                  <strong>STANDARD</strong>
                </div>
              </div>
            </div>

            <div className="col-lg-6">
              <div className="se-about-section-copy">
                <span className="se-about-eyebrow">
                  <span className="se-about-eyebrow-line" />
                  OUR STORY
                </span>

                <h2>
                  Hospitality With
                  <br />
                  <span>Heart & Purpose.</span>
                </h2>

                <p>
                  At StayEase, we believe that travel is about more
                  than reaching a destination. It is about the moments
                  you experience, the comfort you enjoy, and the
                  memories you take home.
                </p>

                <p>
                  Our vision is to make discovering and booking
                  accommodation simpler by bringing hotel information,
                  room choices, and reservations together in one
                  convenient experience.
                </p>

                <p>
                  From relaxing holidays to important business trips,
                  we want every traveler to feel confident when
                  choosing their next stay.
                </p>

                <div className="se-about-story-signature">
                  <span className="se-about-signature-mark">
                    <FaCrown />
                  </span>
                  <span>
                    <strong>The StayEase Philosophy</strong>
                    <small>Comfort in every detail.</small>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="se-about-features">
        <div className="container">
          <div className="se-about-section-heading">
            <span className="se-about-eyebrow">
              <span className="se-about-eyebrow-line" />
              WHY STAYEASE
              <span className="se-about-eyebrow-line" />
            </span>

            <h2>
              A Better Way to
              <br />
              <span>Experience Travel.</span>
            </h2>

            <p>
              The details matter. We focus on making the journey from
              discovering a stay to completing a reservation feel
              clear, convenient, and welcoming.
            </p>
          </div>

          <div className="row g-4">
            {features.map((feature) => (
              <div className="col-lg-3 col-md-6" key={feature.number}>
                <article className="se-about-feature-card">
                  <div className="se-about-feature-top">
                    <span className="se-about-feature-icon">
                      {feature.icon}
                    </span>
                    <span className="se-about-feature-number">
                      {feature.number}
                    </span>
                  </div>

                  <h3>{feature.title}</h3>
                  <p>{feature.description}</p>

                  <span className="se-about-feature-bottom">
                    <span />
                  </span>
                </article>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MISSION & VISION */}
      <section className="se-about-purpose">
        <div className="container">
          <div className="se-about-purpose-heading">
            <span className="se-about-eyebrow">
              <span className="se-about-eyebrow-line" />
              OUR PURPOSE
            </span>
            <h2>
              Guided by Purpose.
              <br />
              <span>Driven by Possibility.</span>
            </h2>
          </div>

          <div className="row g-4">
            <div className="col-lg-6">
              <article className="se-about-purpose-card">
                <span className="se-about-purpose-icon">
                  <FaGem />
                </span>

                <span className="se-about-purpose-label">
                  OUR MISSION
                </span>

                <h3>
                  Making Every
                  <br />
                  Stay Feel Extraordinary.
                </h3>

                <p>
                  To simplify hotel discovery and booking through a
                  convenient platform that prioritizes guest comfort,
                  clear information, and a dependable reservation
                  experience.
                </p>

                <span className="se-about-purpose-number">01</span>
              </article>
            </div>

            <div className="col-lg-6">
              <article className="se-about-purpose-card se-about-vision-card">
                <span className="se-about-purpose-icon">
                  <FaGlobeAsia />
                </span>

                <span className="se-about-purpose-label">
                  OUR VISION
                </span>

                <h3>
                  Inspiring a New
                  <br />
                  Standard of Travel.
                </h3>

                <p>
                  To build a trusted hotel booking experience that
                  connects travelers with memorable destinations and
                  makes planning a stay more accessible and enjoyable.
                </p>

                <span className="se-about-purpose-number">02</span>
              </article>
            </div>
          </div>
        </div>
      </section>

      {/* CORE VALUES */}
      <section className="se-about-values">
        <div className="container">
          <div className="se-about-section-heading">
            <span className="se-about-eyebrow">
              <span className="se-about-eyebrow-line" />
              WHAT WE BELIEVE
              <span className="se-about-eyebrow-line" />
            </span>

            <h2>
              The Values Behind
              <br />
              <span>Every Experience.</span>
            </h2>
          </div>

          <div className="row g-4">
            {values.map((value, index) => (
              <div className="col-lg-3 col-md-6" key={value.title}>
                <article className="se-about-value-card">
                  <div className="se-about-value-icon">{value.icon}</div>

                  <span className="se-about-value-index">
                    0{index + 1}
                  </span>

                  <h3>{value.title}</h3>
                  <p>{value.description}</p>
                </article>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ACHIEVEMENTS */}
      <section className="se-about-stats">
        <div className="container">
          <div className="se-about-stats-inner">
            <div className="se-about-stats-heading">
              <span className="se-about-eyebrow">
                <span className="se-about-eyebrow-line" />
                THE STAYEASE JOURNEY
              </span>

              <h2>
                Every Journey
                <br />
                <span>Starts With Trust.</span>
              </h2>

              <p>
                Our ambition is to create better booking experiences
                and lasting connections between travelers and stays.
              </p>
            </div>

            <div className="se-about-stats-grid">
              <div className="se-about-stat">
                <FaHeart />
                <strong>Guest First</strong>
                <span>Designed around your stay</span>
              </div>

              <div className="se-about-stat">
                <FaShieldAlt />
                <strong>Secure Payments</strong>
                <span>Protected payment processing</span>
              </div>

              <div className="se-about-stat">
                <FaGlobeAsia />
                <strong>Discover More</strong>
                <span>Explore different destinations</span>
              </div>

              <div className="se-about-stat">
                <FaStar />
                <strong>Better Experiences</strong>
                <span>Focused on comfort and ease</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* OUR TEAM */}
      <section className="se-about-team">
        <div className="container">
          <div className="se-about-section-heading">
            <span className="se-about-eyebrow">
              <span className="se-about-eyebrow-line" />
              THE PEOPLE BEHIND THE EXPERIENCE
              <span className="se-about-eyebrow-line" />
            </span>

            <h2>
              Meet the People
              <br />
              <span>Behind StayEase.</span>
            </h2>

            <p>
              A team focused on making your hotel discovery and
              reservation experience better.
            </p>
          </div>

          <div className="row g-4 justify-content-center">
            {teamMembers.map((member, index) => (
              <div className="col-lg-4 col-md-6" key={member.name}>
                <article className="se-about-team-card">
                  <div className="se-about-team-image-wrap">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="se-about-team-image"
                      loading="lazy"
                      onError={(event) => {
                        event.currentTarget.onerror = null;
                        event.currentTarget.src =
                          "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=500&q=85";
                      }}
                    />

                    <span className="se-about-team-index">
                      0{index + 1}
                    </span>

                    <div className="se-about-team-image-overlay" />
                  </div>

                  <div className="se-about-team-info">
                    <span className="se-about-team-role">{member.role}</span>
                    <h3>{member.name}</h3>
                    <p>{member.description}</p>
                    <span className="se-about-team-rule" />
                  </div>
                </article>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* QUOTE */}
      <section className="se-about-quote">
        <div className="container">
          <FaQuoteRight className="se-about-quote-icon" />

          <p>
            Great hospitality is not simply about where you stay.
            It is about how the experience makes you feel.
          </p>

          <span className="se-about-quote-caption">
            THE STAYEASE BELIEF
          </span>
        </div>
      </section>

      {/* CONTACT STRIP */}
      <section className="se-about-contact-strip">
        <div className="container">
          <div className="row g-4">
            <div className="col-md-4">
              <div className="se-about-contact-item">
                <span><FaEnvelope /></span>
                <div>
                  <strong>Email Us</strong>
                  <p>Reach out through our contact page.</p>
                  <Link to="/contact">Contact StayEase <FaArrowRight /></Link>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="se-about-contact-item">
                <span><FaMapMarkerAlt /></span>
                <div>
                  <strong>Discover Destinations</strong>
                  <p>Explore available hotels and locations.</p>
                  <Link to="/hotels">Explore Hotels <FaArrowRight /></Link>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="se-about-contact-item">
                <span><FaClock /></span>
                <div>
                  <strong>Plan Your Stay</strong>
                  <p>Find a stay that fits your travel plans.</p>
                  <Link to="/hotels">Start Exploring <FaArrowRight /></Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="se-about-cta">
        <div className="container">
          <div className="se-about-cta-card">
            <div className="se-about-cta-decoration se-about-cta-decoration-one" />
            <div className="se-about-cta-decoration se-about-cta-decoration-two" />

            <div className="se-about-cta-content">
              <span className="se-about-eyebrow">
                <span className="se-about-eyebrow-line" />
                YOUR NEXT CHAPTER
                <span className="se-about-eyebrow-line" />
              </span>

              <h2>
                Your Perfect Stay
                <br />
                <span>Is Waiting.</span>
              </h2>

              <p>
                Discover a new destination, find your ideal room,
                and make your next journey one to remember.
              </p>

              <Link to="/hotels" className="se-about-gold-btn">
                Explore Hotels <FaArrowRight />
              </Link>
            </div>

            <div className="se-about-cta-crown">
              <FaCrown />
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

export default About;
