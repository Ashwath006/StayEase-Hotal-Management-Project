import { useEffect, useState } from "react";
import {
  FaUser,
  FaEnvelope,
  FaPhoneAlt,
  FaShieldAlt,
  FaCalendarAlt,
  FaEdit,
  FaSave,
  FaTimes,
  FaCrown,
  FaCheckCircle,
} from "react-icons/fa";
import { toast } from "react-toastify";
import API from "../services/api";
import "../styles/profile.css";

function Profile() {
  const getLocalUser = () => {
    try {
      return JSON.parse(localStorage.getItem("user") || "null");
    } catch {
      return null;
    }
  };

  const [localUser, setLocalUser] = useState(getLocalUser);
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [user, setUser] = useState({
    name: "",
    email: "",
    phone: "",
    role: "",
    createdAt: "",
  });

  const [originalUser, setOriginalUser] = useState(null);

  useEffect(() => {
    const storedUser = getLocalUser();
    setLocalUser(storedUser);

    if (!storedUser?._id) {
      toast.error("User not found in storage");
      setLoading(false);
      return;
    }

    fetchProfile(storedUser._id);
  }, []);

  const fetchProfile = async (userId) => {
    try {
      setLoading(true);

      const res = await API.get(`/users/${userId}`);
      const data = res.data.user || res.data;

      setUser({
        name: data.name || "",
        email: data.email || "",
        phone: data.phone || "",
        role: data.role || "user",
        createdAt: data.createdAt || "",
      });

      setOriginalUser({
        name: data.name || "",
        email: data.email || "",
        phone: data.phone || "",
        role: data.role || "user",
        createdAt: data.createdAt || "",
      });
    } catch (err) {
      toast.error(
        err.response?.data?.message || "Failed to load profile"
      );
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setUser((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const cancelEditing = () => {
    if (originalUser) {
      setUser({ ...originalUser });
    }

    setEditing(false);
  };

  const updateProfile = async (e) => {
    e.preventDefault();

    if (!localUser?._id) {
      toast.error("Please login again");
      return;
    }

    if (!user.name.trim()) {
      toast.error("Name is required");
      return;
    }

    try {
      setSaving(true);

      const res = await API.put(`/users/${localUser._id}`, {
        name: user.name.trim(),
        phone: user.phone.trim(),
      });

      const updatedUser = res.data.user || res.data;

      const finalUser = {
        ...user,
        ...updatedUser,
        name: updatedUser.name ?? user.name.trim(),
        email: updatedUser.email ?? user.email,
        phone: updatedUser.phone ?? user.phone.trim(),
        role: updatedUser.role ?? user.role,
        createdAt: updatedUser.createdAt ?? user.createdAt,
      };

      setUser(finalUser);
      setOriginalUser(finalUser);

      const storedUser = {
        ...getLocalUser(),
        ...updatedUser,
      };

      localStorage.setItem("user", JSON.stringify(storedUser));
      setLocalUser(storedUser);

      toast.success(res.data.message || "Profile updated successfully");
      setEditing(false);
    } catch (err) {
      toast.error(
        err.response?.data?.message || "Profile update failed"
      );
    } finally {
      setSaving(false);
    }
  };

  const memberSince = user.createdAt
    ? new Date(user.createdAt).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "long",
        year: "numeric",
      })
    : "Not available";

  const displayRole = user.role
    ? user.role.charAt(0).toUpperCase() + user.role.slice(1)
    : "Member";

  const initials = user.name
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join("");

  if (loading) {
    return (
      <main className="se-profile-page">
        <div className="se-profile-loading">
          <div className="se-profile-spinner" />
          <p>Preparing your profile...</p>
        </div>
      </main>
    );
  }

  return (
    <main className="se-profile-page">
      {/* HERO */}
      <section className="se-profile-hero">
        <div className="se-profile-hero-pattern" />

        <div className="container se-profile-hero-content">
          <span className="se-profile-eyebrow">
            <FaCrown /> YOUR STAYEASE ACCOUNT
          </span>

          <h1>
            My <span>Profile</span>
          </h1>

          <p>
            Your personal space to manage your details and account
            information.
          </p>

          <div className="se-profile-breadcrumb">
            <span>Home</span>
            <span>/</span>
            <strong>My Profile</strong>
          </div>
        </div>

        <div className="se-profile-hero-line" />
      </section>

      {/* PROFILE CONTENT */}
      <section className="se-profile-main">
        <div className="container">
          <div className="se-profile-layout">
            {/* LEFT PROFILE CARD */}
            <aside className="se-profile-sidebar">
              <div className="se-profile-user-card">
                <div className="se-profile-avatar-wrap">
                  <div className="se-profile-avatar">
                    {initials || <FaUser />}
                  </div>

                  <span className="se-profile-avatar-status" />
                </div>

                <span className="se-profile-member-label">
                  STAYEASE MEMBER
                </span>

                <h2>{user.name || "Guest User"}</h2>

                <p className="se-profile-user-email">
                  {user.email || "No email available"}
                </p>

                <div className="se-profile-role-badge">
                  <FaCrown />
                  {displayRole}
                </div>

                <div className="se-profile-divider" />

                <div className="se-profile-sidebar-detail">
                  <span className="se-profile-sidebar-icon">
                    <FaCalendarAlt />
                  </span>

                  <div>
                    <span>MEMBER SINCE</span>
                    <p>{memberSince}</p>
                  </div>
                </div>

                <div className="se-profile-sidebar-detail">
                  <span className="se-profile-sidebar-icon">
                    <FaShieldAlt />
                  </span>

                  <div>
                    <span>ACCOUNT TYPE</span>
                    <p>{displayRole} Account</p>
                  </div>
                </div>

                <div className="se-profile-trust-note">
                  <FaCheckCircle />
                  <span>Your account details are managed securely.</span>
                </div>
              </div>
            </aside>

            {/* RIGHT PROFILE FORM */}
            <section className="se-profile-details-card">
              <div className="se-profile-details-heading">
                <div>
                  <span className="se-profile-section-label">
                    PERSONAL INFORMATION
                  </span>

                  <h2>Account Details</h2>

                  <p>
                    Review your information and keep your details up to date.
                  </p>
                </div>

                {!editing && (
                  <button
                    type="button"
                    className="se-profile-edit-btn"
                    onClick={() => setEditing(true)}
                  >
                    <FaEdit />
                    Edit Profile
                  </button>
                )}
              </div>

              <div className="se-profile-form-divider" />

              <form onSubmit={updateProfile}>
                <div className="se-profile-form-grid">
                  <div className="se-profile-field">
                    <label htmlFor="profile-name">Full Name</label>

                    <div className="se-profile-input-wrap">
                      <FaUser className="se-profile-input-icon" />

                      <input
                        id="profile-name"
                        type="text"
                        name="name"
                        placeholder="Enter your full name"
                        value={user.name}
                        onChange={handleChange}
                        disabled={!editing || saving}
                        autoComplete="name"
                        required
                      />
                    </div>

                    <small>Your preferred display name.</small>
                  </div>

                  <div className="se-profile-field">
                    <label htmlFor="profile-email">Email Address</label>

                    <div className="se-profile-input-wrap">
                      <FaEnvelope className="se-profile-input-icon" />

                      <input
                        id="profile-email"
                        type="email"
                        value={user.email}
                        disabled
                        autoComplete="email"
                      />

                      <FaShieldAlt className="se-profile-locked-icon" />
                    </div>

                    <small>Email address cannot be changed here.</small>
                  </div>

                  <div className="se-profile-field">
                    <label htmlFor="profile-phone">Phone Number</label>

                    <div className="se-profile-input-wrap">
                      <FaPhoneAlt className="se-profile-input-icon" />

                      <input
                        id="profile-phone"
                        type="tel"
                        name="phone"
                        placeholder="Enter your phone number"
                        value={user.phone}
                        onChange={handleChange}
                        disabled={!editing || saving}
                        autoComplete="tel"
                      />
                    </div>

                    <small>Add a number where we can reach you.</small>
                  </div>

                  <div className="se-profile-field">
                    <label htmlFor="profile-role">Account Role</label>

                    <div className="se-profile-input-wrap">
                      <FaShieldAlt className="se-profile-input-icon" />

                      <input
                        id="profile-role"
                        type="text"
                        value={displayRole}
                        disabled
                      />
                    </div>

                    <small>Your assigned account permissions.</small>
                  </div>

                  <div className="se-profile-field se-profile-field-full">
                    <label htmlFor="profile-member-since">
                      Membership Date
                    </label>

                    <div className="se-profile-input-wrap">
                      <FaCalendarAlt className="se-profile-input-icon" />

                      <input
                        id="profile-member-since"
                        type="text"
                        value={memberSince}
                        disabled
                      />
                    </div>
                  </div>
                </div>

                {editing && (
                  <div className="se-profile-actions">
                    <button
                      type="button"
                      className="se-profile-cancel-btn"
                      onClick={cancelEditing}
                      disabled={saving}
                    >
                      <FaTimes />
                      Cancel
                    </button>

                    <button
                      type="submit"
                      className="se-profile-save-btn"
                      disabled={saving}
                    >
                      <FaSave />
                      {saving ? "Saving..." : "Save Changes"}
                    </button>
                  </div>
                )}
              </form>

              <div className="se-profile-bottom-note">
                <div className="se-profile-note-icon">
                  <FaShieldAlt />
                </div>

                <div>
                  <h3>Your information matters</h3>
                  <p>
                    Your account information is displayed here for your
                    convenience. Contact support if you need help with your
                    account.
                  </p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </section>
    </main>
  );
}

export default Profile;