import { useState } from "react";
import {
  FaMapMarkerAlt,
  FaPhoneAlt,
  FaEnvelope,
  FaClock,
  FaArrowRight,
  FaHeadset,
  FaCheckCircle,
} from "react-icons/fa";
import "../styles/contact.css";

function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setSubmitted(false);
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Frontend demonstration only — connect to backend/API to deliver messages.
    setSubmitted(true);

    setForm({
      name: "",
      email: "",
      subject: "",
      message: "",
    });
  };

  const contactDetails = [
    {
      icon: <FaMapMarkerAlt />,
      title: "Our Headquarters",
      lines: ["StayEase Headquarters", "Chennai, Tamil Nadu, India"],
      className: "location",
    },
    {
      icon: <FaPhoneAlt />,
      title: "Call Our Team",
      lines: ["+91 9442850358", "Available for your assistance"],
      className: "phone",
    },
    {
      icon: <FaEnvelope />,
      title: "Email Support",
      lines: ["ashwathj@gmail.com", "We would love to hear from you"],
      className: "email",
    },
    {
      icon: <FaClock />,
      title: "Working Hours",
      lines: ["Monday – Sunday", "9:00 AM – 9:00 PM"],
      className: "hours",
    },
  ];

  return (
    <main className="se-contact-page">
      {/* HERO */}
      <section className="se-contact-hero">
        <div className="se-contact-hero-overlay" />

        <div className="container se-contact-hero-content">
          <span className="se-contact-eyebrow">
            <span /> WE ARE HERE FOR YOU <span />
          </span>

          <h1>
            Let's Start a <span>Conversation</span>
          </h1>

          <p>
            Questions, plans, or special requests? Our hospitality team is
            always ready to make your StayEase experience exceptional.
          </p>

          <div className="se-contact-hero-note">
            <FaHeadset />
            <span>Your comfort is our priority.</span>
          </div>
        </div>

        <div className="se-contact-hero-bottom" />
      </section>

      {/* CONTACT CONTENT */}
      <section className="se-contact-main">
        <div className="container">
          <div className="se-contact-heading">
            <span className="se-contact-section-label">GET IN TOUCH</span>
            <h2>
              We're Just a <span>Message Away</span>
            </h2>
            <p>
              Whether you need booking assistance or have a question, we are
              happy to help.
            </p>
          </div>

          <div className="row g-4 align-items-stretch">
            {/* LEFT CONTACT INFORMATION */}
            <div className="col-lg-5">
              <div className="se-contact-info-panel">
                <div className="se-contact-info-intro">
                  <span className="se-contact-mini-label">
                    CONTACT INFORMATION
                  </span>

                  <h3>
                    Let's make your next stay <span>unforgettable.</span>
                  </h3>

                  <p>
                    Reach out to our team for booking assistance, enquiries,
                    and support throughout your journey.
                  </p>
                </div>

                <div className="se-contact-details">
                  {contactDetails.map((item) => (
                    <div className="se-contact-detail" key={item.title}>
                      <div
                        className={`se-contact-icon ${item.className}`}
                      >
                        {item.icon}
                      </div>

                      <div>
                        <h4>{item.title}</h4>

                        {item.lines.map((line, index) => (
                          <p
                            className={index === 1 ? "secondary" : ""}
                            key={line}
                          >
                            {line}
                          </p>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="se-contact-info-footer">
                  <div className="se-contact-footer-icon">
                    <FaCheckCircle />
                  </div>

                  <div>
                    <h4>Hospitality, with heart.</h4>
                    <p>Every question deserves a thoughtful answer.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT CONTACT FORM */}
            <div className="col-lg-7">
              <div className="se-contact-form-panel">
                <div className="se-contact-form-heading">
                  <span className="se-contact-section-label">
                    SEND US A MESSAGE
                  </span>

                  <h3>How can we help you?</h3>

                  <p>
                    Fill in the details below and tell us what you need.
                  </p>
                </div>

                {submitted && (
                  <div
                    className="se-contact-success"
                    role="status"
                    aria-live="polite"
                  >
                    <FaCheckCircle />
                    <span>
                      Thank you for reaching out! Your message has been
                      received in this demo.
                    </span>
                  </div>
                )}

                <form onSubmit={handleSubmit}>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label htmlFor="contact-name">Your Name</label>
                      <input
                        id="contact-name"
                        type="text"
                        className="se-contact-input"
                        placeholder="Enter your full name"
                        name="name"
                        value={form.name}
                        onChange={handleChange}
                        autoComplete="name"
                        required
                      />
                    </div>

                    <div className="col-md-6">
                      <label htmlFor="contact-email">Email Address</label>
                      <input
                        id="contact-email"
                        type="email"
                        className="se-contact-input"
                        placeholder="you@example.com"
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        autoComplete="email"
                        required
                      />
                    </div>

                    <div className="col-12">
                      <label htmlFor="contact-subject">Subject</label>
                      <input
                        id="contact-subject"
                        type="text"
                        className="se-contact-input"
                        placeholder="What is your enquiry about?"
                        name="subject"
                        value={form.subject}
                        onChange={handleChange}
                        required
                      />
                    </div>

                    <div className="col-12">
                      <label htmlFor="contact-message">Your Message</label>
                      <textarea
                        id="contact-message"
                        rows="6"
                        className="se-contact-input se-contact-textarea"
                        placeholder="Tell us how we can assist you..."
                        name="message"
                        value={form.message}
                        onChange={handleChange}
                        required
                      />
                    </div>

                    <div className="col-12">
                      <button
                        type="submit"
                        className="se-contact-submit"
                      >
                        <span>Send Your Message</span>
                        <FaArrowRight />
                      </button>

                      <p className="se-contact-privacy">
                        We appreciate your trust in StayEase.
                      </p>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* BOTTOM CTA */}
      <section className="se-contact-bottom">
        <div className="container">
          <div className="se-contact-bottom-card">
            <div>
              <span>THE STAYEASE EXPERIENCE</span>
              <h3>Exceptional stays begin with a simple hello.</h3>
              <p>
                We're here to help you find comfort, confidence, and the
                perfect stay.
              </p>
            </div>

            <a href="mailto:support@stayease.com">
              Email Our Team <FaArrowRight />
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}

export default Contact;