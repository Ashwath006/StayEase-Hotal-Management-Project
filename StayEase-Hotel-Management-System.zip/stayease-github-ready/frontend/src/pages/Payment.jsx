import { useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import API from "../services/api";
import "../styles/Payment.css";

function loadRazorpayScript() {
  return new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true);
      return;
    }

    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

function Payment() {
  const { bookingId: roomId } = useParams();
  const navigate = useNavigate();
  const { state } = useLocation();

  const [loading, setLoading] = useState(false);

  let user = null;

  try {
    user = JSON.parse(localStorage.getItem("user") || "null");
  } catch {
    user = null;
  }

  const room = state?.room || {};

  const nights =
    state?.checkIn && state?.checkOut
      ? Math.ceil(
          (new Date(state.checkOut) - new Date(state.checkIn)) /
            (1000 * 60 * 60 * 24)
        )
      : 0;

  const displayedAmount = Number(room.price || 0) * nights;

  const formatDate = (date) =>
    date
      ? new Date(`${date}T00:00:00`).toLocaleDateString("en-IN", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        })
      : "—";

  const handlePayment = async () => {
    if (loading) return;

    if (!state?.checkIn || !state?.checkOut || !roomId) {
      toast.error(
        "Booking details are missing. Please select your stay again."
      );
      return;
    }

    if (!user?._id) {
      toast.error("Please log in before making a payment.");
      navigate("/login");
      return;
    }

    if (nights <= 0) {
      toast.error("Please select valid check-in and check-out dates.");
      return;
    }

    setLoading(true);

    try {
      // Create the order on the backend.
      const orderResponse = await API.post("/payment/create-order", {
        userId: user._id,
        roomId,
        checkIn: state.checkIn,
        checkOut: state.checkOut,
        guests: Number(state.guests || 1),
      });

      const { keyId, order, bookingDetails } = orderResponse.data;

      if (!keyId || !order?.id || !bookingDetails) {
        throw new Error("Invalid payment order response from server.");
      }

      const scriptLoaded = await loadRazorpayScript();

      if (!scriptLoaded) {
        throw new Error(
          "Unable to load Razorpay Checkout. Please try again."
        );
      }

      const checkout = new window.Razorpay({
        key: keyId,
        amount: order.amount,
        currency: order.currency,
        name: "StayEase",
        description: `${bookingDetails.hotelName} · ${bookingDetails.roomType}`,
        order_id: order.id,

        prefill: {
          name: user.name || "",
          email: user.email || "",
          contact: user.phone || "",
        },

        notes: {
          roomId,
        },

        theme: {
          color: "#c9a45c",
        },

        handler: async (response) => {
          // Keep the checkout button disabled during verification.
          setLoading(true);

          try {
            const verifyResponse = await API.post(
              "/payment/verify",
              {
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
              }
            );

            const booking = verifyResponse.data?.booking;

            if (
              !verifyResponse.data?.success ||
              !booking?._id ||
              booking.paymentStatus !== "Paid"
            ) {
              throw new Error(
                "Payment verification is incomplete. Please check your booking before retrying."
              );
            }

            // Navigate only after backend verification succeeds.
            navigate("/payment-success", {
              replace: true,
              state: {
                booking,

                hotelName: bookingDetails.hotelName,
                roomNumber: bookingDetails.roomNumber,
                roomType: bookingDetails.roomType,

                checkIn: state.checkIn,
                checkOut: state.checkOut,
                guests: Number(state.guests || 1),

                amount: booking.totalAmount,
                method: "Razorpay",

                // Actual Razorpay ID, not a generated transaction number.
                razorpay_payment_id: booking.razorpayPaymentId,
              },
            });
          } catch (error) {
            toast.error(
              error.response?.data?.message ||
                error.message ||
                "Payment verification failed. If money was deducted, please contact support."
            );
          } finally {
            setLoading(false);
          }
        },

        modal: {
          ondismiss: () => {
            setLoading(false);
          },
        },
      });

      checkout.on("payment.failed", (response) => {
        setLoading(false);

        toast.error(
          response.error?.description ||
            "Payment failed. Please try again."
        );
      });

      checkout.open();
    } catch (error) {
      setLoading(false);

      toast.error(
        error.response?.data?.message ||
          error.message ||
          "Unable to start payment."
      );
    }
  };

  if (!state?.checkIn || !state?.checkOut || !roomId) {
    return (
      <main className="stay-payment-page">
        <section className="stay-payment-card stay-payment-empty">
          <span className="stay-payment-eyebrow">
            STAYEASE · ROYAL COLLECTION
          </span>

          <h2>Booking details unavailable</h2>

          <p>
            Please select your room and dates again before proceeding
            to payment.
          </p>

          <button
            type="button"
            className="stay-payment-button"
            onClick={() => navigate("/hotels")}
          >
            Explore Hotels
          </button>
        </section>

        <ToastContainer position="top-right" />
      </main>
    );
  }

  return (
    <main className="stay-payment-page">
      <div className="stay-payment-shell">
        <header className="stay-payment-heading">
          <span className="stay-payment-eyebrow">
            STAYEASE · ROYAL COLLECTION
          </span>

          <h1>Complete Your Stay</h1>

          <p>
            Thoughtfully chosen comfort. A seamless booking experience.
          </p>
        </header>

        <div className="stay-payment-layout">
          <section className="stay-payment-card stay-payment-summary">
            <div className="stay-payment-section-title">
              <span className="stay-payment-icon">01</span>

              <div>
                <h2>Reservation Summary</h2>
                <p>Review your stay before payment</p>
              </div>
            </div>

            <div className="stay-payment-hotel">
              <div className="stay-payment-hotel-mark">S</div>

              <div>
                <span className="stay-payment-eyebrow">
                  YOUR SELECTED ROOM
                </span>

                <h3>
                  {room.hotel?.hotelName ||
                    state.hotelName ||
                    "Your Hotel"}
                </h3>

                <p>
                  {room.roomNumber || "Room"} ·{" "}
                  {room.roomType || "Guest Room"}
                </p>
              </div>
            </div>

            <div className="stay-payment-dates">
              <div>
                <span>CHECK-IN</span>
                <strong>{formatDate(state.checkIn)}</strong>
              </div>

              <div className="stay-payment-night-count">
                <span>{nights}</span>
                <small>{nights === 1 ? "NIGHT" : "NIGHTS"}</small>
              </div>

              <div>
                <span>CHECK-OUT</span>
                <strong>{formatDate(state.checkOut)}</strong>
              </div>
            </div>

            <div className="stay-payment-detail">
              <span>Guest name</span>
              <strong>{user?.name || "Guest"}</strong>
            </div>

            <div className="stay-payment-detail">
              <span>Email</span>
              <strong>{user?.email || "—"}</strong>
            </div>

            <div className="stay-payment-detail">
              <span>Guests</span>
              <strong>{state.guests || 1}</strong>
            </div>

            <div className="stay-payment-detail">
              <span>Price per night</span>
              <strong>
                ₹{Number(room.price || 0).toLocaleString("en-IN")}
              </strong>
            </div>

            <div className="stay-payment-total">
              <div>
                <span>Total amount</span>
                <small>
                  {nights} {nights === 1 ? "night" : "nights"} · INR
                </small>
              </div>

              <strong>
                ₹{displayedAmount.toLocaleString("en-IN")}
              </strong>
            </div>

            <p className="stay-payment-note">
              The final amount is calculated and validated by the server.
            </p>
          </section>

          <section className="stay-payment-card stay-payment-checkout">
            <div className="stay-payment-section-title">
              <span className="stay-payment-icon">02</span>

              <div>
                <h2>Secure Checkout</h2>
                <p>Pay securely using Razorpay</p>
              </div>
            </div>

            <div className="stay-payment-secure-mark">
              <span>✦</span>
            </div>

            <h3>Make your stay official</h3>

            <p className="stay-payment-description">
              Choose an available payment option in Razorpay Checkout.
              UPI, cards and other methods depend on your checkout eligibility.
            </p>

            <div className="stay-payment-methods">
              <span>UPI</span>
              <span>Cards</span>
              <span>Netbanking</span>
              <span>Wallets</span>
            </div>

            <div className="stay-payment-security">
              <span>♢</span>

              <div>
                <strong>Secure payment verification</strong>
                <p>
                  Your booking is confirmed only after server-side verification.
                </p>
              </div>
            </div>

            <button
              type="button"
              className="stay-payment-button"
              onClick={handlePayment}
              disabled={loading || nights <= 0}
            >
              {loading
                ? "PLEASE WAIT..."
                : `PAY ₹${displayedAmount.toLocaleString("en-IN")}`}

              {!loading && <span>→</span>}
            </button>

            <p className="stay-payment-terms">
              By continuing, you agree to complete payment through the
              secure Razorpay checkout.
            </p>
          </section>
        </div>
      </div>

      <ToastContainer position="top-right" />
    </main>
  );
}

export default Payment;