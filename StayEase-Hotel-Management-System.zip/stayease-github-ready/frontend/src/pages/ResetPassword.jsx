import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import { toast, ToastContainer } from "react-toastify";

function ResetPassword() {

  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      const res = await API.post("/password/reset", form);

      toast.success(res.data.message);

      setTimeout(() => {
        navigate("/login");
      }, 2000);

    } catch (err) {

      toast.error(
        err.response?.data?.message || "Reset Failed"
      );

    }

  };

  return (
    <div className="container mt-5">

      <div className="row justify-content-center">

        <div className="col-md-5">

          <div className="card shadow">

            <div className="card-body">

              <h3 className="text-center mb-4">
                Reset Password
              </h3>

              <form onSubmit={handleSubmit}>

                <div className="mb-3">

                  <label>Email</label>

                  <input
                    type="email"
                    name="email"
                    className="form-control"
                    onChange={handleChange}
                    required
                  />

                </div>

                <div className="mb-3">

                  <label>New Password</label>

                  <input
                    type="password"
                    name="password"
                    className="form-control"
                    onChange={handleChange}
                    required
                  />

                </div>

                <button className="btn btn-primary w-100">
                  Reset Password
                </button>

              </form>

            </div>

          </div>

        </div>

      </div>

      <ToastContainer />

    </div>
  );
}

export default ResetPassword;