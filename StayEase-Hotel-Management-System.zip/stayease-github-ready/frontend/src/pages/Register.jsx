import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../services/api";
import ToastNotification from "../components/ToastNotification";
import "../styles/Register.css";

function Register() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [toastData, setToastData] = useState({
    message: "",
    type: "success",
    show: false,
  });

  const showToast = (message, type = "success") => {
    setToastData({ message, type, show: true });
  };

  const closeToast = () => {
    setToastData((prev) => ({ ...prev, show: false }));
  };

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (form.password !== form.confirmPassword) {
      showToast("Passwords do not match", "error");
      return;
    }

    if (form.password.length < 6) {
      showToast("Password must be at least 6 characters", "error");
      return;
    }

    try {
      setLoading(true);

      await API.post("/auth/register", {
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        password: form.password,
      });

      showToast("Registration Successful!", "success");

      setTimeout(() => {
        navigate("/login");
      }, 1500);
    } catch (err) {
      showToast(
        err.response?.data?.message || "Registration Failed",
        "error"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="se-register-page">
      <div className="se-register-background-glow se-register-glow-one" />
      <div className="se-register-background-glow se-register-glow-two" />

      <div className="se-register-wrapper">
        <header className="se-register-header">
          <Link to="/" className="se-register-brand">
            <div className="se-register-brand-icon">S</div>

            <div className="se-register-brand-name">
              Stay<span>Ease</span>
              <small>PREMIUM HOSPITALITY</small>
            </div>
          </Link>

          <Link to="/" className="se-register-home-link">
            <span>←</span> Back to Home
          </Link>
        </header>

        <main className="se-register-layout">
          <section className="se-register-showcase">
            <div className="se-register-showcase-content">
              <div className="se-register-eyebrow">
                <span className="se-register-eyebrow-line" />
                YOUR JOURNEY BEGINS HERE
              </div>

              <h1>
                Discover a More
                <br />
                <span>Beautiful Stay.</span>
              </h1>

              <p>
                Create your StayEase account and discover exceptional
                stays, thoughtfully selected rooms, and memorable
                hospitality wherever you travel.
              </p>

              <div className="se-register-features">
                <div className="se-register-feature">
                  <div className="se-register-feature-icon">✧</div>
                  <div>
                    <strong>Exclusive Stays</strong>
                    <small>Explore rooms selected for your comfort.</small>
                  </div>
                </div>

                <div className="se-register-feature">
                  <div className="se-register-feature-icon">⌂</div>
                  <div>
                    <strong>Easy Reservations</strong>
                    <small>Manage your bookings in one place.</small>
                  </div>
                </div>

                <div className="se-register-feature">
                  <div className="se-register-feature-icon">♧</div>
                  <div>
                    <strong>Personal Experience</strong>
                    <small>Plan your next stay with greater ease.</small>
                  </div>
                </div>
              </div>
            </div>

            <div className="se-register-showcase-footer">
              <span>COMFORT · ELEGANCE · EXPERIENCE</span>
              <span>STAYEASE</span>
            </div>
          </section>

          <section className="se-register-form-panel">
            <div className="se-register-card">
              <div className="se-register-card-top">
                <div className="se-register-card-icon">✧</div>
                <span className="se-register-card-label">
                  CREATE YOUR ACCOUNT
                </span>
              </div>

              <h2>Join StayEase</h2>

              <p className="se-register-subtitle">
                Sign up to make your next stay extraordinary.
              </p>

              <form onSubmit={handleSubmit}>
                <div className="se-register-field">
                  <label htmlFor="register-name">Full Name</label>
                  <div className="se-register-input-wrap">
                    <span className="se-register-input-icon">♙</span>
                    <input
                      id="register-name"
                      type="text"
                      name="name"
                      placeholder="Enter your full name"
                      value={form.name}
                      onChange={handleChange}
                      autoComplete="name"
                      maxLength={100}
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                <div className="se-register-field">
                  <label htmlFor="register-email">Email Address</label>
                  <div className="se-register-input-wrap">
                    <span className="se-register-input-icon">✉</span>
                    <input
                      id="register-email"
                      type="email"
                      name="email"
                      placeholder="you@example.com"
                      value={form.email}
                      onChange={handleChange}
                      autoComplete="email"
                      maxLength={254}
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                <div className="se-register-field">
                  <label htmlFor="register-phone">Phone Number</label>
                  <div className="se-register-input-wrap">
                    <span className="se-register-input-icon">☎</span>
                    <input
                      id="register-phone"
                      type="tel"
                      name="phone"
                      placeholder="Enter your phone number"
                      value={form.phone}
                      onChange={handleChange}
                      autoComplete="tel"
                      maxLength={20}
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                <div className="se-register-field">
                  <label htmlFor="register-password">Password</label>
                  <div className="se-register-input-wrap">
                    <span className="se-register-input-icon">♙</span>
                    <input
                      id="register-password"
                      type={showPassword ? "text" : "password"}
                      name="password"
                      placeholder="Create a password"
                      value={form.password}
                      onChange={handleChange}
                      autoComplete="new-password"
                      minLength={6}
                      required
                      disabled={loading}
                    />

                    <button
                      type="button"
                      className="se-register-password-toggle"
                      onClick={() => setShowPassword(!showPassword)}
                      aria-label={
                        showPassword ? "Hide password" : "Show password"
                      }
                      disabled={loading}
                    >
                      {showPassword ? "Hide" : "Show"}
                    </button>
                  </div>
                </div>

                <div className="se-register-field">
                  <label htmlFor="register-confirm-password">
                    Confirm Password
                  </label>
                  <div className="se-register-input-wrap">
                    <span className="se-register-input-icon">♙</span>
                    <input
                      id="register-confirm-password"
                      type={showConfirmPassword ? "text" : "password"}
                      name="confirmPassword"
                      placeholder="Re-enter your password"
                      value={form.confirmPassword}
                      onChange={handleChange}
                      autoComplete="new-password"
                      minLength={6}
                      required
                      disabled={loading}
                    />

                    <button
                      type="button"
                      className="se-register-password-toggle"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                      aria-label={
                        showConfirmPassword
                          ? "Hide confirm password"
                          : "Show confirm password"
                      }
                      disabled={loading}
                    >
                      {showConfirmPassword ? "Hide" : "Show"}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="se-register-submit"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="se-register-spinner" />
                      Creating Account...
                    </>
                  ) : (
                    <>
                      Create Account
                      <span className="se-register-submit-arrow">→</span>
                    </>
                  )}
                </button>
              </form>

              <div className="se-register-divider">
                <span />
                <small>ALREADY A MEMBER?</small>
                <span />
              </div>

              <p className="se-register-login-text">
                Already have an account? <Link to="/login">Sign In</Link>
              </p>

              <div className="se-register-privacy">
                <span>♧</span>
                Your information is handled securely.
              </div>
            </div>
          </section>
        </main>

        <footer className="se-register-footer">
          <span>© {new Date().getFullYear()} StayEase</span>
          <span>MADE FOR MEMORABLE STAYS</span>
        </footer>
      </div>

      <ToastNotification
        message={toastData.message}
        type={toastData.type}
        show={toastData.show}
        onClose={closeToast}
      />
    </div>
  );
}

export default Register;