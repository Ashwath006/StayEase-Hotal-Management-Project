
import { useCallback, useEffect, useState } from "react";
import API from "../services/api";
import { toast } from "react-toastify";
import BookingModal from "../components/BookingModal";
import "../styles/MyBookings.css";

const FALLBACK_IMAGE =
  "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1000&q=85";

function MyBookings() {
  const [bookings, setBookings] = useState([]);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cancellingId, setCancellingId] = useState(null);

  const getUser = () => {
    try {
      return JSON.parse(localStorage.getItem("user") || "null");
    } catch {
      return null;
    }
  };

  const user = getUser();

  const fetchBookings = useCallback(async () => {
    if (!user?._id) {
      setBookings([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      const res = await API.get(`/bookings/user/${user._id}`);

      const data = res.data?.bookings;
      setBookings(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Fetch bookings error:", err);
      toast.error(
        err.response?.data?.message || "Unable to load your bookings."
      );
    } finally {
      setLoading(false);
    }
  }, [user?._id]);

  useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  const formatDate = (date) => {
    if (!date) return "—";

    const parsedDate = new Date(date);

    if (Number.isNaN(parsedDate.getTime())) return "—";

    return parsedDate.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  const formatCurrency = (amount) =>
    Number(amount || 0).toLocaleString("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 2,
    });

  const getStatusClass = (status) => {
    const normalized = String(status || "").toLowerCase();

    if (normalized === "booked" || normalized === "confirmed") {
      return "stay-status-confirmed";
    }

    if (normalized === "cancelled" || normalized === "canceled") {
      return "stay-status-cancelled";
    }

    return "stay-status-pending";
  };

  const cancelBooking = async (id) => {
    const confirmed = window.confirm(
      "Are you sure you want to cancel this booking?"
    );

    if (!confirmed) return;

    try {
      setCancellingId(id);

      await API.patch(`/bookings/cancel/${id}`);

      toast.success("Booking cancelled successfully.");
      await fetchBookings();

      if (selectedBooking?._id === id) {
        setSelectedBooking(null);
      }
    } catch (err) {
      toast.error(
        err.response?.data?.message || "Unable to cancel this booking."
      );
    } finally {
      setCancellingId(null);
    }
  };

  const escapeHtml = (value) =>
    String(value ?? "—").replace(/[&<>"']/g, (character) => {
      const entities = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      };

      return entities[character];
    });

  const downloadInvoice = (booking) => {
    const invoiceWindow = window.open("", "_blank", "width=850,height=700");

    if (!invoiceWindow) {
      toast.error("Please allow pop-ups to print your invoice.");
      return;
    }

    const hotelName = booking.hotelId?.hotelName || "StayEase Hotel";
    const bookingId = booking._id || "";
    const paymentStatus = booking.paymentStatus || "Not specified";

    invoiceWindow.document.write(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>StayEase Invoice - ${escapeHtml(bookingId.slice(-8))}</title>
        <style>
          * { box-sizing: border-box; }
          body {
            margin: 0;
            padding: 35px;
            font-family: Arial, sans-serif;
            color: #17243b;
            background: #fff;
          }
          .invoice {
            max-width: 760px;
            margin: auto;
            border: 1px solid #e4dfd2;
            padding: 35px;
          }
          .header {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            border-bottom: 3px solid #c6a15b;
            padding-bottom: 22px;
          }
          .brand {
            font-size: 28px;
            font-weight: 800;
            color: #10213b;
            letter-spacing: 1px;
          }
          .gold { color: #ad8741; }
          h2 { margin: 28px 0 8px; }
          .muted { color: #687386; font-size: 13px; }
          .details {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
          }
          .details td {
            padding: 13px 10px;
            border-bottom: 1px solid #e9e5dc;
            vertical-align: top;
          }
          .details td:first-child {
            color: #687386;
            width: 42%;
          }
          .total {
            margin-top: 24px;
            padding: 20px;
            background: #10213b;
            color: white;
            display: flex;
            justify-content: space-between;
            font-size: 19px;
            font-weight: bold;
          }
          .footer {
            margin-top: 35px;
            text-align: center;
            color: #687386;
            font-size: 12px;
          }
          .print-button {
            display: block;
            margin: 22px auto;
            border: 0;
            background: #10213b;
            color: white;
            padding: 12px 25px;
            cursor: pointer;
          }
          @media print {
            body { padding: 0; }
            .invoice { border: 0; padding: 15px; }
            .print-button { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="invoice">
          <div class="header">
            <div>
              <div class="brand">Stay<span class="gold">Ease</span></div>
              <p class="muted">ROYAL HOSPITALITY · BOOKING INVOICE</p>
            </div>
            <div style="text-align:right">
              <strong>BOOKING RECEIPT</strong>
              <p class="muted">ID: ${escapeHtml(bookingId.slice(-8).toUpperCase())}</p>
              <p class="muted">Date: ${escapeHtml(formatDate(booking.createdAt))}</p>
            </div>
          </div>

          <h2>${escapeHtml(hotelName)}</h2>
          <p class="muted">${escapeHtml(booking.hotelId?.location || "")}</p>

          <table class="details">
            <tr><td>Room Number</td><td><strong>${escapeHtml(booking.roomId?.roomNumber)}</strong></td></tr>
            <tr><td>Room Type</td><td>${escapeHtml(booking.roomId?.roomType)}</td></tr>
            <tr><td>Check-in</td><td>${escapeHtml(formatDate(booking.checkIn))}</td></tr>
            <tr><td>Check-out</td><td>${escapeHtml(formatDate(booking.checkOut))}</td></tr>
            <tr><td>Guests</td><td>${escapeHtml(booking.guests || 1)}</td></tr>
            <tr><td>Booking Status</td><td>${escapeHtml(booking.bookingStatus)}</td></tr>
            <tr><td>Payment Status</td><td>${escapeHtml(paymentStatus)}</td></tr>
            <tr><td>Payment Reference</td><td>${escapeHtml(booking.razorpayPaymentId || "—")}</td></tr>
          </table>

          <div class="total">
            <span>Total Amount</span>
            <span>${escapeHtml(formatCurrency(booking.totalAmount))}</span>
          </div>

          <div class="footer">
            <p>Thank you for choosing StayEase.</p>
            <p>This receipt reflects the booking information available in your account.</p>
          </div>
        </div>

        <button class="print-button" onclick="window.print()">Print / Save as PDF</button>
      </body>
      </html>
    `);

    invoiceWindow.document.close();
    invoiceWindow.focus();
  };

  const getHotelImage = (hotel) => {
    const image = hotel?.images?.[0];

    if (typeof image === "string" && image.trim()) {
      return image;
    }

    return FALLBACK_IMAGE;
  };

  return (
    <main className="stay-bookings-page">
      <div className="stay-bookings-container">
        {/* PAGE HEADER */}
        <section className="stay-bookings-header">
          <div className="stay-header-copy">
            <span className="stay-eyebrow">
              <span className="stay-eyebrow-line" />
              YOUR STAY, YOUR STORY
            </span>

            <h1>
              My <span>Bookings</span>
            </h1>

            <p>
              Every journey deserves exceptional hospitality.
              Manage your reservations in one place.
            </p>
          </div>

          <button
            type="button"
            className="stay-refresh-btn"
            onClick={fetchBookings}
            disabled={loading}
          >
            <span className={loading ? "stay-refresh-icon spinning" : "stay-refresh-icon"}>
              ↻
            </span>
            {loading ? "Refreshing..." : "Refresh Bookings"}
          </button>
        </section>

        {/* SUMMARY */}
        {!loading && (
          <section className="stay-booking-summary">
            <div className="stay-summary-icon">♛</div>

            <div>
              <span className="stay-summary-label">YOUR RESERVATIONS</span>
              <h3>
                {bookings.length}{" "}
                {bookings.length === 1 ? "Booking" : "Bookings"}
              </h3>
            </div>

            <div className="stay-summary-divider" />

            <div className="stay-summary-detail">
              <span className="stay-summary-label">CONFIRMED STAYS</span>
              <strong>
                {
                  bookings.filter((booking) =>
                    ["booked", "confirmed"].includes(
                      String(booking.bookingStatus || "").toLowerCase()
                    )
                  ).length
                }
              </strong>
            </div>
          </section>
        )}

        {/* LOADING */}
        {loading ? (
          <div className="stay-booking-state">
            <div className="stay-luxury-spinner" />
            <h3>Preparing Your Reservations</h3>
            <p>Please wait while we retrieve your booking details.</p>
          </div>
        ) : !user?._id ? (
          <div className="stay-booking-state">
            <div className="stay-empty-icon">♙</div>
            <h3>Sign In to View Your Bookings</h3>
            <p>Your reservations will be available once you sign in.</p>
            <button
              type="button"
              className="stay-gold-btn"
              onClick={() => (window.location.href = "/login")}
            >
              Sign In
            </button>
          </div>
        ) : bookings.length === 0 ? (
          <div className="stay-booking-state">
            <div className="stay-empty-icon">♜</div>
            <h3>Your Next Escape Awaits</h3>
            <p>
              You haven't made any reservations yet. Discover your next
              memorable stay with StayEase.
            </p>
            <button
              type="button"
              className="stay-gold-btn"
              onClick={() => (window.location.href = "/hotels")}
            >
              Explore Hotels <span>→</span>
            </button>
          </div>
        ) : (
          <section className="stay-bookings-list">
            {bookings.map((booking) => (
              <article className="stay-booking-card" key={booking._id}>
                {/* IMAGE */}
                <div className="stay-booking-image-wrap">
                  <img
                    src={getHotelImage(booking.hotelId)}
                    alt={booking.hotelId?.hotelName || "Hotel"}
                    className="stay-booking-image"
                    onError={(event) => {
                      event.currentTarget.onerror = null;
                      event.currentTarget.src = FALLBACK_IMAGE;
                    }}
                  />

                  <div className="stay-image-overlay" />

                  <span className="stay-image-caption">
                    <span>✦</span> STAYEASE COLLECTION
                  </span>
                </div>

                {/* CONTENT */}
                <div className="stay-booking-content">
                  <div className="stay-booking-topline">
                    <div className="stay-hotel-heading">
                      <span className="stay-hotel-kicker">YOUR RESERVATION</span>
                      <h2>
                        {booking.hotelId?.hotelName || "Hotel Reservation"}
                      </h2>

                      <p className="stay-hotel-location">
                        <span>⌖</span>
                        {booking.hotelId?.location || "Location unavailable"}
                      </p>
                    </div>

                    <span
                      className={`stay-status-badge ${getStatusClass(
                        booking.bookingStatus
                      )}`}
                    >
                      <span className="stay-status-dot" />
                      {booking.bookingStatus || "Pending"}
                    </span>
                  </div>

                  <div className="stay-booking-details-grid">
                    <div className="stay-detail-item">
                      <span className="stay-detail-icon">♜</span>
                      <div>
                        <span className="stay-detail-label">ROOM</span>
                        <strong>{booking.roomId?.roomNumber || "—"}</strong>
                      </div>
                    </div>

                    <div className="stay-detail-item">
                      <span className="stay-detail-icon">✧</span>
                      <div>
                        <span className="stay-detail-label">ROOM TYPE</span>
                        <strong>{booking.roomId?.roomType || "—"}</strong>
                      </div>
                    </div>

                    <div className="stay-detail-item">
                      <span className="stay-detail-icon">♙</span>
                      <div>
                        <span className="stay-detail-label">GUESTS</span>
                        <strong>
                          {booking.guests || 1}{" "}
                          {(booking.guests || 1) === 1 ? "Guest" : "Guests"}
                        </strong>
                      </div>
                    </div>

                    <div className="stay-detail-item">
                      <span className="stay-detail-icon">◷</span>
                      <div>
                        <span className="stay-detail-label">BOOKED ON</span>
                        <strong>{formatDate(booking.createdAt)}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="stay-booking-date-panel">
                    <div className="stay-date-item">
                      <span className="stay-date-label">CHECK-IN</span>
                      <strong>{formatDate(booking.checkIn)}</strong>
                    </div>

                    <div className="stay-date-connector">
                      <span>✦</span>
                      <span className="stay-date-line" />
                    </div>

                    <div className="stay-date-item">
                      <span className="stay-date-label">CHECK-OUT</span>
                      <strong>{formatDate(booking.checkOut)}</strong>
                    </div>

                    <div className="stay-total-price">
                      <span className="stay-date-label">TOTAL AMOUNT</span>
                      <strong>{formatCurrency(booking.totalAmount)}</strong>
                    </div>
                  </div>

                  <div className="stay-booking-footer">
                    <div className="stay-booking-meta">
                      <span className="stay-booking-id">
                        ID · {booking._id?.slice(-8).toUpperCase()}
                      </span>

                      <span
                        className={`stay-payment-status ${
                          String(booking.paymentStatus || "").toLowerCase() === "paid"
                            ? "stay-payment-paid"
                            : "stay-payment-other"
                        }`}
                      >
                        <span>●</span>
                        Payment: {booking.paymentStatus || "Unspecified"}
                      </span>
                    </div>

                    <div className="stay-booking-actions">
                      <button
                        type="button"
                        className="stay-action-btn stay-view-btn"
                        onClick={() => setSelectedBooking(booking)}
                      >
                        View Details <span>↗</span>
                      </button>

                      <button
                        type="button"
                        className="stay-action-btn stay-invoice-btn"
                        onClick={() => downloadInvoice(booking)}
                      >
                        <span>⇩</span> Invoice
                      </button>

                      {["booked", "confirmed"].includes(
                        String(booking.bookingStatus || "").toLowerCase()
                      ) && (
                        <button
                          type="button"
                          className="stay-action-btn stay-cancel-btn"
                          onClick={() => cancelBooking(booking._id)}
                          disabled={cancellingId === booking._id}
                        >
                          {cancellingId === booking._id
                            ? "Cancelling..."
                            : "Cancel Booking"}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </section>
        )}

        {/* FOOTER SIGNATURE */}
        {!loading && bookings.length > 0 && (
          <div className="stay-bookings-signature">
            <span className="stay-signature-line" />
            <span>CRAFTED FOR EXCEPTIONAL STAYS</span>
            <span className="stay-signature-diamond">✦</span>
            <span className="stay-signature-line" />
          </div>
        )}
      </div>

      {selectedBooking && (
        <BookingModal
          booking={selectedBooking}
          onClose={() => setSelectedBooking(null)}
        />
      )}
    </main>
  );
}

export default MyBookings;
