import { useEffect, useState } from "react";
import API from "../services/api";
import HotelCard from "../components/HotelCard";
import LoadingSpinner from "../components/LoadingSpinner";
import "../styles/hotels.css";

function Hotels() {
  const [hotels, setHotels] = useState([]);
  const [filteredHotels, setFilteredHotels] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useState("");
  const [price, setPrice] = useState("");
  const [rating, setRating] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    fetchHotels();
  }, []);

  const fetchHotels = async () => {
    try {
      setError("");

      const res = await API.get("/hotels");
      const hotelData = Array.isArray(res.data.hotels)
        ? res.data.hotels
        : [];

      setHotels(hotelData);
      setFilteredHotels(hotelData);
    } catch (err) {
      console.error("Failed to fetch hotels:", err);
      setError("Unable to load hotels. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const filtered = hotels.filter((hotel) => {
      const hotelName = hotel.hotelName || "";
      const hotelLocation = hotel.location || "";
      const hotelPrice = Number(hotel.price) || 0;
      const hotelRating = Number(hotel.rating) || 0;

      const matchName = hotelName
        .toLowerCase()
        .includes(search.trim().toLowerCase());

      const matchLocation =
        location === "" || hotelLocation === location;

      let matchPrice = true;

      if (price === "1") {
        matchPrice = hotelPrice < 3000;
      } else if (price === "2") {
        matchPrice = hotelPrice >= 3000 && hotelPrice <= 5000;
      } else if (price === "3") {
        matchPrice = hotelPrice > 5000;
      }

      let matchRating = true;

      if (rating !== "") {
        matchRating = hotelRating >= Number(rating);
      }

      return matchName && matchLocation && matchPrice && matchRating;
    });

    setFilteredHotels(filtered);
  }, [search, location, price, rating, hotels]);

  const clearFilters = () => {
    setSearch("");
    setLocation("");
    setPrice("");
    setRating("");
  };

  const hasActiveFilters = search || location || price || rating;

  return (
    <main className="st-hotels-page">
      <section className="st-hotels-hero">
        <div className="container">
          <div className="st-hotels-hero-content">
            <span className="st-hotels-eyebrow">
              <span className="st-hotels-eyebrow-line"></span>
              STAYEASE COLLECTION
              <span className="st-hotels-eyebrow-line"></span>
            </span>

            <h1>
              Discover Your <span>Perfect Stay</span>
            </h1>

            <p>
              Explore exceptional hotels, beautiful destinations, and
              unforgettable experiences.
            </p>

            <div className="st-hotels-hero-stats">
              <div>
                <strong>{hotels.length}+</strong>
                <span>Hotel Listings</span>
              </div>

              <span className="st-hotels-stat-divider"></span>

              <div>
                <strong>Luxury</strong>
                <span>Stay Experiences</span>
              </div>

              <span className="st-hotels-stat-divider"></span>

              <div>
                <strong>Easy</strong>
                <span>Online Booking</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="st-hotels-content">
        <div className="container">
          <div className="st-hotels-heading-row">
            <div>
              <span className="st-hotels-section-label">
                FIND YOUR NEXT GETAWAY
              </span>

              <h2>Available Hotels</h2>

              <p>Find the right place for your next memorable stay.</p>
            </div>

            <div className="st-hotels-result-count">
              <span>{filteredHotels.length}</span>
              <div>
                <strong>Hotels Found</strong>
                <small>Matching your preferences</small>
              </div>
            </div>
          </div>

          <div className="st-hotels-filter-panel">
            <div className="st-hotels-filter-title">
              <div className="st-hotels-filter-icon">⌕</div>
              <div>
                <h3>Find Your Stay</h3>
                <p>Filter hotels to match your preferences.</p>
              </div>

              {hasActiveFilters && (
                <button
                  type="button"
                  className="st-hotels-clear-btn"
                  onClick={clearFilters}
                >
                  Clear Filters <span>×</span>
                </button>
              )}
            </div>

            <div className="row g-3 st-hotels-filter-grid">
              <div className="col-12 col-md-6 col-lg-3">
                <label htmlFor="st-hotel-search">Search Hotel</label>
                <div className="st-hotels-search-wrap">
                  <span  className="st-hotels-search-icon"> 
                    <i className="bi bi-search"></i>
                  </span>
                  <input
                    id="st-hotel-search"
                    type="search"
                    className="form-control st-hotels-input st-hotels-search-input "
                    placeholder="      Enter hotel name..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
              </div>

              <div className="col-12 col-md-6 col-lg-3">
                <label htmlFor="st-hotel-location">Destination</label>
                <select
                  id="st-hotel-location"
                  className="form-select st-hotels-input"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                >
                  <option value="">All Locations</option>
                  {[...new Set(hotels.map((hotel) => hotel.location).filter(Boolean))]
                    .sort()
                    .map((loc) => (
                      <option key={loc} value={loc}>
                        {loc}
                      </option>
                    ))}
                </select>
              </div>

              <div className="col-12 col-md-6 col-lg-3">
                <label htmlFor="st-hotel-price">Price Per Night</label>
                <select
                  id="st-hotel-price"
                  className="form-select st-hotels-input"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                >
                  <option value="">All Prices</option>
                  <option value="1">Below ₹3,000</option>
                  <option value="2">₹3,000 – ₹5,000</option>
                  <option value="3">Above ₹5,000</option>
                </select>
              </div>

              <div className="col-12 col-md-6 col-lg-3">
                <label htmlFor="st-hotel-rating">Guest Rating</label>
                <select
                  id="st-hotel-rating"
                  className="form-select st-hotels-input"
                  value={rating}
                  onChange={(e) => setRating(e.target.value)}
                >
                  <option value="">All Ratings</option>
                  <option value="4">★ 4 & Above</option>
                  <option value="3">★ 3 & Above</option>
                  <option value="2">★ 2 & Above</option>
                </select>
              </div>
            </div>
          </div>

          {loading ? (
            <div className="st-hotels-loading">
              <LoadingSpinner />
              <p>Discovering exceptional stays...</p>
            </div>
          ) : error ? (
            <div className="st-hotels-empty">
              <div className="st-hotels-empty-icon">!</div>
              <h3>Something went wrong</h3>
              <p>{error}</p>
              <button
                type="button"
                className="st-hotels-retry-btn"
                onClick={() => {
                  setLoading(true);
                  fetchHotels();
                }}
              >
                Try Again
              </button>
            </div>
          ) : filteredHotels.length > 0 ? (
            <div className="row g-4 st-hotels-results">
              {filteredHotels.map((hotel) => (
                <HotelCard key={hotel._id} hotel={hotel} />
              ))}
            </div>
          ) : (
            <div className="st-hotels-empty">
              <div className="st-hotels-empty-icon">⌕</div>
              <h3>No Hotels Found</h3>
              <p>
                We couldn't find hotels matching your current filters.
                Try another destination or adjust your price range.
              </p>
              <button
                type="button"
                className="st-hotels-retry-btn"
                onClick={clearFilters}
              >
                Clear All Filters
              </button>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}

export default Hotels;