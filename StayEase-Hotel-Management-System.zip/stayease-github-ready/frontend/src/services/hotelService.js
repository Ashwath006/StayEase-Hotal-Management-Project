import API from "./api";

export const getHotels = async () => {
  return await API.get("/hotels");
};

export const getHotel = async (id) => {
  return await API.get(`/hotels/${id}`);
};

export const addHotel = async (hotelData) => {
  return await API.post("/hotels", hotelData);
};

export const updateHotel = async (id, hotelData) => {
  return await API.put(`/hotels/${id}`, hotelData);
};

export const deleteHotel = async (id) => {
  return await API.delete(`/hotels/${id}`);
};