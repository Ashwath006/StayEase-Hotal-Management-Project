import API from "./api";

export const getRooms = () => API.get("/rooms");

export const addRoom = (roomData) => API.post("/rooms", roomData);

export const updateRoom = (id, roomData) =>
  API.put(`/rooms/${id}`, roomData);

export const deleteRoom = (id) =>
  API.delete(`/rooms/${id}`);