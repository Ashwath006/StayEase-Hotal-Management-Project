function Payment() {
  return (
    <div className="container mt-5">
      <h2>Payment Page (Razorpay Ready Structure)</h2>

      <button className="btn btn-success">
        Pay Now
      </button>
    </div>
  );
}

export default Payment;