const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const User = require("./models/User");

require("dotenv").config();

async function createAdmin() {
  const { MONGO_URI, ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;

  if (!MONGO_URI || !ADMIN_EMAIL || !ADMIN_PASSWORD) {
    throw new Error(
      "Missing MONGO_URI, ADMIN_EMAIL, or ADMIN_PASSWORD in backend/.env"
    );
  }

  await mongoose.connect(MONGO_URI);

  const existingUser = await User.findOne({ email: ADMIN_EMAIL });

  if (existingUser) {
    console.log("An account with this admin email already exists.");
    return;
  }

  const hashedPassword = await bcrypt.hash(ADMIN_PASSWORD, 10);

  await User.create({
    name: ADMIN_NAME || "StayEase Admin",
    email: ADMIN_EMAIL,
    password: hashedPassword,
    role: "admin",
  });

  console.log("Admin account created successfully.");
}

createAdmin()
  .catch((error) => {
    console.error("Admin creation failed:", error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.disconnect();
    }
  });
