const crypto = require("crypto");
const Razorpay = require("razorpay");

const Room = require("../models/Room");
const Hotel = require("../models/Hotel");
const User = require("../models/User");
const Booking = require("../models/Booking");
const PaymentOrder = require("../models/PaymentOrder");
const getRazorpay = () => {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;

  if (!keyId || !keySecret) {
    throw new Error(
      "Razorpay credentials are missing from backend .env"
    );
  }

  return new Razorpay({
    key_id: keyId,
    key_secret: keySecret,
  });
};


// Create a Razorpay order. Do NOT create the booking here.
exports.createOrder = async (req, res) => {
  try {
    const { userId, roomId, checkIn, checkOut, guests = 1 } = req.body;

    if (!userId || !roomId || !checkIn || !checkOut) {
      return res.status(400).json({
        success: false,
        message: "User, room and stay dates are required",
      });
    }

    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const guestCount = Number(guests);

    if (
      Number.isNaN(start.getTime()) ||
      Number.isNaN(end.getTime()) ||
      end <= start
    ) {
      return res.status(400).json({
        success: false,
        message: "Please provide valid check-in and check-out dates",
      });
    }

    if (!Number.isInteger(guestCount) || guestCount < 1) {
      return res.status(400).json({
        success: false,
        message: "Guest count must be at least 1",
      });
    }

    const [user, room] = await Promise.all([
      User.findById(userId),
      Room.findById(roomId),
    ]);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found. Please log in again.",
      });
    }

    if (!room) {
      return res.status(404).json({
        success: false,
        message: "Room not found",
      });
    }

    if (!room.available) {
      return res.status(409).json({
        success: false,
        message: "This room is currently unavailable",
      });
    }

    if (guestCount > Number(room.capacity)) {
      return res.status(400).json({
        success: false,
        message: `Maximum capacity for this room is ${room.capacity}`,
      });
    }

    const hotelId = room.hotelId || room.hotel;

    if (!hotelId) {
      return res.status(400).json({
        success: false,
        message: "Hotel information is missing for this room",
      });
    }

    const hotel = await Hotel.findById(hotelId);

    if (!hotel) {
      return res.status(404).json({
        success: false,
        message: "Hotel not found",
      });
    }

    const nights = Math.ceil(
      (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)
    );

    const totalAmount = nights * Number(room.price);

    if (!Number.isFinite(totalAmount) || totalAmount <= 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid room price",
      });
    }

    // Razorpay expects amount in paise.
    const razorpay = getRazorpay();

    const razorpayOrder = await razorpay.orders.create({
      amount: Math.round(totalAmount * 100),
      currency: "INR",
      receipt: `stay_${Date.now()}`,
      notes: {
        userId: String(user._id),
        roomId: String(room._id),
      },
    });

    await PaymentOrder.create({
      userId: user._id,
      hotelId: hotel._id,
      roomId: room._id,
      checkIn: start,
      checkOut: end,
      guests: guestCount,
      amount: totalAmount,
      currency: "INR",
      razorpayOrderId: razorpayOrder.id,
      paymentStatus: "Pending",
    });

    return res.status(201).json({
      success: true,
      keyId: process.env.RAZORPAY_KEY_ID,
      order: {
        id: razorpayOrder.id,
        amount: razorpayOrder.amount,
        currency: razorpayOrder.currency,
      },
      bookingDetails: {
        hotelName: hotel.hotelName,
        roomNumber: room.roomNumber,
        roomType: room.roomType,
        pricePerNight: room.price,
        nights,
        guests: guestCount,
        totalAmount,
      },
    });
  }
catch (err) {
  console.error("Create payment order failed:", err);

  return res.status(500).json({
    success: false,
    message: err.error?.description || err.message || "Unable to create payment order",
  });
}

};

// Verify signature and payment with Razorpay before creating booking.
exports.verifyPayment = async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
    } = req.body;

    if (
      !razorpay_order_id ||
      !razorpay_payment_id ||
      !razorpay_signature
    ) {
      return res.status(400).json({
        success: false,
        message: "Payment verification details are incomplete",
      });
    }

    // Find the order created by OUR backend.
    const pendingOrder = await PaymentOrder.findOne({
      razorpayOrderId: razorpay_order_id,
    });

    if (!pendingOrder) {
      return res.status(404).json({
        success: false,
        message: "Payment order not found",
      });
    }

    // Idempotency: don't create a second booking for the same payment.
    if (pendingOrder.paymentStatus === "Paid" && pendingOrder.bookingId) {
      const existingBooking = await Booking.findById(
        pendingOrder.bookingId
      );

      return res.json({
        success: true,
        message: "Payment was already verified",
        booking: existingBooking,
      });
    }

    const secret = process.env.RAZORPAY_KEY_SECRET;

    if (!secret) {
      throw new Error("Razorpay secret is missing");
    }

    const expectedSignature = crypto
      .createHmac("sha256", secret)
      .update(`${pendingOrder.razorpayOrderId}|${razorpay_payment_id}`)
      .digest("hex");

    const expectedBuffer = Buffer.from(expectedSignature, "hex");
    const receivedBuffer = Buffer.from(razorpay_signature, "hex");

    if (
      expectedBuffer.length !== receivedBuffer.length ||
      !crypto.timingSafeEqual(expectedBuffer, receivedBuffer)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid payment signature",
      });
    }

    // A valid signature alone does not prove that money was captured.
    const razorpay = getRazorpay();
    const payment = await razorpay.payments.fetch(razorpay_payment_id);

    if (
      payment.order_id !== pendingOrder.razorpayOrderId ||
      payment.amount !== Math.round(pendingOrder.amount * 100) ||
      payment.currency !== pendingOrder.currency ||
      payment.status !== "captured"
    ) {
      return res.status(400).json({
        success: false,
        message: "Payment is not captured or does not match this order",
      });
    }

    const room = await Room.findById(pendingOrder.roomId);

    if (!room || !room.available) {
      return res.status(409).json({
        success: false,
        message:
          "Payment was received, but the room is no longer available. Contact support for assistance.",
        paymentId: razorpay_payment_id,
      });
    }

    // Claim the room atomically so two requests cannot both book it.
    const claimedRoom = await Room.findOneAndUpdate(
      { _id: room._id, available: true },
      { $set: { available: false } },
      { new: true }
    );

    if (!claimedRoom) {
      return res.status(409).json({
        success: false,
        message:
          "Payment was received, but the room is no longer available. Contact support for assistance.",
        paymentId: razorpay_payment_id,
      });
    }

    try {
      const booking = await Booking.create({
        userId: pendingOrder.userId,
        hotelId: pendingOrder.hotelId,
        roomId: pendingOrder.roomId,
        checkIn: pendingOrder.checkIn,
        checkOut: pendingOrder.checkOut,
        guests: pendingOrder.guests,
        totalAmount: pendingOrder.amount,
        bookingStatus: "Booked",
        paymentStatus: "Paid",
        razorpayOrderId: pendingOrder.razorpayOrderId,
        razorpayPaymentId: razorpay_payment_id,
      });

      pendingOrder.razorpayPaymentId = razorpay_payment_id;
      pendingOrder.paymentStatus = "Paid";
      pendingOrder.bookingId = booking._id;
      await pendingOrder.save();

      return res.json({
        success: true,
        message: "Payment verified and booking confirmed",
        booking,
      });
    } catch (bookingError) {
      // Release the room if booking persistence failed.
      await Room.findByIdAndUpdate(room._id, { available: true });
      throw bookingError;
    }
  } catch (err) {
    console.error("Verify payment error:", err.message);

    return res.status(500).json({
      success: false,
      message: "Unable to verify payment. Please contact support if money was deducted.",
    });
  }
};