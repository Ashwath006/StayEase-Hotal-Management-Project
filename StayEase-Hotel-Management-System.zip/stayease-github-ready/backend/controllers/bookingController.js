const Booking = require("../models/Booking");
const Room = require("../models/Room");

const hasOverlappingBooking = async (roomId, checkIn, checkOut, excludeId = null) => {
  const query = {
    roomId,
    bookingStatus: { $ne: "Cancelled" },
    paymentStatus: { $ne: "Failed" },

    // Existing booking overlaps with requested dates
    checkIn: { $lt: new Date(checkOut) },
    checkOut: { $gt: new Date(checkIn) },
  };

  // Exclude the current booking when needed
  if (excludeId) {
    query._id = { $ne: excludeId };
  }

  return Booking.findOne(query);
};

const refreshRoomAvailability = async (roomId) => {
  const now = new Date();

  // Find a booking that occupies the room right now
  const currentBooking = await Booking.findOne({
    roomId,
    bookingStatus: {
      $nin: ["Cancelled", "Checked Out", "Completed"],
    },
    paymentStatus: { $ne: "Failed" },
    checkIn: { $lte: now },
    checkOut: { $gt: now },
  });

  // Room is available only if no active booking exists now
  const room = await Room.findByIdAndUpdate(
    roomId,
    {
      available: !currentBooking,
    },
    {
      new: true,
    }
  );

  if (!room) {
    throw new Error("Room not found while updating availability");
  }

  return room;
};
// Create Booking
exports.createBooking = async (req, res) => {
  try {
    const {
      userId,
      hotelId,
      roomId,
      checkIn,
      checkOut,
      guests,
    } = req.body;

    if (!userId || !hotelId || !roomId || !checkIn || !checkOut) {
      return res.status(400).json({
        success: false,
        message: "Please provide all required booking details",
      });
    }

    const start = new Date(checkIn);
    const end = new Date(checkOut);

    if (
      Number.isNaN(start.getTime()) ||
      Number.isNaN(end.getTime()) ||
      start < new Date(new Date().setHours(0, 0, 0, 0)) ||
      end <= start
    ) {
      return res.status(400).json({
        success: false,
        message: "Please select valid check-in and check-out dates",
      });
    }

    const room = await Room.findById(roomId);

    if (!room) {
      return res.status(404).json({
        success: false,
        message: "Room Not Found",
      });
    }

    // Make sure the room belongs to the selected hotel
    if (String(room.hotel) !== String(hotelId)) {
      return res.status(400).json({
        success: false,
        message: "Room does not belong to the selected hotel",
      });
    }

    // Check guest capacity
    const guestCount = Number(guests || 1);

    if (
      !Number.isInteger(guestCount) ||
      guestCount < 1 ||
      guestCount > room.capacity
    ) {
      return res.status(400).json({
        success: false,
        message: `This room can accommodate up to ${room.capacity} guests`,
      });
    }

    const existingBooking = await hasOverlappingBooking(
      roomId,
      start,
      end
    );

    if (existingBooking) {
      return res.status(400).json({
        success: false,
        message: "Room is not available for these dates",
      });
    }

    const days = Math.ceil(
      (end - start) / (1000 * 60 * 60 * 24)
    );

    const totalAmount = days * room.price;

    const booking = await Booking.create({
      userId,
      hotelId,
      roomId,
      checkIn: start,
      checkOut: end,
      guests: guestCount,
      totalAmount,
      bookingStatus: "Booked",
    });

    // Update whether the room is occupied right now
    await refreshRoomAvailability(roomId);

    res.status(201).json({
      success: true,
      message: "Booking Created Successfully",
      booking,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

// Get All Bookings
exports.getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("userId", "name email")
      .populate("hotelId", "hotelName location")
      .populate("roomId", "roomNumber roomType");

    const roomIds = [
      ...new Set(
        bookings
          .filter((booking) => booking.roomId)
          .map((booking) => String(booking.roomId._id))
      ),
    ];

    await Promise.all(
      roomIds.map((id) => refreshRoomAvailability(id))
    );

    res.json({
      success: true,
      bookings,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

// Cancel Booking
exports.cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking Not Found",
      });
    }

    booking.bookingStatus = "Cancelled";
    await booking.save();

    await refreshRoomAvailability(booking.roomId);

    res.json({
      success: true,
      message: "Booking Cancelled Successfully",
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

exports.updateBookingStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const allowedStatuses = [
      "Booked",
      "Confirmed",
      "Pending",
      "Processing",
      "Cancelled",
      "Checked In",
      "Checked Out",
      "Completed",
    ];

    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid booking status: ${status}`,
      });
    }

    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking Not Found",
      });
    }

    booking.bookingStatus = status;
    await booking.save();

    const room = await refreshRoomAvailability(booking.roomId);

    return res.status(200).json({
      success: true,
      message: "Booking Status Updated Successfully",
      booking,
      roomAvailability: room?.available ?? null,
    });
  } catch (err) {
    console.error("Update booking status error:", err);

    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

// Get Bookings By User
exports.getUserBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({
      userId: req.params.userId,
    })
      .populate("hotelId", "hotelName location")
      .populate("roomId", "roomNumber roomType price");

    const roomIds = [
      ...new Set(
        bookings
          .filter((booking) => booking.roomId)
          .map((booking) => String(booking.roomId._id))
      ),
    ];

    await Promise.all(
      roomIds.map((id) => refreshRoomAvailability(id))
    );

    res.json({
      success: true,
      bookings,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};
