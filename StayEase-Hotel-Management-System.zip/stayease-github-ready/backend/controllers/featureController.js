const crypto = require("crypto");

/* =========================
   PAYMENT (RAZORPAY STRUCTURE)
========================= */

// Create Payment Order (STRUCTURE)
exports.createPaymentOrder = async (req, res) => {
  try {
    res.json({
      success: true,
      message: "Payment order created (structure ready)",
      orderId: "order_demo_12345",
      amount: req.body.amount || 0,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Verify Payment (STRUCTURE)
exports.verifyPayment = async (req, res) => {
  try {
    res.json({
      success: true,
      message: "Payment verified (structure ready)",
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


/* =========================
   PASSWORD + EMAIL OTP FLOW
========================= */

// Fake OTP store (for structure only)
let otpStore = {};

// Generate OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000);
};

// Send OTP for password change
exports.sendPasswordOTP = async (req, res) => {
  try {
    const { email } = req.body;

    const otp = generateOTP();

    otpStore[email] = otp;

    // (REAL PROJECT: send email here)
    console.log(`OTP sent to ${email}: ${otp}`);

    res.json({
      success: true,
      message: "OTP sent to email (structure ready)",
    });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Verify OTP
exports.verifyPasswordOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (otpStore[email] == otp) {
      return res.json({
        success: true,
        message: "OTP verified successfully",
      });
    }

    return res.status(400).json({
      success: false,
      message: "Invalid OTP",
    });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Change Password
exports.changePassword = async (req, res) => {
  try {
    const { email, newPassword } = req.body;

    // (REAL PROJECT: hash password + DB update)

    delete otpStore[email];

    res.json({
      success: true,
      message: "Password changed successfully (structure ready)",
    });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};