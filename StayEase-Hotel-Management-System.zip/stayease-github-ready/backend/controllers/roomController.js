
const Room = require("../models/Room");
const Booking = require("../models/Booking");

// Validate check-in and check-out dates
const getDateRange = (checkIn, checkOut) => {
  if (!checkIn || !checkOut) {
    return { error: "Please provide both check-in and check-out dates" };
  }

  const start = new Date(checkIn);
  const end = new Date(checkOut);

  if (
    Number.isNaN(start.getTime()) ||
    Number.isNaN(end.getTime()) ||
    end <= start
  ) {
    return { error: "Please provide valid check-in and check-out dates" };
  }

  return { start, end };
};

// Find rooms that are already booked during the selected dates
const getBookedRoomIds = async (checkIn, checkOut, hotelId) => {
  const query = {
    bookingStatus: { $ne: "Cancelled" },
    paymentStatus: { $ne: "Failed" },
    checkIn: { $lt: checkOut },
    checkOut: { $gt: checkIn },
  };

  if (hotelId) {
    query.hotelId = hotelId;
  }

  const bookings = await Booking.find(query).select("roomId");

  return new Set(
    bookings.map((booking) => String(booking.roomId))
  );
};

// Add Room
exports.addRoom = async (req, res) => {
  try {
    const room = await Room.create(req.body);

    res.status(201).json({
      success: true,
      message: "Room Added Successfully",
      room,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get All Rooms
exports.getRooms = async (req, res) => {
  try {
    const filter = {};

    if (req.query.hotelId) {
      filter.hotel = req.query.hotelId;
    }

    const { checkIn, checkOut } = req.query;

    // If dates are provided, both are required
    if (checkIn || checkOut) {
      const range = getDateRange(checkIn, checkOut);

      if (range.error) {
        return res.status(400).json({
          success: false,
          message: range.error,
        });
      }

      const rooms = await Room.find(filter)
        .populate("hotel", "hotelName location");

      const bookedRoomIds = await getBookedRoomIds(
        range.start,
        range.end,
        req.query.hotelId
      );

      const availableRooms = rooms.filter(
        (room) => !bookedRoomIds.has(String(room._id))
      );

      return res.json({
        success: true,
        count: availableRooms.length,
        rooms: availableRooms,
      });
    }

    // No dates selected: return all rooms as before
    const rooms = await Room.find(filter).populate(
      "hotel",
      "hotelName location"
    );

    res.json({
      success: true,
      count: rooms.length,
      rooms,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get Single Room
exports.getRoom = async (req, res) => {
  try {
    const room = await Room.findById(req.params.id).populate(
      "hotel",
      "hotelName location"
    );

    if (!room) {
      return res.status(404).json({
        success: false,
        message: "Room Not Found",
      });
    }

    const { checkIn, checkOut } = req.query;

    // Optionally check availability for selected dates
    if (checkIn || checkOut) {
      const range = getDateRange(checkIn, checkOut);

      if (range.error) {
        return res.status(400).json({
          success: false,
          message: range.error,
        });
      }

      const existingBooking = await Booking.findOne({
        roomId: room._id,
        bookingStatus: { $ne: "Cancelled" },
        paymentStatus: { $ne: "Failed" },
        checkIn: { $lt: range.end },
        checkOut: { $gt: range.start },
      });

      return res.json({
        success: true,
        room,
        isAvailableForDates: !existingBooking,
      });
    }

    res.json({
      success: true,
      room,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Update Room
exports.updateRoom = async (req, res) => {
  try {
    const room = await Room.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!room) {
      return res.status(404).json({
        success: false,
        message: "Room Not Found",
      });
    }

    res.json({
      success: true,
      message: "Room Updated Successfully",
      room,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Delete Room
exports.deleteRoom = async (req, res) => {
  try {
    const room = await Room.findByIdAndDelete(req.params.id);

    if (!room) {
      return res.status(404).json({
        success: false,
        message: "Room Not Found",
      });
    }

    res.json({
      success: true,
      message: "Room Deleted Successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
  