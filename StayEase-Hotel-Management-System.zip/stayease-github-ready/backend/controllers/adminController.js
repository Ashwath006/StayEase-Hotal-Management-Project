const User = require("../models/User");
const Hotel = require("../models/Hotel");
const Room = require("../models/Room");
const Booking = require("../models/Booking");

// ===============================
// Dashboard Statistics
// ===============================
exports.getDashboardStats = async (req, res) => {

  try {

    const totalUsers = await User.countDocuments();

    const totalHotels = await Hotel.countDocuments();

    const totalRooms = await Room.countDocuments();

    const totalBookings = await Booking.countDocuments();

    const revenue = await Booking.aggregate([
      {
        $group: {
          _id: null,
          total: { $sum: "$totalAmount" },
        },
      },
    ]);

    const totalRevenue =
      revenue.length > 0 ? revenue[0].total : 0;

    const recentBookings = await Booking.find()
      .populate("userId", "name")
      .populate("hotelId", "hotelName")
      .populate("roomId", "roomNumber")
      .sort({ createdAt: -1 })
      .limit(5);

    res.json({
      success: true,
      totalUsers,
      totalHotels,
      totalRooms,
      totalBookings,
      totalRevenue,
      recentBookings,
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }

};

// ===============================
// Get All Users
// ===============================
exports.getAllUsers = async (req, res) => {

  try {

    const users = await User.find().sort({
      createdAt: -1,
    });

    res.json({
      success: true,
      users,
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }

};

// ===============================
// Delete User
// ===============================
exports.deleteUser = async (req, res) => {

  try {

    const user = await User.findById(req.params.id);

    if (!user) {

      return res.status(404).json({
        success: false,
        message: "User Not Found",
      });

    }

    if (user.role === "admin") {

      return res.status(400).json({
        success: false,
        message: "Admin Cannot Be Deleted",
      });

    }

    await User.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: "User Deleted Successfully",
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }

};