const Review = require("../models/Review");

// Add Review
exports.addReview = async (req, res) => {
  try {

    const review = await Review.create(req.body);

    res.status(201).json({
      success: true,
      message: "Review Added Successfully",
      review,
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }
};

// Get Reviews by Hotel
exports.getReviews = async (req, res) => {
  try {

    const reviews = await Review.find({
      hotelId: req.params.hotelId,
    }).populate("userId", "name");

    res.json({
      success: true,
      count: reviews.length,
      reviews,
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }
};

// Delete Review
exports.deleteReview = async (req, res) => {
  try {

    await Review.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: "Review Deleted",
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }
};