const Hotel = require("../models/Hotel");

// Add Hotel
exports.addHotel = async (req, res) => {
  try {
    const hotel = await Hotel.create(req.body);

    res.status(201).json({
      success: true,
      message: "Hotel Added Successfully",
      hotel,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get All Hotels
exports.getHotels = async (req, res) => {
  try {
    const {
      search,
      location,
      minPrice,
      maxPrice,
      sort,
    } = req.query;

    let filter = {};

    // Search by Hotel Name
    if (search) {
      filter.hotelName = {
        $regex: search,
        $options: "i",
      };
    }

    // Search by Location
    if (location) {
      filter.location = {
        $regex: location,
        $options: "i",
      };
    }

    // Price Filter
    if (minPrice || maxPrice) {
      filter.price = {};

      if (minPrice) {
        filter.price.$gte = Number(minPrice);
      }

      if (maxPrice) {
        filter.price.$lte = Number(maxPrice);
      }
    }

    // Sorting
    let sortOption = {};

    switch (sort) {
      case "priceLow":
        sortOption.price = 1;
        break;

      case "priceHigh":
        sortOption.price = -1;
        break;

      case "ratingHigh":
        sortOption.rating = -1;
        break;

      case "ratingLow":
        sortOption.rating = 1;
        break;

      default:
        sortOption.createdAt = -1;
    }

    const hotels = await Hotel.find(filter).sort(sortOption);

    res.json({
      success: true,
      count: hotels.length,
      hotels,
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }
};

// Get Single Hotel
exports.getHotel = async (req, res) => {
  try {
    const hotel = await Hotel.findById(req.params.id);

    if (!hotel) {
      return res.status(404).json({
        success: false,
        message: "Hotel Not Found",
      });
    }

    res.json({
      success: true,
      hotel,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Update Hotel
exports.updateHotel = async (req, res) => {
  try {
    const hotel = await Hotel.findByIdAndUpdate(
      req.params.id,
      req.body,
      {returnDocument: "after"}
    );

    if (!hotel) {
      return res.status(404).json({
        success: false,
        message: "Hotel Not Found",
      });
    }

    res.json({
      success: true,
      message: "Hotel Updated Successfully",
      hotel,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Delete Hotel
exports.deleteHotel = async (req, res) => {
  try {
    const hotel = await Hotel.findByIdAndDelete(req.params.id);

    if (!hotel) {
      return res.status(404).json({
        success: false,
        message: "Hotel Not Found",
      });
    }

    res.json({
      success: true,
      message: "Hotel Deleted Successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};