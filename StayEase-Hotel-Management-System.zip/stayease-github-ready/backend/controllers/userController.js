const User = require("../models/User");

// =========================
// Get User Profile
// =========================
exports.getProfile = async (req, res) => {

  try {

    const user = await User.findById(req.params.id).select("-password");

    if (!user) {

      return res.status(404).json({
        success: false,
        message: "User Not Found",
      });

    }

    res.json({
      success: true,
      user,
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }

};

// =========================
// Update User Profile
// =========================
exports.updateProfile = async (req, res) => {

  try {

    const { name, phone } = req.body;

    const user = await User.findById(req.params.id);

    if (!user) {

      return res.status(404).json({
        success: false,
        message: "User Not Found",
      });

    }

    user.name = name || user.name;
    user.phone = phone || user.phone;

    await user.save();

    res.json({
      success: true,
      message: "Profile Updated Successfully",
      user,
    });

  } catch (err) {

    res.status(500).json({
      success: false,
      message: err.message,
    });

  }

};