const express = require("express");

const router = express.Router();

const {
  createBooking,
  getBookings,
  cancelBooking,
  getUserBookings,
  updateBookingStatus,
} = require("../controllers/bookingController");
// Create booking
router.post("/", createBooking);

// Get all bookings (admin)
router.get("/", getBookings);

// Get user bookings
router.get("/user/:userId", getUserBookings);

// Cancel booking
router.patch("/cancel/:id", cancelBooking);
router.put("/status/:id", updateBookingStatus);
module.exports = router;