const express = require("express");

const router = express.Router();

const {
  addRoom,
  getRooms,
  getRoom,
  updateRoom,
  deleteRoom,
} = require("../controllers/roomController");

router.post("/", addRoom);

router.get("/", getRooms);

router.get("/:id", getRoom);

router.put("/:id", updateRoom);

router.delete("/:id", deleteRoom);

module.exports = router;