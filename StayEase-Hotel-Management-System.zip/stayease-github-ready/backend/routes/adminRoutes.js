const express = require("express");

const router = express.Router();

const {
  getDashboardStats,
  getAllUsers,
  deleteUser,
} = require("../controllers/adminController");

// Dashboard
router.get("/dashboard", getDashboardStats);

// Get All Users
router.get("/users", getAllUsers);

// Delete User
router.delete("/users/:id", deleteUser);

module.exports = router;